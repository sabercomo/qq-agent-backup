#!/bin/sh
set -eu
rm -f /tmp/.X99-lock /tmp/.X11-unix/X99
Xvfb :99 -screen 0 1280x1200x24 -nolisten tcp &
exec node --use-env-proxy src/server.js
