import assert from 'node:assert/strict';
import { bootApp } from './_harness.mjs';

const env = await bootApp({ config: {
  persona: { botName: '呆猫', roleText: '呆猫专用测试角色卡', randomPerConversation: true },
  store: { contextSliderPos: 0, historyCount: 80 },
  chatActive: { enabled: true, ttlMinutes: 30 },
  skills: {
    'early-finish': { enabled: false },
    'persona-evolution': { enabled: false },
    'persona-grow': { enabled: false },
    'self-surf': { enabled: false },
    'hot-trend-tracker': { enabled: false }
  }
} });
const originalRandom = Math.random;

try {
  const scenarios = [
    { text: '@覆盖Bot 第一段', roll: 0.1, key: 'daimao', finish: { activeTopic: '第一段话题' } },
    { text: '继续第一段', roll: 0.9, key: 'daimao', finish: { summary: '话题结束' } },
    { text: '@覆盖Bot 第二段', roll: 0.9, key: 'xiaojingyu', finish: { activeTopic: '第二段话题' } },
    { text: '继续第二段', roll: 0.1, key: 'xiaojingyu', finish: { activeTopic: '第二段话题' } },
    { text: '@覆盖Bot 超时后新段', roll: 0.1, key: 'daimao', finish: { summary: '话题结束' }, expire: true },
    { text: '@覆盖Bot 关闭随机', roll: 0.9, key: '', finish: { summary: '话题结束' }, randomOff: true }
  ];
  for (const [index, scenario] of scenarios.entries()) {
    if (scenario.randomOff) env.app.updateConfig({ persona: { randomPerConversation: false } });
    if (scenario.expire) env.app.orchestrator.activeTopics.get('group:456').until = Date.now() - 1;
    Math.random = () => scenario.roll;
    const firstRequest = env.llm.state.requests.length;
    env.llm.state.script.push(
      { toolCalls: [{ name: 'send_message', args: { messages: `回复${index}` } }] },
      { toolCalls: [{ name: 'finish', args: { summary: '本轮结束', ...scenario.finish } }] }
    );
    env.pushGroupMsg(111, '张三', scenario.text, 9900 + index);
    const session = await env.waitSessionDone(scenario.text.replace('@覆盖Bot ', ''));
    assert.equal(session.personaKey, scenario.key);
    assert.ok(session.sent.some((entry) => entry.text === `回复${index}`));
    const request = env.llm.state.requests[firstRequest];
    const system = String(request.messages.find((message) => message.role === 'system').content);
    const user = String(request.messages.find((message) => message.role === 'user').content);
    assert.ok(system.startsWith(`你是「${scenario.key ? session.personaName : '呆猫'}」`));
    assert.equal(env.app.getConfig().persona.botName, '呆猫');
    assert.equal(system.includes('呆猫专用测试角色卡'), scenario.key === 'daimao');
    assert.equal(system.includes('角色卡：DeepSeek 小鲸鱼'), scenario.key === 'xiaojingyu');
    assert.equal(system.includes('【本轮身份确认】'), scenario.key === 'xiaojingyu');
    assert.equal(user.includes('呆猫专用测试角色卡'), !scenario.key);
    assert.equal(user.includes('角色卡：DeepSeek 小鲸鱼'), false);
    if (scenario.finish.activeTopic) {
      assert.equal(env.app.orchestrator.activeTopics.get('group:456').personaKey, scenario.key);
    } else {
      assert.equal(env.app.orchestrator.activeTopics.has('group:456'), false);
    }
    console.log(`PASS ${scenario.text}: ${session.personaName}`);
  }

  env.app.updateConfig({ skills: {
    'persona-evolution': { enabled: true }, 'persona-grow': { enabled: true }
  } });
  const { skillManager } = await import('../src/skills/manager.js');
  for (const id of ['persona-evolution', 'persona-grow']) {
    assert.equal(skillManager.isActive(id, { personaKey: 'xiaojingyu' }).active, false);
    assert.equal(skillManager.isActive(id, { personaKey: 'daimao' }).active, true);
  }
  console.log('PASS cat growth layers are scoped to cat conversations');
} finally {
  Math.random = originalRandom;
  await env.teardown();
}
