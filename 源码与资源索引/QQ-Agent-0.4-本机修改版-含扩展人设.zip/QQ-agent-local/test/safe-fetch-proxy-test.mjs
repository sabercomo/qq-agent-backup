import assert from 'node:assert/strict';
import http from 'node:http';
import net from 'node:net';
import { setRuntimeConfig } from '../src/config.js';
import { safeFetch, safeFetchBinary } from '../src/safe-fetch.js';

const hosts = [];
const backend = http.createServer((req, res) => {
  hosts.push(req.headers.host);
  if (req.url === '/private') {
    res.writeHead(302, { location: 'http://127.0.0.1/private' });
    res.end();
  } else if (req.url === '/large') {
    res.end('x'.repeat(60000));
  } else {
    res.end('热门排行测试');
  }
});
await new Promise((resolve) => backend.listen(0, '127.0.0.1', resolve));
const port = backend.address().port;
const tunnels = [];
const sockets = new Set();
const proxy = http.createServer();
proxy.on('connect', (req, socket, head) => {
  tunnels.push(req.url);
  const upstream = net.connect(port, '127.0.0.1', () => {
    socket.write('HTTP/1.1 200 Connection Established\r\n\r\n');
    if (head.length) upstream.write(head);
    socket.pipe(upstream).pipe(socket);
  });
  for (const s of [socket, upstream]) {
    sockets.add(s);
    s.on('close', () => sockets.delete(s));
  }
});
await new Promise((resolve) => proxy.listen(0, '127.0.0.1', resolve));

const names = ['http_proxy', 'https_proxy', 'no_proxy', 'HTTP_PROXY', 'HTTPS_PROXY', 'NO_PROXY', 'QQ_AGENT_DNS_OVER_HTTPS'];
const previous = Object.fromEntries(names.map((name) => [name, process.env[name]]));
const originalFetch = globalThis.fetch;
const dnsCalls = [];
process.env.http_proxy = process.env.HTTP_PROXY = `http://127.0.0.1:${proxy.address().port}`;
process.env.https_proxy = process.env.HTTPS_PROXY = process.env.http_proxy;
process.env.no_proxy = process.env.NO_PROXY = '';
process.env.QQ_AGENT_DNS_OVER_HTTPS = 'https://resolver.test/dns-query';
globalThis.fetch = async (raw) => {
  const url = new URL(raw);
  assert.equal(url.origin, 'https://resolver.test');
  dnsCalls.push(url.searchParams.get('name'));
  const hostname = url.searchParams.get('name');
  const isV6 = url.searchParams.get('type') === 'AAAA';
  return {
    ok: true,
    json: async () => ({
      Status: 0,
      Answer: isV6
        ? (hostname === 'mixed.test' ? [{ type: 28, data: '::1' }] : [])
        : [{ type: 1, data: hostname === 'local.test' ? '127.0.0.1' : '93.184.216.34' }]
    })
  };
};
setRuntimeConfig({ security: { allowPrivateImageHosts: true } });

try {
  const page = await safeFetch('http://ranking.test/');
  assert.equal(page.body, '热门排行测试');
  assert.deepEqual(tunnels, ['93.184.216.34:80']);
  assert.equal(hosts[0], 'ranking.test');
  assert(dnsCalls.includes('ranking.test'));

  const large = await safeFetch('http://ranking.test/large');
  assert.equal(large.body.length, 50000);
  assert(large.truncated);

  const beforeRedirect = tunnels.length;
  await assert.rejects(safeFetch('http://ranking.test/private'), /内网/);
  assert.equal(tunnels.length, beforeRedirect + 1);
  await assert.rejects(safeFetch('http://mixed.test/'), /内网/);
  assert.equal(tunnels.length, beforeRedirect + 1);

  setRuntimeConfig({ security: { browseLock: { enabled: true, hosts: ['allowed.test'] } } });
  const beforeLock = dnsCalls.length;
  await assert.rejects(safeFetch('http://ranking.test/', { browseLocked: true }), /浏览锁定/);
  assert.equal(dnsCalls.length, beforeLock);

  setRuntimeConfig({ security: { allowPrivateImageHosts: true } });
  process.env.no_proxy = process.env.NO_PROXY = 'local.test';
  const beforeDirect = tunnels.length;
  const direct = await safeFetchBinary(`http://local.test:${port}/`);
  assert.equal(direct.buffer.toString(), '热门排行测试');
  assert.equal(tunnels.length, beforeDirect);
  assert.equal(hosts.at(-1), `local.test:${port}`);
  console.log('PASS: proxy uses validated IP and original Host; body limit, private redirects, mixed DNS, browse lock and NO_PROXY hold');
} finally {
  globalThis.fetch = originalFetch;
  for (const [name, value] of Object.entries(previous)) {
    if (value === undefined) delete process.env[name];
    else process.env[name] = value;
  }
  for (const socket of sockets) socket.destroy();
  backend.closeAllConnections();
  await Promise.all([new Promise((resolve) => proxy.close(resolve)), new Promise((resolve) => backend.close(resolve))]);
}
