import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'qq-model-search-'));
process.env.QQ_AGENT_DATA_DIR = dir;
const { parseResponsesSearch } = await import('../src/web-search.js');

try {
  const message = { type: 'message', content: [{ type: 'output_text', text: '联网检索后的综合回答', annotations: [] }] };
  const search = { type: 'web_search_call', status: 'completed', action: { sources: [
    { type: 'url', url: 'https://api-docs.deepseek.com/' },
    { type: 'url', url: 'https://api-docs.deepseek.com/' },
    { type: 'url', url: 'https://example.com/guide', title: '来源页面' },
    { type: 'url', url: 'file:///etc/passwd' },
    { type: 'url', url: 'not a URL' }
  ] } };
  const result = parseResponsesSearch({ output: [search, message] }, '查询词');
  assert.deepEqual(result.results.map((item) => item.url), ['https://api-docs.deepseek.com/', 'https://example.com/guide']);
  assert.equal(result.answer, '联网检索后的综合回答');
  assert.equal(result.results[1].title, '来源页面');
  console.log('PASS Magpie GLM action.sources: real links, deduplication and invalid URL filtering');

  const cited = parseResponsesSearch({ output: [{ type: 'message', content: [{
    type: 'output_text', text: '引用回答', annotations: [
      { type: 'url_citation', url: 'https://example.com/cited', title: '引用来源' }
    ]
  }] }] }, '查询词');
  assert.equal(cited.results[0].title, '引用来源');
  assert.equal(cited.results[0].url, 'https://example.com/cited');
  console.log('PASS Responses citation annotations');

  assert.equal(parseResponsesSearch({ output: [search], output_text: '顶层回答' }, '词', 1).results.length, 1);
  assert.throws(() => parseResponsesSearch({ output: [message] }, '词'), /没有返回可用的来源链接/);
  assert.throws(() => parseResponsesSearch({ output: [{ ...search, status: 'failed' }, message] }, '词'), /没有返回可用的来源链接/);
  assert.throws(() => parseResponsesSearch({ output: [search] }, '词'), /没有返回回答文本/);
  console.log('PASS result limit; missing answers, missing sources and failed searches are explicit errors');
} finally {
  fs.rmSync(dir, { recursive: true });
}
