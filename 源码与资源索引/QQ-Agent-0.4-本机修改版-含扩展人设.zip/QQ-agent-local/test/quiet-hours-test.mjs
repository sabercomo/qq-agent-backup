import assert from 'node:assert/strict';
import { bootApp, sleep } from './_harness.mjs';

const RealDate = Date;
let offset = new RealDate('2026-10-30T02:00:00+08:00').getTime() - RealDate.now();
globalThis.Date = class extends RealDate {
  constructor(...args) { super(...(args.length ? args : [RealDate.now() + offset])); }
  static now() { return RealDate.now() + offset; }
};

const env = await bootApp({ config: {
  send: { quietHours: { enabled: true, start: '01:00', end: '07:00' } },
  store: { contextSliderPos: 100, keywords: ['大肥鱼', '肥鱼', '呆猫', '老大猫', 'DeepSeek', '吃白饭'] },
  chatActive: { enabled: true, ttlMinutes: 30 },
  skills: {
    'early-finish': { enabled: false },
    'persona-evolution': { enabled: false },
    'persona-grow': { enabled: false },
    'self-surf': { enabled: false },
    'hot-trend-tracker': { enabled: false }
  }
} });
const { inQuietHours, requestedReplyContext } = await import('../src/quiet-hours.js');
const { app, llm, pushGroupMsg } = env;

try {
  for (const [time, quiet] of [['00:59:59', false], ['01:00:00', true], ['06:59:59', true], ['07:00:00', false]]) {
    assert.equal(inQuietHours(new RealDate(`2026-10-30T${time}+08:00`)), quiet, time);
  }
  console.log('PASS 01:00 inclusive / 07:00 exclusive');

  app.orchestrator.activeTopics.set('group:456', { topic: '正在跟聊', until: Date.now() + 1800000 });
  pushGroupMsg(111, '张三', '普通夜间闲聊', 9801);
  await sleep(500);
  assert.equal(llm.state.requests.length, 0);
  assert.equal(app.store.getChatMeta('group:456').unread, 0);
  await app.orchestrator.wake('group:456', { proactive: true });
  assert.equal(llm.state.requests.length, 0);
  console.log('PASS overnight random replies, active follow-up and proactive wake blocked before LLM');

  for (const [message, expected, mid] of [
    ['@覆盖Bot 夜间艾特', '艾特可以回复', 9802],
    ['大肥鱼 夜间称呼', '称呼可以回复', 9803]
  ]) {
    llm.state.script.push(
      { toolCalls: [{ name: 'send_message', args: { messages: expected } }] },
      { toolCalls: [{ name: 'finish', args: { summary: '已回复' } }] }
    );
    pushGroupMsg(111, '张三', message, mid);
    const session = await env.waitSessionDone(message.includes('艾特') ? '夜间艾特' : '夜间称呼');
    assert.ok(session.sent.some((entry) => entry.text === expected), JSON.stringify({
      status: session.status, error: session.error, sent: session.sent,
      tools: session.messages.filter((entry) => entry.role === 'tool')
    }));
  }
  console.log('PASS actual orchestrator → model tool → send queue permits @ and nickname requests');

  await assert.rejects(app.sender.sendTextBatch('group:456', ['不能主动复读']), /夜间静默/);
  await assert.rejects(app.sender.sendImage('group:456', { url: 'https://example.com/image.png' }), /夜间静默/);
  await assert.rejects(app.sender.sendSticker('group:456', { id: 'test', url: 'https://example.com/sticker.png' }), /夜间静默/);
  await assert.rejects(app.sender.poke('group:456', 111), /夜间静默/);
  await requestedReplyContext.run('group:456', async () => {
    await assert.rejects(app.sender.sendTextBatch('group:789', ['不能借另一个群的唤醒发消息']), /夜间静默/);
    await app.sender.sendImage('group:456', { url: 'https://example.com/requested.png' });
  });
  await assert.rejects(app.sender.sendTextBatch('group:456', ['请求结束后不能继续主动发']), /夜间静默/);
  console.log('PASS text, stickers, pictures and pokes guarded; requested media allowed; allowance does not leak');

  offset = new RealDate('2026-10-30T00:59:59+08:00').getTime() - RealDate.now();
  const crossing = app.sender.sendTextBatch('group:456', ['跨入静默的第一条', '跨入静默的第二条']);
  await sleep(20);
  offset = new RealDate('2026-10-30T01:00:00+08:00').getTime() - RealDate.now();
  await assert.rejects(crossing, /夜间静默/);
  console.log('PASS queued messages rechecked after typing delay at 01:00');

  offset = new RealDate('2026-10-30T07:00:00+08:00').getTime() - RealDate.now();
  await app.sender.sendTextBatch('group:456', ['七点恢复普通发送']);
  console.log('PASS normal sending resumes at 07:00');
} finally {
  await env.teardown();
  globalThis.Date = RealDate;
}
