import assert from 'node:assert/strict';
import { bootApp, sleep } from './_harness.mjs';

const env = await bootApp({ config: {
  store: { contextSliderPos: 0, historyCount: 80 },
  wakeDelayMs: 300,
  skills: {
    'early-finish': { enabled: false },
    'persona-evolution': { enabled: false },
    'persona-grow': { enabled: false },
    'self-surf': { enabled: false },
    'hot-trend-tracker': { enabled: false },
    'repeat-echo': { enabled: false },
    'image-ref-hint': { enabled: false },
    'long-image-reader': { enabled: false }
  }
} });

try {
  for (const withBacklog of [false, true]) {
    const label = withBacklog ? '延迟到达且乱序' : '延迟到达的图片艾特';
    if (withBacklog) env.app.store.appendIncoming('group:456', {
      mid: 9810, ts: Date.now(), senderId: '112', senderName: '李四', text: '触发前已存在的积压'
    });
    const firstRequest = env.llm.state.requests.length;
    env.llm.state.script.push(
      { toolCalls: [{ name: 'send_message', args: { messages: label + '已回应' } }] },
      { toolCalls: [{ name: 'finish', args: { summary: '话题结束' } }] }
    );
    env.pushGroupMsg(111, '张三', '', withBacklog ? 9811 : 9801, {
      time: Math.floor(Date.now() / 1000) - 600,
      message: [
        { type: 'image', data: { file: 'late.png', url: 'https://example.com/late.png' } },
        { type: 'at', data: { qq: '888' } },
        { type: 'text', data: { text: label } }
      ]
    });
    if (withBacklog) {
      await sleep(60);
      env.pushGroupMsg(112, '李四', '窗口内追加的更早时间消息', 9812, {
        time: Math.floor(Date.now() / 1000) - 1200
      });
    }
    const session = await env.waitSessionDone(label);
    assert(session.sent.some(x => x.text === label + '已回应'));
    const prompt = String(env.llm.state.requests[firstRequest].messages.find(x => x.role === 'user').content);
    const wake = prompt.slice(prompt.indexOf('【未读信息】以下'));
    assert(wake.includes(label));
    if (withBacklog) {
      assert(wake.includes('窗口内追加的更早时间消息'));
      assert(!wake.includes('触发前已存在的积压'));
      assert(prompt.slice(0, prompt.indexOf('【未读信息】以下')).includes('触发前已存在的积压'));
    }
    assert.equal(env.app.store.unreadCount('group:456'), 0);
    console.log('PASS ' + label);
  }
} finally {
  await env.teardown();
}
