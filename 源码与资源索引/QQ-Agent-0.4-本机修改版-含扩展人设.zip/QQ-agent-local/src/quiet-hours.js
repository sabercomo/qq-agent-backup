import { AsyncLocalStorage } from 'node:async_hooks';
import { getConfig } from './config.js';

// 只为当前被明确召唤的会话放行，异步发送队列也继承这份上下文。
export const requestedReplyContext = new AsyncLocalStorage();

export function inQuietHours(at = new Date()) {
  const hours = getConfig().send.quietHours;
  if (!hours.enabled) return false;
  const [startHour, startMinute] = hours.start.split(':').map(Number);
  const [endHour, endMinute] = hours.end.split(':').map(Number);
  const start = startHour * 60 + startMinute;
  const end = endHour * 60 + endMinute;
  const minute = at.getHours() * 60 + at.getMinutes();
  return start < end ? minute >= start && minute < end : minute >= start || minute < end;
}

export function assertCanSend(chatKey) {
  if (inQuietHours() && requestedReplyContext.getStore() !== chatKey) {
    throw new Error('夜间静默：仅回复本会话的 @、称呼唤醒或私聊请求');
  }
}
