// 疯狂星期四发送器（可自定义） —— 确定性型插件（plugins/）
// （显示名与 plugin.json 的 name 一致；改名字只改那一处即可。）
//
// ── 为什么放 plugins/ 而不是 skills/ ────────────────────────────────────
// 按 skill-development.md §0 的三问判断法：
//   第一问（触发时机能用 if 描述吗）
//     if (今天是指定星期 && 在可发送时段内 && 不在上班时段 && 这是第 N 次主动开口) → 说
//     ✅ 能写成死规则 → 插件。第一问是本质，以它为准。
// 所以落在 plugins/。
//
// ══ 两条**完全不同**的路：群聊 vs 私聊 ═════════════════════════════════
//
// 【群聊】走官方机制 —— 不碰发送，只往系统提示词里注入一条指令，
//   真正发送由模型走正常工具链（send_message → ctx.sender），
//   限频 / 去重 / 每会话串行 / 留档 四项全部保留。
//   触发时机来自核心的「主动开话题」随机循环，它只会唤醒群聊
//   （打包版 orchestrator.js:1381 `if (kind !== 'group') continue;` 已核实）。
//
// 【私聊】核心**永远不会**对私聊发起"主动开口"（同一个 if 决定的），
//   所以私聊这一支只能由本插件自己巡检 + 直接调 OneBot HTTP 接口发送。
//   ⚠️ 代价（明确写在这里，不藏着）：私聊这条**绕过了官方发送队列**，
//      因此没有限频、没有去重、不会写进聊天存档（机器人"不记得"自己发过）。
//      重复发送靠本插件自己的落盘状态兜住（当天每个对象只发一次）。
//      这正是用户明确选择并接受的取舍；群聊那条没有这个代价。
//   默认**关闭**（privateEnabled=false），要用才开。
//
// ── 几个必须踩准的坑（都是本仓库里别人已经踩过的，注释里有出处）────────
//   · 不能用 `api.fetch`：本机它一调用就抛 `originalFetch is not a function`
//     （plugins/silence-ping/index.js:1103 的实测记录）。所以用全局 fetch。
//   · 取 OneBot 接入点不能只信程序配置：程序配置里可能是空令牌，要去 SnowLuma
//     的 onebot_<QQ>.json 里补，并**探活**确认令牌真能用（否则一路 401 静默发不出）。
//   · 调模型要用 `skillContext: { thinkingMode: 'off' }`：只是让它写一句话，
//     开着思考会把预算烧在 reasoning 上，正文可能直接为空。
//   · 钩子里禁止发消息/发请求（plugin-development.md §3.2），所以私聊巡检
//     只能放定时器（activate 建、deactivate 清），不能塞进钩子。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
// DATA_DIR 必须复用核心的导出，不要自己拼路径：它由 QQ_AGENT_DATA_DIR >
// QQ_AGENT_PROFILE（多实例 data-2/）> 默认 data/ 三层决定，自己算会写错实例。
import { DATA_DIR, getConfig, personaForChat } from '../../src/config.js';
// CQ 转义复用核心的实现（自己写容易漏掉 `[` / `]`，会被协议端当消息段解析）。
import { escapeCqText } from '../../src/util.js';

const STATE_FILE = path.join(DATA_DIR, 'thursday-vibe.json');
// 消息存档目录：核心把每个会话存成 <kind>_<id>.json。用于"上次说话时间"的兜底查询
// （范式同 plugins/silence-ping 的 fileStore：钩子还没跑过时也能查到记录）。
const MESSAGES_DIR = path.join(DATA_DIR, 'messages');
const WEEKDAYS = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
const MODE_FIXED = '固定次数';
const MODE_RANDOM = '随机一次';
const OUT_MAX_CHARS = 200;        // 私聊一次最多发多少字（超长截断）
const PRIVATE_FIRST_DELAY_MS = 20000;

let cfg = () => ({});
let log = () => {};

// 核心聊天存档的引用：只能靠 before-context 钩子带进来（钩子载荷里有 store）。
// 私聊巡检单独跑的时候没有 ctx，就靠这份缓存的引用查"上次说话时间"；
// 一次都没缓存到时会退回直接读 data/messages/ 文件。
let storeRef = null;

// ── 状态（落盘）────────────────────────────────────────────────────────
// {
//   day:   'YYYY-MM-DD',                 只保留当天，跨天自动清零
//   seen:  { 'group:123': 3 },           今天这个会话出现过几次"主动开口机会"
//   plan:  { 'group:123': 2 },           今天选定的触发序号（固定=N，随机=当天抽签）
//   fired: { 'group:123': {nth,at,sent} } 今天已经用掉了这次机会
// }
// plan 也落盘，是为了"当天抽签只抽一次"：否则每次进程重启都重抽，
// 随机模式下会变成"每次重启都有可能提前触发"。
let state = { day: '', seen: {}, plan: {}, fired: {} };

// 本次会话该不该注入 —— before-context 写、promptSections 读，键是 sessionId
// （两者拿到的是同一个 skillContext，sessionId 一致）。只在内存里：会话不跨进程存活。
const decisions = new Map();

// 私聊巡检定时器（activate 建、deactivate/dispose 清）
let privateTimer = null;
// 只提示一次的告警集合，防止定时器每轮刷屏
const warnedOnce = new Set();

function warnOnce(key, message) {
  if (warnedOnce.has(key)) return;
  warnedOnce.add(key);
  log(message);
}

/**
 * 两个通道的"名单是空的"提示。
 *
 * ⚠️ 刻意分开成两条、并且各自写明"**只有这一边不发，另一边不受影响**"：
 * 群聊和私聊是两条独立的路（阵容见文件头），一边的名单为空**绝不能**牵连另一边。
 * 提示里点名是哪个通道静默，免得用户以为"整个功能坏了"。
 */
function warnNoGroupList() {
  warnOnce('no-group-list',
    '「群聊生效」已打开，但「群聊名单」是空的 —— **只有群聊不发送，私聊不受影响**。'
    + '要发群就填群号（逗号分隔，例如 123456,789012）；留空不会自动理解成「所有群」。');
}

function warnNoPrivateList() {
  warnOnce('no-private-list',
    '「私聊生效」已打开，但「私聊名单」是空的 —— **只有私聊不发送，群聊不受影响**。'
    + '要发私聊就填 QQ 号（逗号分隔，例如 10001,10002）；留空不会自动理解成「所有好友」。');
}

function pad2(n) { return String(n).padStart(2, '0'); }

function todayKey(d = new Date()) {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

/** 跨天就清零。每次读写状态前都调一次。 */
function rollDay() {
  const key = todayKey();
  if (state.day !== key) {
    state = { day: key, seen: {}, plan: {}, fired: {} };
    decisions.clear();
    return true;
  }
  return false;
}

function loadState() {
  // 先归零再读：文件缺失/损坏时必须从干净状态开始。
  // 否则会沿用上一次留在内存里的计数 —— 表现为"把 data/thursday-vibe.json
  // 删了想重置，结果当天依然不发"，而且新实例沿用旧内存值完全看不出问题。
  state = { day: '', seen: {}, plan: {}, fired: {} };
  try {
    const parsed = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    if (parsed && typeof parsed === 'object') {
      state = {
        day: String(parsed.day || ''),
        seen: (parsed.seen && typeof parsed.seen === 'object') ? { ...parsed.seen } : {},
        plan: (parsed.plan && typeof parsed.plan === 'object') ? { ...parsed.plan } : {},
        fired: (parsed.fired && typeof parsed.fired === 'object') ? { ...parsed.fired } : {}
      };
    }
  } catch { /* 第一次运行，或文件坏了 —— 从零开始，不影响功能 */ }
  rollDay();
}

function saveState() {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    // 先写临时文件再 rename：避免"写了一半被读到"留下半个 JSON。
    const tmp = `${STATE_FILE}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(state, null, 1), 'utf8');
    fs.renameSync(tmp, STATE_FILE);
  } catch (error) {
    log(`状态写盘失败（本次仍按内存态走）：${error?.message ?? error}`);
  }
}

// ── 时间 / 星期判定 ────────────────────────────────────────────────────

/** "HH:MM" → 当天的第几分钟；不合法返回 null。 */
function parseHHMM(raw) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(raw ?? '').trim());
  if (!m) return null;
  const h = Number(m[1]);
  const min = Number(m[2]);
  if (h > 23 || min > 59) return null;
  return h * 60 + min;
}

/** 是否落在时段内。start === end 或配置非法时视为"全天"，不把功能卡死。 */
function inWindow(now, startRaw, endRaw) {
  const start = parseHHMM(startRaw);
  const end = parseHHMM(endRaw);
  if (start === null || end === null || start === end) return true;
  const cur = now.getHours() * 60 + now.getMinutes();
  // start < end 是普通时段；start > end 是跨零点（如 22:00~02:00）
  return start < end ? (cur >= start && cur < end) : (cur >= start || cur < end);
}

/**
 * 解析「上班时段」这类多段区间："09:00-12:00, 14:00-17:00" → [{start,end}]（单位：分钟）。
 * 刻意写得宽容，因为这个字段是要给人手敲的：
 *   · 分隔符 `-` `~` `～` `–` `—` `至` `到` 都认
 *   · 冒号 `:` `：` 和点号 `.` 都认（很多人习惯写 9.00）
 * 看不懂的段返回在 bad 里由调用方提示 —— 但**只忽略这一段**，不让整份配置失效
 * （配置写错就整个功能静默不工作，是最难排查的一类故障）。
 */
function parseRanges(raw) {
  const ranges = [];
  const bad = [];
  for (const piece of String(raw ?? '').split(/[,，、;；\n]+/)) {
    const s = piece.trim();
    if (!s) continue;
    const m = /^(\d{1,2})\s*[:.：]\s*(\d{1,2})\s*[-~～–—至到]\s*(\d{1,2})\s*[:.：]\s*(\d{1,2})$/.exec(s);
    if (!m) { bad.push(s); continue; }
    const [h1, m1, h2, m2] = [Number(m[1]), Number(m[2]), Number(m[3]), Number(m[4])];
    if (h1 > 23 || h2 > 23 || m1 > 59 || m2 > 59) { bad.push(s); continue; }
    ranges.push({ start: h1 * 60 + m1, end: h2 * 60 + m2 });
  }
  return { ranges, bad };
}

/** 当前是否落在任一段「上班时段」里。含跨零点；结束那一分钟不算在内。 */
function inQuietRanges(now, raw) {
  const { ranges, bad } = parseRanges(raw);
  for (const b of bad) warnOnce(`bad-range:${b}`, `「上班时段」里有一段看不懂、已忽略：${b} —— 正确写法形如 09:00-12:00，多段用逗号隔开`);
  const cur = now.getHours() * 60 + now.getMinutes();
  for (const r of ranges) {
    if (r.start === r.end) continue;                    // 空区间，忽略
    if (r.start < r.end ? (cur >= r.start && cur < r.end) : (cur >= r.start || cur < r.end)) return true;
  }
  return false;
}

/** 「周四」/「星期四」/「4」→ 0..6（0 = 周一）。看不懂返回 null。 */
function weekdayIndex(label) {
  const s = String(label ?? '').trim().replace(/^星期/, '周').replace(/^周天$/, '周日');
  const n = Number(s);
  if (Number.isInteger(n) && n >= 1 && n <= 7) return n - 1;
  const i = WEEKDAYS.indexOf(s);
  return i >= 0 ? i : null;
}

/** JS 的 getDay() 是 0=周日，换算成本表的 0=周一。 */
function currentWeekdayIndex(d = new Date()) {
  return (d.getDay() + 6) % 7;
}

/**
 * 名单解析：逗号/顿号/分号/空格分隔，只保留像群号/QQ 号的纯数字项（5~12 位）。
 * 群聊名单与私聊名单**共用这一个解析器** —— 两边语义现在是一致的（见下）。
 * 非数字项会被忽略；若因此把名单清空了，会走到"名单为空"的提示，不会是静默失效。
 */
function idList(raw) {
  return String(raw ?? '')
    .split(/[\s,，、;；]+/)
    .map((s) => s.trim())
    .filter((s) => /^\d{5,12}$/.test(s));
}

/**
 * ⚠️ 群聊名单与私聊名单都是"**留空 = 全不发**"，不是"全部"。
 * 理由：隐式的"全部"很容易在用户没想清楚时就把消息发到不该发的会话里；
 * 显式填写才是安全的默认。空名单时不会静默什么都不做 ——
 * 会提示一次为什么（见 groupGate 与 privateTick）。
 */
function groupList(c) { return idList(c?.groups); }

/** 私聊名单（QQ 号）。同 groupList：留空 = 全不发。 */
function privateTargets(c) { return idList(c?.privateList); }

/** 要发送的内容（去掉首尾空白）。空 = 没得发。 */
function contentOf(c) {
  return String(c?.content ?? '').trim();
}

/** 1~50 的整数钳制；非法回退到 fallback。 */
function clampNth(raw, fallback) {
  const n = Math.floor(Number(raw));
  if (!Number.isFinite(n) || n < 1) return fallback;
  return Math.min(50, n);
}

/**
 * 这个会话"最近一条消息"的时间戳 —— **任何一条都算**：对方说的、机器人说的都算。
 * 三个来源，取最大的那个：
 *   ① 核心存档（内存，最准；getChatMeta 的 lastTs 就是最后一条，含 self:true）
 *   ② data/messages/<kind>_<id>.json（兜底：钩子还没跑到过时也能查到）
 *   ③ **本插件自己直发的时间** —— 私聊走的是直连 HTTP，没有进核心存档，
 *      不叠加这一项的话"刚给某人发过 10 分钟"会被漏掉，等于门槛在私聊这边失效。
 */
function lastActivityTs(chatKey, store) {
  let ts = 0;
  try {
    const meta = store?.getChatMeta?.(chatKey);
    if (meta && Number(meta.lastTs) > 0) ts = Number(meta.lastTs);
  } catch { /* 存档读不到就退回读文件 */ }
  if (!ts) ts = lastTsFromFile(chatKey);
  const own = Number(state?.fired?.[chatKey]?.sentAt) || 0;
  return Math.max(ts, own);
}

/** 直接读消息存档文件，拿最后一条的 ts。文件不存在/坏了都返回 0。 */
function lastTsFromFile(chatKey) {
  const m = /^(group|private):(\d+)$/.exec(String(chatKey || ''));
  if (!m) return 0;
  try {
    const file = path.join(MESSAGES_DIR, `${m[1]}_${m[2]}.json`);
    const j = JSON.parse(fs.readFileSync(file, 'utf8'));
    const arr = Array.isArray(j?.messages) ? j.messages : [];
    const last = arr[arr.length - 1];
    return Number(last?.ts) || 0;
  } catch {
    return 0;                                   // 没有这个会话的存档 = 从没聊过
  }
}

/**
 * 冷场门槛：最近 idleMinMinutes 分钟内**有过任何消息**，现在就不主动开口。
 *
 * 语义（用户明确选择）：不区分是谁说的 —— 正在聊着就让位。
 * 这与核心「主动开话题」自己的冷场判定同源（它用 store.getChatMeta().lastTs），
 * 所以群聊那边本插件填小于 30 的数不会更激进：核心自带的 30 分钟是更硬的底线
 * （packaged config.js 的 proactive.idleThresholdMs=1800000，且没在界面上暴露）。
 *
 * 没有记录（从没聊过）= 够冷场 → 放行。
 */
function idleGate(chatKey, store, now = new Date()) {
  const c = cfg();
  const winMin = Math.floor(Number(c.idleMinMinutes));
  if (!Number.isFinite(winMin) || winMin <= 0) return { ok: true };     // 0 = 关掉这道门槛
  const last = lastActivityTs(chatKey, store);
  if (!last) return { ok: true };
  const idleMs = now.getTime() - last;
  if (idleMs < winMin * 60000) {
    const mins = Math.max(1, Math.round(idleMs / 60000));
    return { ok: false, why: `${mins} 分钟前这个会话还有消息（冷场门槛 ${winMin} 分钟），先不主动开口` };
  }
  return { ok: true };
}

/**
 * 只跟"时间与内容"有关的前置条件 —— 群聊和私聊**共用**一套（用户选择：设置共用，只分开关与名单）。
 * 计数与判定都只在这些条件全满足时才进行，这样"第 N 次"指的是
 * **可发送时段内的**第 N 次主动开口，不会出现"凌晨那次把序号占了、白天再也轮不到"。
 */
function timeGate(now = new Date()) {
  const c = cfg();

  const want = weekdayIndex(c.weekday);
  if (want === null) return { ok: false, why: `「星期几」配置看不懂：${c.weekday}` };
  if (currentWeekdayIndex(now) !== want) return { ok: false, why: `今天不是${WEEKDAYS[want]}` };

  if (c.allDay === false && !inWindow(now, c.windowStart, c.windowEnd)) {
    return { ok: false, why: `不在时段内（${c.windowStart}~${c.windowEnd}）` };
  }

  // 上班时段：排除项，优先级高于上面的"可发送时段"。
  if (c.skipWorkHours !== false && inQuietRanges(now, c.quietRanges)) {
    return { ok: false, why: `现在是上班时段（${c.quietRanges}），不发送` };
  }

  if (!contentOf(c)) return { ok: false, why: '「要发送的内容」是空的，没得发' };

  return { ok: true };
}

/** 群聊前置条件：必须是核心发起的"主动开口"，且群聊开关打开、群在名单里。 */
function groupGate(ctx) {
  const c = cfg();
  if (ctx?.proactive !== true) return { ok: false, why: '这次是在回复用户，不参与（避免影响正常聊天）' };
  if (String(ctx?.kind ?? '') !== 'group') return { ok: false, why: '这不是群聊' };
  if (c.groupEnabled === false) return { ok: false, why: '「群聊生效」已在设置里关掉' };
  const chatKey = String(ctx?.chatKey ?? '');
  if (!chatKey) return { ok: false, why: '这次没有会话上下文' };

  const list = groupList(c);
  if (!list.length) {
    warnNoGroupList();
    return { ok: false, why: '「群聊名单」是空的（留空 = 全不发），请填写群号' };
  }
  if (!list.includes(String(ctx?.chatId))) return { ok: false, why: `群 ${ctx?.chatId} 不在群聊名单里` };

  const t = timeGate(new Date());
  if (!t.ok) return t;
  const i = idleGate(chatKey, ctx?.store);
  if (!i.ok) return i;
  return { ok: true, chatKey, kind: 'group' };
}

/** 私聊前置条件：私聊开关打开、在私聊名单里、时间条件满足。 */
function privateGate(qq) {
  const c = cfg();
  if (c.privateEnabled !== true) return { ok: false, why: '「私聊生效」没开' };
  if (!privateTargets(c).includes(String(qq))) return { ok: false, why: `${qq} 不在私聊名单里` };
  const t = timeGate(new Date());
  if (!t.ok) return t;
  const i = idleGate(`private:${qq}`, storeRef);
  if (!i.ok) return i;
  return { ok: true, chatKey: `private:${qq}`, kind: 'private' };
}

/**
 * 记一次"主动开口机会"，返回是否命中触发点。
 *
 * consume=false 时只计数、不占位（用于"这次会话拿不到 sessionId"的情形，
 * 例如控制台的 /api/prompt-preview：它既注入不了，也就不该把当天机会用掉）。
 *
 * 用 >= 而不是 ===：万一某次机会没能走到"注入/发送"，序号会跳过去 ——
 * 用 === 就永远错过、当天不再触发。宁可晚一次，不要永不触发。
 */
function takeOpportunity(chatKey, { consume }) {
  rollDay();
  const c = cfg();
  state.seen[chatKey] = (Number(state.seen[chatKey]) || 0) + 1;
  const seen = state.seen[chatKey];

  // 当天第一次满足条件时定下"第几次触发"，之后不再改（随机模式只抽一次签）。
  if (!Number.isFinite(Number(state.plan[chatKey]))) {
    const randomMode = c.triggerMode === MODE_RANDOM;
    const max = clampNth(c.randomMax, 3);
    state.plan[chatKey] = randomMode
      ? 1 + Math.floor(Math.random() * max)
      : clampNth(c.triggerNth, 1);
    if (c.verbose) {
      log(`${chatKey} 今天定下触发序号：第 ${state.plan[chatKey]} 次（${randomMode ? `随机 1~${max}` : '固定'}）`);
    }
  }
  const plan = state.plan[chatKey];

  if (state.fired[chatKey] || seen < plan || !consume) return { fire: false, nth: seen, plan };
  state.fired[chatKey] = { nth: seen, at: Date.now(), sent: false };
  return { fire: true, nth: seen, plan };
}

// ── 生命周期 ───────────────────────────────────────────────────────────

export function setup(api) {
  cfg = api.config;      // 记住函数，不要在这里快照 —— 用户改设置后要立刻生效
  log = api.log;
  loadState();
  // 注意：**不在 setup 里读 cfg()**。加载期的 setup 早于本插件在注册表里登记，
  // 此刻 api.config() 还拿不到 manifest.settings（会读到 undefined）——
  // 这正是文档反复强调"配置要在执行时读"的那个坑。判定时才调 cfg()。
  api.log('疯狂星期四发送器（可自定义）已加载：群聊走官方机制（只在"主动开口"时），私聊是独立开关、默认关闭。');
}

// 可用性判定走同步调用链，返回 Promise 会被当成"可用"（skill-reference.md §3.1）。
// 这里只放"整个插件都没法工作"的条件；私聊名单为空只影响私聊那一支，不该让群聊一起失业。
export function available() {
  const c = cfg();
  if (c.weekday == null && c.content == null) return true;   // 配置还没读到 → 乐观放行
  if (weekdayIndex(c.weekday) === null) {
    return { ok: false, reason: `设置里的「星期几」看不懂：${c.weekday}，请在设置里重新选一次` };
  }
  if (c.content != null && !contentOf(c)) {
    return { ok: false, reason: '设置里的「要发送的内容」是空的，请填上要它说的话' };
  }
  return true;
}

/**
 * 被启用时：起私聊巡检定时器。
 *
 * ⚠️ **无条件**启动，不在 activate 里判断 privateEnabled —— 因为用户改设置不会重新触发
 * activate，只有开关被拨动/热重载才会。若在这里判断，用户把「私聊生效」打开后
 * 必须重启才生效（表现就是"明明开了却什么都不发"）。所以定时器常驻、
 * 每轮进去现读配置：关着就立刻返回，开销可以忽略。
 */
export function activate() {
  startupListCheck();
  startPrivateLoop();
}

/**
 * 启动时把"名单没填"讲清楚，**两个通道各自独立判断**。
 *
 * 为什么不能只靠 groupGate 里的提示：那个提示只在群里真的出现"主动开口"时才跑，
 * 而核心的「主动开话题」默认是关的 —— 那就永远不会有人来问，提示也就永远不出现，
 * 用户只看到"什么都不发"却没有任何线索。私聊那边有定时器兜着，本来就会出现。
 */
function startupListCheck() {
  const c = cfg();
  // 配置还没读到时（activate 早于注册的极端情形）什么都别判断，免得误报。
  if (c.groups === undefined && c.groupEnabled === undefined && c.privateEnabled === undefined) return;
  if (c.groupEnabled !== false && !groupList(c).length) warnNoGroupList();
  if (c.privateEnabled === true && !privateTargets(c).length) warnNoPrivateList();
}

/** 被关闭时：**必须**清掉 activate 建的东西，否则会留下幽灵定时器继续发私信。 */
export function deactivate() {
  stopPrivateLoop();
}

/** 卸载/热重载时兜底再清一次。 */
export function dispose() {
  stopPrivateLoop();
}

// 本插件不建别的监听器/订阅；唯一的常驻资源就是上面这个定时器，已在两处清理。
// 热重载顺序是"先 deactivate+dispose 旧实例，再跑新 setup"，所以不会累积。

// ── ① 群聊：计数与判定（每个会话恰好一次）────────────────────────────────

export const hooks = {
  /**
   * 提示词组装之前（每个会话恰好一次，源码：orchestrator.js 的 #runAgent）。
   * 群聊这一支唯一的"写"入口。
   *
   * 为什么不放 promptSections 里计数：那个函数会被 ① 每个会话、
   * ② 控制台 /api/prompt-preview 调用（它传的 ctx 没有 sessionId/proactive）。
   * 在那种地方写盘会把真实序号算错。放这里，"一个会话算一次"是结构上保证的。
   */
  'before-context': (ctx = {}) => {
    // 先把聊天存档的引用捡起来（任何会话都带 store，**必须在任何 return 之前**）：
    // 私聊巡检是独立定时器跑的，没有 ctx，只能靠这份引用查"上次说话时间"。
    if (ctx.store) storeRef = ctx.store;

    const g = groupGate(ctx);
    if (!g.ok) {
      if (cfg().verbose) log(`本次不计入：${g.why}`);
      return;
    }
    const sid = ctx.sessionId == null ? '' : String(ctx.sessionId);
    const r = takeOpportunity(g.chatKey, { consume: Boolean(sid) });
    if (r.fire && sid) {
      decisions.set(sid, true);
      if (decisions.size > 200) decisions.delete(decisions.keys().next().value);
      if (cfg().verbose) log(`${g.chatKey} 命中：今天第 ${r.nth} 次主动开口（计划第 ${r.plan} 次）→ 已注入指令`);
    }
    saveState();
  },

  /**
   * 工具执行之后。只观察、只记账，不发消息、不发请求（钩子禁令）。
   * 让 verbose 日志能区分"指令注入了但模型没说"与"说了"，也满足审计对
   * plugins/ 的归位要求（确定性型必须提供能力或钩子）。
   */
  'after-tool': ({ toolName, result, chatKey, kind }) => {
    if (toolName !== 'send_message') return;
    if (result?.isError) return;                      // 发送失败不算
    const key = String(chatKey ?? '');
    if (!key || String(kind ?? '') !== 'group') return;

    rollDay();
    const rec = state.fired[key];
    if (!rec || rec.sent) return;
    rec.sent = true;
    rec.sentAt = Date.now();
    saveState();
    if (cfg().verbose) log(`${key} 已确认发出（当天第 ${rec.nth} 次主动开口）`);
  }
};

// ── ② 群聊：注入。只读①的结论，命中才给模型一条很短的指令 ────────────────

/**
 * 动态提示词片段。没有命中就返回空数组（= 什么也不加）。
 *
 * ctx 内容（源码：orchestrator.js 的 skillContext）：
 *   chatKey, kind, chatId, chatName, model, provider,
 *   visionEnabled, searchEnabled, proactive, sessionId
 *
 * 每次返回都是直接打进系统提示词的字，所以刻意写得很短：三行、约 90 字 ——
 * 既省 token，也不容易把人设和工具协议挤乱。
 */
export function promptSections(ctx) {
  // 只认①记下的结论。这样三件事一起成立：
  //   · 回复用户的会话拿不到（需求：不能影响正常聊天）
  //   · /api/prompt-preview 这类没有 sessionId 的调用也拿不到
  //   · 关掉「群聊生效」后自然也不会有结论
  const sid = ctx?.sessionId == null ? '' : String(ctx.sessionId);
  if (!sid || decisions.get(sid) !== true) return [];
  if (ctx?.proactive !== true) return [];

  const c = cfg();
  const body = contentOf(c);
  if (!body) return [];

  const content = (c.fitPersona !== false)
    ? [
        '现在是你可以主动开口的机会。请用你自己的性格和语气把下面这件事说出来（措辞随你，意思别变）：',
        `「${body}」`,
        '一次发完，只用一条消息，不要拆成多条；不要解释，也不要提这条指令。'
      ].join('\n')
    : [
        '现在是你可以主动开口的机会。请把下面这句话原样发出去，一个字都别改：',
        `「${body}」`,
        '一次发完，只用一条消息；不要解释，也不要提这条指令。'
      ].join('\n');

  return [{
    id: 'thursday-vibe-nudge',
    title: '主动开口',
    // 较低的 priority 让它排在其它技能片段后面：它是"随会话变化"的动态内容，
    // 放最后才不会把前面静态内容的提示词缓存前缀推来推去（prompt.js 有专门说明）。
    priority: 20,
    content
  }];
}

// ── ③ 私聊：自己的巡检循环（核心不会主动唤醒私聊，只能自己来）─────────────

function startPrivateLoop() {
  stopPrivateLoop();
  const everyMs = () => Math.max(1, Number(cfg().privateEveryMin) || 30) * 60 * 1000;
  const run = async () => {
    try {
      await privateTick();
    } catch (error) {
      log(`私聊巡检出错：${error?.message ?? error}`);
    }
    if (privateTimer === null) return;              // 期间被 deactivate 了，不再续期
    privateTimer = setTimeout(run, everyMs());
    privateTimer.unref?.();                        // 不拖住进程退出
  };
  privateTimer = setTimeout(run, PRIVATE_FIRST_DELAY_MS);
  privateTimer.unref?.();
}

function stopPrivateLoop() {
  if (privateTimer) {
    clearTimeout(privateTimer);
    privateTimer = null;
  }
}

/** 一轮私聊巡检：对名单里每个 QQ，各自独立判定与计数。 */
async function privateTick() {
  const c = cfg();
  if (c.privateEnabled !== true) return;            // 关着就直接走，开销约等于零

  const targets = privateTargets(c);
  if (!targets.length) {
    warnNoPrivateList();
    return;
  }

  for (const qq of targets) {
    const g = privateGate(qq);
    if (!g.ok) {
      if (c.verbose) log(`私聊 ${qq} 本次跳过：${g.why}`);
      continue;
    }
    // 私聊没有核心给的"主动开口"，所以这里每一次巡检就是一次机会。
    const r = takeOpportunity(g.chatKey, { consume: true });
    if (!r.fire) {
      saveState();
      if (c.verbose) log(`私聊 ${qq} 本次不触发：今天第 ${r.nth} 次机会，计划第 ${r.plan} 次`);
      continue;
    }
    saveState();

    let text;
    try {
      text = await composeText(g.chatKey, c);
      await onebotSend(g.chatKey, text);
      state.fired[g.chatKey].sent = true;
      state.fired[g.chatKey].sentAt = Date.now();
      saveState();
      log(`已给 ${qq} 发出私聊：${text.slice(0, 40)}${text.length > 40 ? '…' : ''}`);
    } catch (error) {
      // 发送失败要把占位退回，否则当天再也不会重试（一天只发一次的设计会把它彻底吞掉）。
      delete state.fired[g.chatKey];
      saveState();
      log(`给 ${qq} 发私聊失败（已退回本次机会，下一轮会重试）：${error?.message ?? error}`);
    }
  }
}

/** 去掉不该出现在 QQ 消息里的东西，并保证"一次发完"。 */
function cleanOutgoing(text) {
  let t = String(text ?? '');
  t = t.replace(/```[\s\S]*?```/g, ' ');             // 代码块
  t = t.split(/\n+/)[0];                             // 只留第一行 —— 一次发完
  t = t.replace(/^["“'']+|["”'']+$/g, '').trim();     // 去掉包着的引号
  t = t.replace(/^(回复|消息|私信)[:：]\s*/, '').trim();
  if (t.length > OUT_MAX_CHARS) t = t.slice(0, OUT_MAX_CHARS);
  return t;
}

/**
 * 生成要发出去的文本。
 *   fitPersona=false → 原样照发配置的内容（不调模型，0 token）
 *   fitPersona=true  → 调一次模型让它用自己的语气写一句
 * 模型失败/返回空 → 退回原文（宁可发得生硬，也不要什么都不发）。
 */
async function composeText(chatKey, c) {
  const body = contentOf(c);
  if (c.fitPersona === false) return body;

  try {
    const llm = await import('../../src/llm.js');
    const persona = String(personaForChat?.(chatKey)?.roleText || getConfig()?.persona?.roleText || '').trim();
    const res = await llm.chatCompletion({
      messages: [
        { role: 'system', content: persona ? `你的人设：\n${persona}` : '你是一个聊天机器人。' },
        {
          role: 'user',
          content: `请用你自己的语气，把下面这件事写成一句可以直接发出去的话。`
            + `只输出这句话本身：不要引号、不要解释、不要换行。\n${body}`
        }
      ],
      temperature: 0.9,
      maxTokens: 200,
      // 只是写一句话，不需要思考：开着思考会把预算烧在 reasoning 上，
      // 正文可能直接为空（llm.js 支持按次覆盖）。
      skillContext: { thinkingMode: 'off' }
    });
    const raw = res?.message?.content;
    const text = Array.isArray(raw) ? raw.map((x) => x?.text ?? '').join('') : String(raw ?? '');
    const cleaned = cleanOutgoing(text);
    return cleaned || body;
  } catch (error) {
    log(`私聊生成措辞失败，改用原文发送：${error?.message ?? error}`);
    return body;
  }
}

// ── 私聊发送：OneBot HTTP 直发（唯一可行通道，代价见文件头）──────────────

/** 发送用的 fetch。**不用 api.fetch**：本机它一调用就抛 originalFetch is not a function。 */
function doFetch(url, init) {
  return fetch(url, init);
}

let snowCache = { at: 0, list: [] };

/**
 * 收集 SnowLuma 配置里的 HTTP 接入点候选（带 30 秒缓存）。
 * 只认 onebot_*.json，避免挑到无关配置（范式同 plugins/silence-ping、plugins/friend-gate）。
 */
function snowlumaCandidates() {
  if (Date.now() - snowCache.at < 30000) return snowCache.list;
  const list = [];
  try {
    const here = path.dirname(fileURLToPath(import.meta.url));
    const appRoot = path.resolve(here, '..', '..');       // plugins/<id>/ → app 根
    const dirs = [
      path.join(appRoot, 'snowluma', 'config'),
      path.join(appRoot, 'resources', 'snowluma', 'config'),
      path.join(appRoot, '..', 'snowluma', 'config')
    ];
    for (const dir of dirs) {
      try {
        if (!dir || !fs.existsSync(dir)) continue;
        for (const f of fs.readdirSync(dir)) {
          if (!/^onebot_.*\.json$/i.test(f)) continue;
          try {
            const j = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
            const hs = (j?.networks?.httpServers) || [];
            const ws = (j?.networks?.wsServers) || [];
            const port = Number(hs[0]?.port || 3000);
            const tk = String(hs[0]?.accessToken || ws[0]?.accessToken || '');
            if (tk) list.push({ base: `http://${hs[0]?.host || '127.0.0.1'}:${port}`, token: tk, file: f });
          } catch { /* 跳过坏文件 */ }
        }
        if (list.length) break;                          // 找到一个有效目录就够了
      } catch { /* 试下一个目录 */ }
    }
  } catch { /* 忽略 */ }
  snowCache = { at: Date.now(), list };
  return list;
}

/**
 * 选定可用的 OneBot 接入点：程序配置 → SnowLuma 配置 → 逐个探活（get_status 需要认证，正好当探针）。
 * 不探活的话，拿着失效令牌会一路 401、表现成"什么都没发生"，极难排查。
 */
async function onebotPick() {
  const appCfg = getConfig()?.snowluma || {};
  const appBase = String(appCfg.httpUrl || '').replace(/\/+$/, '');
  const appToken = String(appCfg.httpAccessToken || appCfg.accessToken || '');

  const tries = [];
  if (appBase && appToken) tries.push({ base: appBase, token: appToken, from: '程序配置' });
  for (const c of snowlumaCandidates()) {
    const base = appBase || c.base;
    if (tries.some((t) => t.token === c.token && t.base === base)) continue;
    tries.push({ base, token: c.token, from: `SnowLuma(${c.file})` });
  }
  if (!tries.length) tries.push({ base: appBase || 'http://127.0.0.1:3000', token: appToken, from: '默认' });

  for (const t of tries) {
    if (!t.token) continue;
    try {
      const res = await doFetch(`${t.base}/get_status`, {
        headers: { authorization: `Bearer ${t.token}` },
        signal: AbortSignal.timeout(8000)
      });
      if (res.ok) return t;
      warnOnce(`probe-${t.base}-${res.status}`, `OneBot 接入点探活失败 HTTP ${res.status}：${t.base}（来源 ${t.from}）`);
    } catch (error) {
      warnOnce(`probe-${t.base}-err`, `OneBot 接入点探活异常：${t.base}（来源 ${t.from}）：${error?.message ?? error}`);
    }
  }
  const fallback = tries[0];
  warnOnce('probe-fallback',
    `没有探到可用令牌，退回 ${fallback.base}（来源 ${fallback.from}，令牌${fallback.token ? '有' : '为空'}）。`
    + '若发送一直 401，请在 SnowLuma 里确认 HTTP 服务端口与令牌。');
  return fallback;
}

/** OneBot HTTP 直发。只允许私聊：群聊那条走官方队列，不该从这里出去。 */
async function onebotSend(chatKey, text) {
  const m = /^private:(\d+)$/.exec(String(chatKey || ''));
  if (!m) throw new Error(`私聊直发只接受 private:<QQ号>，收到：${chatKey}`);
  const { base, token, from } = await onebotPick();
  const res = await doFetch(`${base}/send_private_msg`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: JSON.stringify({ user_id: Number(m[1]), message: [{ type: 'text', data: { text: escapeCqText(text) } }] }),
    signal: AbortSignal.timeout(60000)
  });
  if (!res.ok) {
    throw new Error(res.status === 401
      ? `OneBot HTTP 401（令牌未被接受，来源：${from}；请核对 SnowLuma 的 HTTP 端口与令牌）`
      : `OneBot HTTP ${res.status}`);
  }
}

/**
 * 测试替身（仅供 test/ 使用，生产路径不读它）。
 *
 * 为什么要开这个口子：私聊那支是"定时器 + 网络"，直接测就得等 30 分钟或真发一条私信出去。
 * 本仓库已有同款做法：plugins/silence-ping 的 internals.aiOverride
 * （"测试替身：仅在 internals.aiOverride 被设置时生效，生产环境恒为 null"）。
 * 这里只暴露只读能力与"手动跑一轮"，不改变任何生产行为。
 */
export const internals = {
  privateTick,
  onebotPick,
  idleGate,
  lastActivityTs,
  lastTsFromFile,
  hasPrivateTimer: () => privateTimer !== null
};
