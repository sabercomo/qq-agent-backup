// 人设生长（LLM 型技能）
//
// 设计原则：
//   1. 日常成长写进独立的「生长层」(data/persona-grow/growth.json)，每轮通过
//      promptSections 注入 —— 不覆盖用户手写的角色卡，随时可删可回滚。
//   2. 只有主人私聊里明确要求时，才用 patch 追加到 config.persona.roleText。
//   3. 对方表达不满时，先提醒模型「问清楚再改」，而不是自己猜。
//   4. 所有写操作都有上限（每日条数、总条数、去重），避免一天之内被人设带跑。

import fs from 'node:fs';
import path from 'node:path';
import { getConfig, updateConfig, DATA_DIR } from '../../src/config.js';

const STORE_DIR = path.join(DATA_DIR, 'persona-grow');
const STORE_FILE = path.join(STORE_DIR, 'growth.json');
const CATEGORIES = ['口癖', '偏好', '雷点', '习惯', '梗', '其他'];
const ROLE_APPEND_HEADER = '\n\n## 后来长出来的（自动追加）\n';

const DISSATISFY_WORDS = [
  '不像你', '不对', '重说', '你变了', '太ai', '太 ai', '不是这样', '别这么',
  '错了', '怪怪的', '出戏', '尴尬', '谁问你了', '答非所问', '人设崩', 'ooc',
];

let cfg = () => ({});
let log = () => {};
let warn = () => {};

function now() {
  return Date.now();
}

function dayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function defaults() {
  return { items: [], lastLearnAt: 0, learnDay: '', learnCount: 0, lastAskAt: 0 };
}

function load() {
  try {
    const d = JSON.parse(fs.readFileSync(STORE_FILE, 'utf8'));
    return { ...defaults(), ...d, items: Array.isArray(d.items) ? d.items : [] };
  } catch {
    return defaults();
  }
}

function save(data) {
  try {
    fs.mkdirSync(STORE_DIR, { recursive: true });
    const tmp = `${STORE_FILE}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
    fs.renameSync(tmp, STORE_FILE);
  } catch (e) {
    warn('保存生长层失败：' + (e?.message || e));
  }
}

function newId() {
  return 'g' + now().toString(36) + Math.random().toString(36).slice(2, 6);
}

function normalizeCategory(raw) {
  const s = String(raw || '').trim();
  if (CATEGORIES.includes(s)) return s;
  if (/口癖|口头禅|说法|语气/.test(s)) return '口癖';
  if (/喜好|偏好|喜欢|爱/.test(s)) return '偏好';
  if (/雷|讨厌|禁区|不喜欢/.test(s)) return '雷点';
  if (/习惯|作息|日常/.test(s)) return '习惯';
  if (/梗/.test(s)) return '梗';
  return '其他';
}

function squash(s) {
  return String(s || '').replace(/\s+/g, '');
}

function tooSimilar(a, b) {
  const x = squash(a);
  const y = squash(b);
  if (!x || !y) return false;
  if (x === y) return true;
  if (x.length > 6 && y.length > 6 && (x.includes(y) || y.includes(x))) return true;
  return x.slice(0, 10) === y.slice(0, 10);
}

function ownerIds() {
  const c = getConfig() || {};
  const raw = c.skills?.['owner-identity']?.ids;
  if (typeof raw === 'string' && raw.trim()) {
    return raw.split(/[,，\s]+/).map((s) => s.trim()).filter(Boolean);
  }
  if (Array.isArray(raw)) return raw.map(String);
  return [];
}

/** 找「对方上一条是不是在表达不满」，返回提示文本或空串。 */
function dissatisfactionHint(ctx) {
  try {
    if (!ctx?.chatKey || !ctx?.store?.recent) return '';
    const list = ctx.store.recent(ctx.chatKey, { limit: 4 });
    if (!list || typeof list.then === 'function' || !Array.isArray(list)) return '';
    const lastUser = [...list].reverse().find((m) => m && !m.self && m.text);
    if (!lastUser) return '';
    const t = String(lastUser.text).toLowerCase();
    if (!DISSATISFY_WORDS.some((w) => t.includes(w))) return '';
    return '【注意】对方上一条明显不满意。先问一句他希望我哪儿不一样（一句话，别辩解、别连发道歉），问清楚再改；不要马上换个说法硬圆。';
  } catch {
    return '';
  }
}

function renderGrowth(limit) {
  const d = load();
  const items = d.items.slice(-limit);
  if (!items.length) return '';
  const lines = items.map((it) => `- [${it.category}] ${it.content}`);
  return `【我长出来的样子】这些是真实聊天里慢慢记住的，自然地用，别当台词复述：\n${lines.join('\n')}`;
}

/** 动态提示词片段：生长层 + 不满提醒。 */
export function promptSections(ctx = {}) {
  try {
    const c = cfg() || {};
    const parts = [];
    const limit = Math.max(1, Math.min(30, Number(c.injectLimit) || 12));
    const growth = renderGrowth(limit);
    if (growth) parts.push(growth);
    if (c.dissatisfactionCheck !== false) {
      const hint = dissatisfactionHint(ctx);
      if (hint) parts.push(hint);
    }
    if (!parts.length) return [];
    return [{ id: 'persona-growth', title: '人设生长', priority: 30, content: parts.join('\n\n') }];
  } catch {
    return [];
  }
}

export function available(context = {}) {
  if (context.personaKey === 'xiaojingyu') return { ok: false, reason: '本轮是小鲸鱼，呆猫生长层不参与' };
  return { ok: true };
}

export function setup(api) {
  cfg = api.config || (() => ({}));
  log = api.log || (() => {});
  warn = api.warn || log;

  // ── 1. 查看 ──────────────────────────────────────────────
  api.registerTool({
    id: 'view',
    name: '查看人设生长层',
    description: '查看自己目前「长出来」的口癖/偏好/雷点等条目，以及角色卡正文长度。当你想确认自己现在是什么样、或决定要改什么之前使用。',
    category: 'memory',
    icon: '🌱',
    parameters: { type: 'object', properties: {} },
    async execute() {
      const d = load();
      const role = String(getConfig()?.persona?.roleText || '');
      if (!d.items.length) {
        return { content: `生长层还是空的。角色卡正文 ${role.length} 字。可以先在聊天里留意对方的偏好和你的口头禅。` };
      }
      const lines = d.items.map((it, i) => {
        const ev = it.evidence ? `（依据：${String(it.evidence).slice(0, 40)}）` : '';
        return `${i + 1}. [${it.category}] ${it.content}${ev}`;
      });
      return { content: `角色卡正文 ${role.length} 字。生长层 ${d.items.length} 条：\n${lines.join('\n')}` };
    }
  });

  // ── 2. 记一条成长 ────────────────────────────────────────
  api.registerTool({
    id: 'learn',
    name: '记一条人设成长',
    description: '把一条在真实聊天里有依据的「变化」写进生长层：口癖、偏好、雷点、习惯、梗。当对方明确表达喜好/雷点、你发现自己反复用某个说法、或被人纠正过时使用。一次只记一条。',
    category: 'memory',
    icon: '📝',
    parameters: {
      type: 'object',
      properties: {
        category: {
          type: 'string',
          enum: CATEGORIES,
          description: '这条属于哪一类：口癖 / 偏好 / 雷点 / 习惯 / 梗 / 其他'
        },
        content: { type: 'string', description: '一句话写清这条成长，20~60 字，写具体（例：被叫「大肥鱼」会先嘴硬再认）' },
        evidence: { type: 'string', description: '依据：对方的原话或发生场景，没有就留空' }
      },
      required: ['content']
    },
    async execute(ctx, args = {}) {
      const c = cfg() || {};
      const content = String(args.content || '').trim();
      if (!content) return { content: '缺少 content：要用一句话写清这条成长', isError: true };
      if (content.length > 120) return { content: `内容太长（${content.length} 字），请压到 60 字以内再记`, isError: true };

      const d = load();
      const category = normalizeCategory(args.category);
      if (d.items.some((it) => tooSimilar(it.content, content))) {
        return { content: '生长层里已经有很接近的一条了，不用重复记。' };
      }

      const dailyLimit = Math.max(1, Number(c.dailyLearnLimit) || 3);
      const today = dayKey();
      if (d.learnDay !== today) {
        d.learnDay = today;
        d.learnCount = 0;
      }
      if (d.learnCount >= dailyLimit) {
        return { content: `今天已经长了 ${d.learnCount} 条，到上限了（每天 ${dailyLimit} 条）。明天再说。` };
      }

      const item = {
        id: newId(),
        category,
        content,
        evidence: String(args.evidence || '').slice(0, 200),
        createdAt: now(),
        chatKey: String(ctx?.chatKey || ''),
        hits: 0
      };
      d.items.push(item);
      d.learnCount += 1;
      d.lastLearnAt = now();

      const maxItems = Math.max(8, Math.min(200, Number(c.maxItems) || 40));
      while (d.items.length > maxItems) d.items.shift();

      save(d);
      log(`长出一条新的人设：[${category}] ${content}`);
      return { content: `记下了：[${category}] ${content}（今天第 ${d.learnCount}/${dailyLimit} 条）` };
    }
  });

  // ── 3. 问对方希望怎么改 ──────────────────────────────────
  api.registerTool({
    id: 'ask',
    name: '问对方希望怎么改',
    description: '当对方对你的回答明显不满意（说「不像你」「不对」「重说」「你变了」），或你想改核心角色卡之前，用它向对方（主人）发消息问清楚希望哪儿不一样。不要在没收到负面反馈时乱用。',
    category: 'messaging',
    icon: '❓',
    parameters: {
      type: 'object',
      properties: {
        question: { type: 'string', description: '要问的话，口语、一句就够（例：那我该怎么说才算像你？给个方向）' },
        target: { type: 'string', description: '发给谁：留空 = 当前会话；private:QQ号 = 私聊某人' }
      },
      required: ['question']
    },
    async execute(ctx, args = {}) {
      const c = cfg() || {};
      const question = String(args.question || '').trim();
      if (!question) return { content: '缺少 question', isError: true };
      if (question.length > 200) return { content: '问题太长，压到 100 字以内', isError: true };

      const cooldown = Math.max(1, Number(c.askCooldownMin) || 60) * 60 * 1000;
      const d = load();
      const pass = now() - (d.lastAskAt || 0);
      if (pass < cooldown) {
        const left = Math.ceil((cooldown - pass) / 60000);
        return { content: `上次问过才 ${Math.floor(pass / 60000)} 分钟，还有 ${left} 分钟冷却。这次先按现有理解回应，别反复追问。` };
      }

      let target = String(args.target || '').trim();
      if (!target) {
        if (ctx?.kind === 'private' && ctx?.chatId) target = `private:${ctx.chatId}`;
        else {
          const owners = ownerIds();
          if (!owners.length) {
            return { content: '当前在群里，且没有配置主人（owner-identity），无法私聊征求意见。改为在群里简短问一句即可。', isError: true };
          }
          target = `private:${owners[0]}`;
        }
      }

      try {
        await ctx.sender.sendTextBatch(target, question);
        d.lastAskAt = now();
        d.lastQuestion = question;
        save(d);
        return { content: `已经把问题发给 ${target} 了。等对方回复后再决定怎么改，别自己先改。` };
      } catch (e) {
        return { content: '发送失败：' + (e?.message || e), isError: true };
      }
    }
  });

  // ── 4. 主人改角色卡正文 ──────────────────────────────────
  api.registerTool({
    id: 'patch',
    name: '把内容追加到角色卡',
    description: '仅主人私聊、且对方明确说「把这条写进人设/设定」时使用：把一段文字追加到角色卡正文末尾。日常成长不要用这个，用 learn 写生长层。',
    category: 'model',
    icon: '✍️',
    parameters: {
      type: 'object',
      properties: {
        text: { type: 'string', description: '要追加的角色设定正文，直接写设定本身（不要写「请把…写进去」）' }
      },
      required: ['text']
    },
    async execute(ctx, args = {}) {
      const c = cfg() || {};
      if (c.allowRolePatch === false) {
        return { content: '主人把「允许改角色卡正文」关掉了，只能写生长层。', isError: true };
      }
      if (ctx?.kind !== 'private') {
        return { content: '改角色卡正文只能在私聊里做（群里容易被人带节奏）。', isError: true };
      }
      const text = String(args.text || '').trim();
      if (!text) return { content: '缺少 text', isError: true };
      if (text.length > 1500) return { content: `太长（${text.length} 字），一次别超过 1500 字`, isError: true };

      const cfgNow = getConfig() || {};
      const role = String(cfgNow.persona?.roleText || '');
      if (role.includes(text)) return { content: '角色卡里已经有这段了，不用重复追加。' };

      const next = role + ROLE_APPEND_HEADER + text;
      try {
        updateConfig({ persona: { ...(cfgNow.persona || {}), roleText: next } });
        log(`角色卡正文追加了 ${text.length} 字`);
        return { content: `已追加到角色卡正文（现在 ${next.length} 字）。这部分会从下一轮开始生效。` };
      } catch (e) {
        return { content: '写入失败：' + (e?.message || e), isError: true };
      }
    }
  });

  // ── 5. 删掉一条 ──────────────────────────────────────────
  api.registerTool({
    id: 'forget',
    name: '删掉一条人设成长',
    description: '当某条生长记录不对、过时，或对方明确否认时使用。可以按序号（先用 view 查看）或按关键词删除。',
    category: 'memory',
    icon: '🧽',
    parameters: {
      type: 'object',
      properties: {
        index: { type: 'number', description: '要删除的序号，从 1 开始（用 view 查看）' },
        keyword: { type: 'string', description: '或按关键词匹配删除' }
      }
    },
    async execute(ctx, args = {}) {
      const d = load();
      if (!d.items.length) return { content: '生长层是空的，没得删。' };

      let before = d.items.length;
      if (Number.isFinite(Number(args.index))) {
        const i = Number(args.index) - 1;
        if (i < 0 || i >= d.items.length) return { content: `序号超出范围（1~${d.items.length}）`, isError: true };
        d.items.splice(i, 1);
      } else if (args.keyword) {
        const kw = String(args.keyword).trim();
        d.items = d.items.filter((it) => !String(it.content).includes(kw));
        if (d.items.length === before) return { content: `没有找到含「${kw}」的记录。` };
      } else {
        return { content: '要删哪条？给 index 或 keyword', isError: true };
      }

      save(d);
      return { content: `已删除 ${before - d.items.length} 条，剩 ${d.items.length} 条。` };
    }
  });

  log('人设生长已加载');
}
