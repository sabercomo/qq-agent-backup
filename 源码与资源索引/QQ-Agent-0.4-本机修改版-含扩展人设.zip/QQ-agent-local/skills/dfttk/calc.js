/**
 * calc.js —— 调 dfttk 网站自己的"智能配枪 / TTK 计算"（window.DFTTK_AI）
 *
 * ── 为什么必须开浏览器 ─────────────────────────────────────────────────
 *   站点明确写了：需要浏览器 + Web Worker；`/api/*` 全部 410，没有 HTTP 接口。
 *   实测（2026-10-20）：无头 Edge + CDP 打开 https://dfttk.com/ai/calculator，
 *   等 `window.DFTTK_AI` 出现后调 calculate() 就能拿到结果，约 5~8 秒。
 *
 * ── 超时（按需求加的）──────────────────────────────────────────────────
 *   总上限默认 **8 分钟**：到点无论浏览器卡在哪一步，都强杀进程并返回"配枪失败"，
 *   绝不让群友一直干等。分阶段也有上限：启浏览器 25s、页面就绪 60s、计算 120s。
 *
 * ── 返回 ───────────────────────────────────────────────────────────────
 *   { ok:true, text } 或 { ok:false, reason }（绝不编数据，失败就说失败）
 */
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const CALC_URL = 'https://dfttk.com/ai/calculator';
const BROWSER_CANDIDATES = [
  '/usr/bin/chromium',
  path.join(process.env['ProgramFiles(x86)'] || '', 'Microsoft/Edge/Application/msedge.exe'),
  path.join(process.env['ProgramFiles'] || '', 'Microsoft/Edge/Application/msedge.exe'),
  path.join(process.env['ProgramFiles'] || '', 'Google/Chrome/Application/chrome.exe'),
  path.join(process.env['ProgramFiles(x86)'] || '', 'Google/Chrome/Application/chrome.exe'),
  path.join(process.env.LOCALAPPDATA || '', 'Google/Chrome/Application/chrome.exe')
];

// 单次计算放宽到 7 分钟：站点计算器在复杂配装/网络慢时确实会拖很久（用户实测反馈），
// 总闸仍是 8 分钟 —— 到点强杀浏览器并报"配枪失败"。
const PHASE = { browserMs: 25000, readyMs: 60000, calcMs: 7 * 60 * 1000 };
export const DEFAULT_TOTAL_MS = 8 * 60 * 1000;   // ← 需求：超过 8 分钟就取消并告知失败

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const findBrowser = (override) => {
  if (override && fs.existsSync(override)) return override;
  for (const p of BROWSER_CANDIDATES) if (p && fs.existsSync(p)) return p;
  return null;
};

/** 极简 CDP 客户端：走 `--remote-debugging-pipe`（fd 3 写、fd 4 读，消息以 \0 分隔）。
 *
 *  为什么不用 WebSocket：应用主进程（Electron 的 Node）**没有全局 WebSocket**，
 *  实测线上报 "WebSocket is not defined"。pipe 模式只依赖 child_process 的 stdio，
 *  任何 Node 版本都能跑，也不用开本地端口。
 */
function makePipeCdp(proc) {
  const toBrowser = proc.stdio[3];
  const fromBrowser = proc.stdio[4];
  const pending = new Map();
  let seq = 0;
  let closed = false;
  let buf = Buffer.alloc(0);

  const onData = (chunk) => {
    buf = Buffer.concat([buf, chunk]);
    let i;
    while ((i = buf.indexOf(0)) >= 0) {
      const raw = buf.subarray(0, i).toString('utf8');
      buf = buf.subarray(i + 1);
      if (!raw.trim()) continue;
      let msg;
      try { msg = JSON.parse(raw); } catch { continue; }
      if (msg.id != null && pending.has(msg.id)) {
        const h = pending.get(msg.id);
        pending.delete(msg.id);
        clearTimeout(h.timer);
        msg.error ? h.reject(new Error(msg.error.message || 'CDP 报错')) : h.resolve(msg.result);
      }
    }
  };
  fromBrowser.on('data', onData);
  fromBrowser.on('error', () => { closed = true; });
  proc.on('exit', () => {
    closed = true;
    for (const [id, h] of pending) { clearTimeout(h.timer); h.reject(new Error('浏览器进程已退出')); pending.delete(id); }
  });

  const call = (method, params = {}, sessionId, timeoutMs = 60000) => new Promise((resolve, reject) => {
    if (closed) return reject(new Error('浏览器进程已退出'));
    const id = ++seq;
    const timer = setTimeout(() => { pending.delete(id); reject(new Error(`${method} 超时`)); }, timeoutMs);
    pending.set(id, { resolve, reject, timer });
    try {
      toBrowser.write(`${JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) })}\0`);
    } catch (e) {
      clearTimeout(timer); pending.delete(id); reject(e);
    }
  });

  return {
    call,
    close() {
      try { fromBrowser.off('data', onData); } catch { /* ignore */ }
      try { toBrowser.end(); } catch { /* ignore */ }
    }
  };
}

/** 启动无头浏览器并连上 CDP（pipe 模式）；返回 { proc, cdp, profile }。 */
async function startBrowser({ exe, timeoutMs = PHASE.browserMs } = {}) {
  const bin = findBrowser(exe);
  if (!bin) return { ok: false, reason: '没找到可用的浏览器（Edge/Chrome）' };
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'dfttk-calc-'));
  let proc;
  try {
    proc = spawn(bin, [
      '--headless=new', '--remote-debugging-pipe', `--user-data-dir=${profile}`,
      ...(process.platform === 'linux' ? ['--no-sandbox', '--disable-dev-shm-usage'] : []),
      ...(process.env.HTTPS_PROXY ? [`--proxy-server=${process.env.HTTPS_PROXY}`] : []),
      '--no-first-run', '--no-default-browser-check', '--disable-gpu', '--disable-extensions',
      '--disable-background-networking', '--window-size=1200,900', 'about:blank'
    ], { stdio: ['ignore', 'ignore', 'ignore', 'pipe', 'pipe'], windowsHide: true });
  } catch (e) {
    return { ok: false, reason: `启动浏览器失败：${e?.message ?? e}` };
  }
  proc.on('error', () => { /* 下面的探活会超时并报错 */ });

  const cdp = makePipeCdp(proc);
  const deadline = Date.now() + timeoutMs;
  let ready = false;
  while (Date.now() < deadline) {
    try { await cdp.call('Browser.getVersion', {}, null, 3000); ready = true; break; } catch { await sleep(400); }
  }
  if (!ready) {
    if (process.platform === 'win32') {
      try { spawn('taskkill', ['/PID', String(proc.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true }); } catch { /* ignore */ }
    } else { proc.kill(); }
    return { ok: false, reason: '浏览器启动超时（CDP pipe 未就绪）' };
  }
  return { ok: true, proc, cdp, profile };
}

function killBrowser(state) {
  if (!state) return;
  try { state.cdp?.close?.(); } catch { /* ignore */ }
  // ⚠️ proc.kill() 只杀启动器，Edge 还会留下 renderer/gpu/crashpad 子进程（实测残留 10 个）。
  //    用 taskkill /T 连整棵进程树一起收，按 PID 精确制导，不误伤用户自己的浏览器。
  const pid = state.proc?.pid;
  try {
    if (pid && process.platform === 'win32') {
      spawn('taskkill', ['/PID', String(pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true });
    } else {
      state.proc?.kill();
    }
  } catch {
    try { state.proc?.kill(); } catch { /* ignore */ }
  }
  setTimeout(() => { try { fs.rmSync(state.profile, { recursive: true, force: true }); } catch { /* ignore */ } }, 1200);
}

/** 打开计算页并等 window.DFTTK_AI 就绪。 */
async function openCalculator(cdp, log) {
  const { targetId } = await cdp.call('Target.createTarget', { url: 'about:blank' });
  const { sessionId } = await cdp.call('Target.attachToTarget', { targetId, flatten: true });
  const S = (method, params = {}, timeoutMs = 30000) => cdp.call(method, params, sessionId, timeoutMs);
  await S('Page.enable');
  await S('Runtime.enable');
  await S('Page.navigate', { url: CALC_URL });

  const deadline = Date.now() + PHASE.readyMs;
  while (Date.now() < deadline) {
    await sleep(500);
    try {
      const r = await S('Runtime.evaluate', { expression: 'typeof window.DFTTK_AI', returnByValue: true }, 10000);
      if (r?.result?.value === 'object') return { ok: true, S };
    } catch { /* 页面还在加载 */ }
  }
  log?.('[dfttk] 计算页 60 秒内没就绪');
  return { ok: false, reason: '站点计算页加载超时（60 秒内 window.DFTTK_AI 没出现）' };
}

const evalJson = async (S, expr, timeoutMs = PHASE.calcMs) => {
  const r = await S('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true }, timeoutMs);
  if (r?.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text || '页面脚本报错');
  return r?.result?.value;
};

const wan = (n) => (Number.isFinite(Number(n)) ? `${(Number(n) / 10000).toFixed(1)}万` : '?');

/** 把 calculate 的返回整理成人话。字段名以站点 /ai/context.json 的 result 契约为准，取不到就跳过。 */
function formatCalc(calc) {
  const lines = [];
  const w = calc?.weapon || {};
  const a = calc?.ammo || {};
  const input = calc?.input || {};
  const res = calc?.result || {};
  const name = w.name || w.weaponId || '未知武器';
  const ammoName = a.name ? `${a.name}（穿透 ${a.penetrationLevel ?? a.penetration ?? '?'}）` : '默认弹药';
  lines.push(`【${name}】弹药 ${ammoName} ｜ 距离 ${input.distanceMeters ?? '?'} 米`);

  const ttk = Number(res.expectedTtkMs);
  const btk = Number(res.expectedBtk ?? res.expectedShots ?? res.shots);
  if (Number.isFinite(ttk)) lines.push(`期望 TTK：${(ttk / 1000).toFixed(2)} 秒`);
  if (Number.isFinite(btk)) lines.push(`期望击杀弹数：${btk.toFixed(2)} 发`);

  const dist = Array.isArray(res.ttkDistribution) ? res.ttkDistribution : null;
  if (dist && dist.length) {
    const sec = (ms) => (Number(ms) / 1000).toFixed(2);
    const top = dist.slice(0, 3).map((d) => `${d.probability != null ? (Number(d.probability) * 100).toFixed(0) + '% → ' : ''}${sec(d.ttkMs)}秒`);
    lines.push(`分布：${top.join(' ｜ ')}`);
  }
  if (!lines.some((l) => /TTK|弹数/.test(l))) {
    const keys = Object.keys(res).slice(0, 12).join(', ');
    lines.push(`（站点返回的字段：${keys || '空'}）`);
  }
  return lines.join('\n');
}

/**
 * 调站点算一次。总超时默认 8 分钟。
 * @returns {{ok:true, text:string, ms:number} | {ok:false, reason:string, timedOut?:boolean, ms?:number}}
 */
export async function calculateOnSite({ weapon, distance = 30, ammo = '', timeoutMs = DEFAULT_TOTAL_MS, browserExe = '', log = null } = {}) {
  const t0 = Date.now();
  // 下限只留 1 秒（够测试强制触发；正式调用永远是 8 分钟）
  const totalMs = Math.max(1000, Number(timeoutMs) || DEFAULT_TOTAL_MS);
  const totalLabel = totalMs >= 60000 ? `${Math.round(totalMs / 60000)} 分钟` : `${(totalMs / 1000).toFixed(1)} 秒`;
  let state = null;
  let finished = false;

  // 总闸：到点强杀浏览器并返回失败
  const watchdog = new Promise((resolve) => {
    setTimeout(() => {
      if (!finished) resolve({ ok: false, timedOut: true, reason: `配枪超时（超过 ${totalLabel}），已自动取消` });
    }, totalMs);
  });

  const work = (async () => {
    const q = String(weapon ?? '').trim();
    if (!q) return { ok: false, reason: '没给枪名' };
    state = await startBrowser({ exe: browserExe });
    if (!state.ok) return { ok: false, reason: state.reason };
    log?.('[dfttk] 浏览器已启动，打开计算页…');

    const page = await openCalculator(state.cdp, log);
    if (!page.ok) return { ok: false, reason: page.reason };
    const S = page.S;

    const found = await evalJson(S, `window.DFTTK_AI.searchWeapons({ mode:"sol", query:${JSON.stringify(q)}, limit:5 })`);
    const list = Array.isArray(found) ? found : [];
    if (!list.length) return { ok: false, reason: `站点里没有搜到「${q}」` };
    const pick = list[0];
    log?.(`[dfttk] 匹配到 ${pick.name}（${pick.weaponId}）`);

    const expr = `window.DFTTK_AI.calculate({ mode:"sol", sourceType:"v3Official", weaponId:${JSON.stringify(pick.weaponId)}, distanceMeters:${Number(distance) || 30}${ammo ? `, ammoItemId:${JSON.stringify(String(ammo))}` : ''} })`;
    const calc = await evalJson(S, expr);
    if (!calc || calc.ok === false) return { ok: false, reason: `站点计算失败：${calc?.status?.message || '未知原因'}` };
    return { ok: true, text: formatCalc(calc), ms: Date.now() - t0 };
  })();

  const raced = await Promise.race([work.catch((e) => ({ ok: false, reason: String(e?.message ?? e) })), watchdog]);
  finished = true;
  killBrowser(state);
  return raced;
}

/** 把 compare 的返回整理成人话。
 *  实测站点结构（2026-10-20）：
 *  { configs:N, distancesMeters:[30], rows:[{ configIndex, configId, label, configSnapshot, distanceMeters,
 *    calculation:{ ok, status, weapon:{name}, ammo:{name,penetrationLevel}, result:{ expectedTtkMs, expectedBtk, ttkDistribution } } }] }
 */
function formatCompare(res, names, distance) {
  const lines = [`【两枪对比 · 距离 ${distance} 米】`];
  const rows = Array.isArray(res?.rows) ? res.rows : (Array.isArray(res?.results) ? res.results : null);
  if (rows && rows.length) {
    for (const row of rows) {
      const calc = row?.calculation || row;
      const w = calc?.weapon || row?.config?.weapon || {};
      const a = calc?.ammo || {};
      const r = calc?.result || calc || {};
      const name = w.name || row?.label || w.weaponId || '?';
      const ttk = Number(r.expectedTtkMs);
      const btk = Number(r.expectedBtk ?? r.expectedShots);
      const parts = [];
      parts.push(`· ${name}${a.name ? `（${a.name} 穿透${a.penetrationLevel ?? '?'}）` : ''}`);
      parts.push(`   期望 TTK ${Number.isFinite(ttk) ? (ttk / 1000).toFixed(2) + ' 秒' : '?'} ｜ 击杀弹数 ${Number.isFinite(btk) ? btk.toFixed(2) : '?'} 发`);
      lines.push(parts.join('\n'));
    }
    // 谁更快
    const scored = rows.map((row) => {
      const r = (row?.calculation || row)?.result || {};
      return { name: (row?.calculation || row)?.weapon?.name || row?.label || '?', ttk: Number(r.expectedTtkMs) };
    }).filter((x) => Number.isFinite(x.ttk)).sort((a, b) => a.ttk - b.ttk);
    if (scored.length >= 2) {
      const [best, second] = scored;
      const diff = (second.ttk - best.ttk) / 1000;
      const btkOf = (name) => {
        const row = rows.find((rw) => ((rw?.calculation || rw)?.weapon?.name || rw?.label) === name);
        const c = row?.calculation || row;
        return Number(c?.result?.expectedBtk);
      };
      lines.push('');
      if (diff < 0.005) {
        const a = btkOf(best.name);
        const b = btkOf(second.name);
        lines.push(`→ TTK 打平（都是 ${(best.ttk / 1000).toFixed(3)} 秒）`
          + (Number.isFinite(a) && Number.isFinite(b) ? `；击杀弹数 ${a.toFixed(2)} vs ${b.toFixed(2)} 发` : ''));
      } else {
        lines.push(`→ ${best.name} 快 ${diff.toFixed(3)} 秒（${(best.ttk / 1000).toFixed(3)}s vs ${(second.ttk / 1000).toFixed(3)}s）`);
      }
    }
  } else {
    lines.push(`（站点返回字段：${Object.keys(res || {}).slice(0, 12).join(', ') || '空'}）`);
    lines.push(String(JSON.stringify(res)).slice(0, 600));
  }
  return lines.join('\n');
}

/**
 * 两把（最多四把）枪同距离对比 —— 走站点的 compare，一次请求全算。
 * @returns {{ok:true, text:string, ms:number} | {ok:false, reason:string, timedOut?:boolean}}
 */
export async function compareOnSite({ weapons = [], distance = 30, ammoMap = {}, timeoutMs = DEFAULT_TOTAL_MS, browserExe = '', log = null } = {}) {
  const t0 = Date.now();
  const totalMs = Math.max(1000, Number(timeoutMs) || DEFAULT_TOTAL_MS);
  const totalLabel = totalMs >= 60000 ? `${Math.round(totalMs / 60000)} 分钟` : `${(totalMs / 1000).toFixed(1)} 秒`;
  const names = (Array.isArray(weapons) ? weapons : [weapons]).map((x) => String(x ?? '').trim()).filter(Boolean).slice(0, 4);
  if (names.length < 2) return { ok: false, reason: '对比至少要两把枪' };

  let state = null;
  let finished = false;
  const watchdog = new Promise((resolve) => {
    setTimeout(() => {
      if (!finished) resolve({ ok: false, timedOut: true, reason: `对比超时（超过 ${totalLabel}），已自动取消` });
    }, totalMs);
  });

  const work = (async () => {
    state = await startBrowser({ exe: browserExe });
    if (!state.ok) return { ok: false, reason: state.reason };
    const page = await openCalculator(state.cdp, log);
    if (!page.ok) return { ok: false, reason: page.reason };
    const S = page.S;

    const configs = [];
    for (const n of names) {
      const found = await evalJson(S, `window.DFTTK_AI.searchWeapons({ mode:"sol", query:${JSON.stringify(n)}, limit:5 })`);
      const hit = Array.isArray(found) ? found[0] : null;
      if (!hit) return { ok: false, reason: `站点里没搜到「${n}」` };
      configs.push({
        mode: 'sol',
        sourceType: 'v3Official',
        weaponId: hit.weaponId,
        distanceMeters: Number(distance) || 30,
        ...(ammoMap[n] ? { ammoItemId: String(ammoMap[n]) } : {})
      });
      log?.(`[dfttk] 对比项：${hit.name}（${hit.weaponId}）`);
    }

    const expr = `window.DFTTK_AI.compare({ configs: ${JSON.stringify(configs)}, distancesMeters: [${Number(distance) || 30}] })`;
    const res = await evalJson(S, expr, PHASE.calcMs);
    if (!res) return { ok: false, reason: '站点对比没有返回结果' };
    return { ok: true, text: formatCompare(res, names, Number(distance) || 30), ms: Date.now() - t0 };
  })();

  const raced = await Promise.race([work.catch((e) => ({ ok: false, reason: String(e?.message ?? e) })), watchdog]);
  finished = true;
  killBrowser(state);
  return raced;
}

/** 智能改枪结果块清理：去掉标签栏/按钮，把"纯数字/百分比/增量"贴回上一行。
 *  输入是结果容器的 innerText（实测：值有时单独一行、有时和单位连写，所以两头都要容错）。 */
function cleanBuildBlock(rawText, tab) {
  const lines = String(rawText || '').split('\n').map((l) => l.trim()).filter(Boolean);
  const noise = new Set(['推荐方案', '‹', '›', '应用当前方案', '评分明细', '改装设置', '方案已更新', '更好控枪', '均衡', '上限更高']);
  const out = [];
  let started = false;
  let seenTab = 0;
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    if (!started) {
      if (l === tab) { seenTab++; if (seenTab >= 2) started = true; }
      continue;
    }
    if (l === '应用当前方案') break;
    if (noise.has(l)) continue;
    if (/^(更多属性|评分明细|预算 \d)/.test(l)) continue;
    const unitOnly = /^(m\/s|ms|s|发|°|%|个百分点)$/.test(l);
    const numeric = /^[+\-]?[\d,]+(\.\d+)?\s*(%|m\/s|ms|s|发|°|个百分点)?$/.test(l);
    if ((numeric || unitOnly) && out.length) {
      out[out.length - 1] = `${out[out.length - 1]} ${l}`.replace(/\s+/g, ' ').trim();
      continue;
    }
    out.push(l);
  }
  return out;
}

/** 精校参数翻译：authoring:part:<itemId>:tune:<dim>:<idx> → 「配件名 长度 +10」这种。 */
const TUNE_DIM_CN = { length: '长度', weight: '重量', thickness: '厚度', stiffness: '刚度', balance: '配重', port: '导气孔' };
function formatTunes(tunes, resolvePartName) {
  const out = [];
  for (const obj of Object.values(tunes || {})) {
    for (const [k, v] of Object.entries(obj || {})) {
      const m = /^authoring:part:(\d+):tune:([A-Za-z]+):(\d+)$/.exec(k);
      if (!m) { out.push(`${k}=${v}`); continue; }
      const [, itemId, dim, idx] = m;
      const name = resolvePartName?.(itemId) || `配件 ${itemId}`;
      const dimCN = TUNE_DIM_CN[dim] || dim;
      const num = Number(v);
      const shown = Number.isFinite(num) ? `${num > 0 ? '+' : ''}${num}` : String(v);
      out.push(`${name} ${dimCN} ${shown}`);
    }
  }
  return out;
}

/**
 * 智能改枪（枪械改装页里的「智能改枪（测试）」）。
 *
 * 实测（2026-10-20）：M4A1 / 预算 30 万 / 30 发 → 约 **330 秒**出结果，
 * 给出 3 套方案标签（更好控枪 / 均衡 / 上限更高），每套带总价值、余量、面板变化、配件数。
 * ⚠️ 这条流程**只给配装方案与面板，不给改枪码**；要码得走"应用 → 保存为方案"。
 * ⚠️ 只能点界面（站点没有 JS 接口），改版就会失效。
 *
 * @returns {{ok:true, text:string, ms:number, builds:number} | {ok:false, reason:string, timedOut?:boolean}}
 */
export async function buildOnSite({ budget = 300000, weapon = '', weaponId = '', magazine = 30, breath = false, timeoutMs = 10 * 60 * 1000, browserExe = '', log = null, resolvePartName = null } = {}) {
  const t0 = Date.now();
  const totalMs = Math.max(5000, Number(timeoutMs) || 10 * 60 * 1000);
  const totalLabel = totalMs >= 60000 ? `${Math.round(totalMs / 60000)} 分钟` : `${(totalMs / 1000).toFixed(1)} 秒`;
  const budgetNum = Math.max(1, Math.round(Number(budget) || 300000));
  const mag = [30, 45, 60].includes(Number(magazine)) ? Number(magazine) : 30;

  let state = null;
  let finished = false;
  const watchdog = new Promise((resolve) => {
    setTimeout(() => {
      if (!finished) resolve({ ok: false, timedOut: true, reason: `智能改枪超时（超过 ${totalLabel}），已自动取消` });
    }, totalMs);
  });

  const work = (async () => {
    state = await startBrowser({ exe: browserExe });
    if (!state.ok) return { ok: false, reason: state.reason };

    const { targetId } = await state.cdp.call('Target.createTarget', { url: 'https://dfttk.com/' });
    const { sessionId } = await state.cdp.call('Target.attachToTarget', { targetId, flatten: true });
    const S = (m, p = {}, t = 60000) => state.cdp.call(m, p, sessionId, t);
    await S('Page.enable');
    await S('Runtime.enable');

    const ev = async (e, t = 60000) => {
      const r = await S('Runtime.evaluate', { expression: e, awaitPromise: true, returnByValue: true }, t);
      if (r?.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
      return r?.result?.value;
    };

    // ① 换枪：页面的"编辑哪把枪"由 localStorage 决定（activeWeaponIds.sol）。
    //    先停在站点根域写进去，再进改装页 —— 这样不用点界面就能指定任意武器。
    await sleep(3500);
    if (weaponId) {
      const preset = await ev(`(() => {
        try {
          const KEY = 'dfttk.weaponBuilder.workspaces.v3';
          let ws = {};
          try { ws = JSON.parse(localStorage.getItem(KEY) || '{}'); } catch { ws = {}; }
          ws.schemaVersion = 3;
          ws.activeWeaponIds = ws.activeWeaponIds || {};
          ws.activeWeaponIds.sol = ${JSON.stringify(String(weaponId))};
          ws.workspaces = ws.workspaces || {};
          ws.workspaces.sol = ws.workspaces.sol || {};
          const id = ${JSON.stringify(String(weaponId))};
          ws.workspaces.sol[id] = ws.workspaces.sol[id] || {
            weaponId: id, mode: 'sol', config: [], tunes: {}, tacticalEffective: false,
            sourceLoadoutId: null, sourceLoadoutRevision: null, sourceLoadoutName: null,
            dataVersion: null, updatedAt: new Date().toISOString()
          };
          localStorage.setItem(KEY, JSON.stringify(ws));
          return ws.activeWeaponIds.sol;
        } catch (e) { return 'ERR:' + (e?.message ?? e); }
      })()`);
      log?.(`[dfttk] 已指定武器 ${weapon || weaponId}（localStorage: ${preset}）`);
    }
    await S('Page.navigate', { url: 'https://dfttk.com/firefight/builder' });
    const clickAt = async (x, y) => {
      await S('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1 });
      await S('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1 });
    };
    const locate = async (txt, exact = true) => ev(`(() => {
      const els = [...document.querySelectorAll('button,[role="button"],div,span,li')].filter((e) => {
        const t = (e.textContent || '').trim();
        return ${exact ? `t === ${JSON.stringify(txt)}` : `t.includes(${JSON.stringify(txt)})`} && e.children.length <= 2;
      });
      if (!els.length) return null;
      els[0].scrollIntoView({ block: 'center', inline: 'center' });
      const r = els[0].getBoundingClientRect();
      return { x: r.x + r.width / 2, y: r.y + r.height / 2 };
    })()`);
    const clickText = async (txt, exact = true) => {
      const p = await locate(txt, exact);
      if (!p) return false;
      await clickAt(p.x, p.y);
      return true;
    };

    // ① 等页面就绪（出现「智能改枪」按钮）
    let ready = false;
    for (let i = 0; i < 40; i++) {
      await sleep(500);
      if (await ev(`document.body.innerText.includes('智能改枪')`)) { ready = true; break; }
    }
    if (!ready) return { ok: false, reason: '改装页 20 秒内没加载出来' };
    log?.('[dfttk] 改装页已就绪，关闭公告并打开智能改枪…');

    // ②③ 关公告 + 打开「智能改枪」弹窗（DOM 直点 / 真鼠标点击交替，最多 5 轮）
    const closeModals = () => ev(`(() => {
      let n = 0;
      for (const e of document.querySelectorAll('button,div,span')) {
        const t = (e.textContent || '').trim();
        if (/^(知道了|关闭|×|✕|稍后再说)$/.test(t) && e.offsetParent !== null) { try { e.click(); n++; } catch { /* ignore */ } }
      }
      return n;
    })()`);
    const dialogOpen = () => ev(`(() => { const i = document.querySelector('input.weapon-builder-auto-number-input'); return !!i && i.offsetParent !== null; })()`);
    let opened = false;
    for (let round = 0; round < 5 && !opened; round++) {
      await closeModals();
      // 先试 DOM 直点（不怕遮罩层挡鼠标）
      const dom = await ev(`(() => {
        const b = [...document.querySelectorAll('button,[role="button"]')].find((e) => (e.textContent || '').trim() === '智能改枪');
        if (!b) return 'no-btn';
        b.scrollIntoView({ block: 'center' });
        b.click();
        return 'dom-clicked';
      })()`);
      if (dom === 'no-btn') log?.('[dfttk] 页面上没找到「智能改枪」按钮');
      await sleep(1500);
      opened = await dialogOpen();
      if (!opened) {
        await clickText('智能改枪');       // 再试真鼠标点击
        for (let i = 0; i < 8 && !opened; i++) { await sleep(500); opened = await dialogOpen(); }
      }
    }
    if (!opened) return { ok: false, reason: '「智能改枪」弹窗没打开（可能被公告遮挡或站点改版），可以稍后重试' };

    // ④ 设预算 / 弹容量 / 屏息
    await ev(`(() => {
      const inp = document.querySelector('input.weapon-builder-auto-number-input');
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
      setter.call(inp, ${JSON.stringify(String(budgetNum))});
      inp.dispatchEvent(new Event('input', { bubbles: true }));
      inp.dispatchEvent(new Event('change', { bubbles: true }));
    })()`);
    await sleep(400);
    await clickText(`${mag} 发`);
    if (breath) {
      await ev(`(() => {
        const cb = document.querySelector('input[type="checkbox"]');
        if (cb && !cb.checked) cb.click();
      })()`);
    }
    await sleep(400);
    if (!(await clickText('生成推荐方案'))) return { ok: false, reason: '没找到「生成推荐方案」按钮' };
    log?.(`[dfttk] 已提交：预算 ${budgetNum} / ${mag} 发，开始等待（可能要 3~6 分钟）`);

    // ⑤ 等算完：页面出现"正在搜索配装"就继续等；消失即完成
    const waitUntil = Date.now() + totalMs;
    let sawSearching = false;
    let lastPct = null;
    while (Date.now() < waitUntil) {
      await sleep(5000);
      const st = JSON.parse(String(await ev(`(() => {
        const t = document.body.innerText;
        return JSON.stringify({
          searching: t.includes('正在搜索配装'),
          pct: (/(\\d+)%/.exec(t) || [])[1] || null
        });
      })()`)));
      if (st.searching) { sawSearching = true; lastPct = st.pct; continue; }
      if (sawSearching) break;              // 曾经在算 → 现在不在了 = 算完
      if (await ev(`document.body.innerText.includes('推荐方案')`)) break;
      lastPct = st.pct;
    }
    const waited = Math.round((Date.now() - t0) / 1000);
    if (!(await ev(`document.body.innerText.includes('推荐方案')`))) {
      return { ok: false, reason: `等了 ${waited} 秒还没出结果${lastPct ? `（最后进度 ${lastPct}%）` : ''}` };
    }
    log?.(`[dfttk] 智能改枪完成，用时约 ${waited} 秒`);

    // ⑥ 收集结果：先拿标签页名，再逐个点开读摘要
    const tabNames = await ev(`(() => {
      const t = document.body.innerText;
      const i = t.indexOf('推荐方案');
      if (i < 0) return [];
      const known = ['更好控枪', '均衡', '上限更高'];
      const seg = t.slice(i, i + 400);
      return known.filter((k) => seg.includes(k));
    })()`);

    // ⚠️ 不能只取"结果容器"的 innerText：面板变化（后坐力控制 +41 等）在它的**兄弟节点**里。
    //    取整页 innerText 的「推荐方案 → 应用当前方案」区间才能把明细一起拿到。
    const readPanelText = async () => ev(`(() => {
      const t = document.body.innerText || '';
      const a = t.indexOf('推荐方案');
      if (a < 0) return '';
      const b = t.indexOf('应用当前方案', a);
      return t.slice(a, b > a ? b : Math.min(t.length, a + 4000));
    })()`);

    // 面板变化（后坐力控制 +41 等）渲染在隐藏节点里：innerText 拿不到，用叶子节点 textContent 补抓。
    // 只取这 4 个主属性（枪口初速/射速/弹容量 正文里已有，硬抓会抓到隔壁数字）。
    const readPanelDetail = async () => ev(`(() => {
      const names = ['后坐力控制','操控速度','据枪稳定性','腰际射击精度'];
      const leaves = [...document.querySelectorAll('*')]
        .filter((e) => e.children.length === 0 && (e.textContent || '').trim())
        .map((e) => (e.textContent || '').trim());
      const out = [];
      for (const n of names) {
        const i = leaves.lastIndexOf(n);
        if (i < 0) continue;
        const vals = [];
        for (let j = i + 1; j < Math.min(leaves.length, i + 5); j++) {
          const v = leaves[j];
          if (/^[+\\-]?[\\d,.]+(%|ms|m\\/s|发)?$/.test(v) || /^\\([+\\-]?[\\d,.]+(%|ms)?\\)$/.test(v)) vals.push(v);
          else if (vals.length) break;
        }
        if (vals.length) out.push(n + '：' + vals.slice(0, 3).join(' '));
      }
      return out;
    })()`);

    const sections = [];
    const tabs = Array.isArray(tabNames) && tabNames.length ? tabNames : ['更好控枪'];
    /** 切到某个方案标签，并**确认真的选中了**（读出来的块以该标签名开头）；DOM 直点与真点击交替。 */
    const selectTab = async (tab) => {
      for (let i = 0; i < 3; i++) {
        await ev(`(() => {
          const b = [...document.querySelectorAll('button,[role="button"],div,span')]
            .find((e) => (e.textContent || '').trim() === ${JSON.stringify(tab)} && e.children.length <= 2);
          if (b) { b.scrollIntoView({ block: 'center' }); b.click(); }
        })()`);
        await sleep(1000);
        if (cleanBuildBlock(await readPanelText(), tab).length) return true;
        await clickText(tab);
        await sleep(1100);
        if (cleanBuildBlock(await readPanelText(), tab).length) return true;
      }
      return false;
    };

    for (const tab of tabs) {
      const selected = await selectTab(tab);
      const lines = selected ? cleanBuildBlock(await readPanelText(), tab) : [];
      const detail = selected ? await readPanelDetail() : [];
      const extra = (Array.isArray(detail) ? detail : []).filter((d) => !lines.some((l) => l.startsWith(d.split('：')[0])));
      if (lines.length) sections.push({ tab, lines: [...lines, ...extra] });
    }

    if (!sections.length) {
      return { ok: false, reason: '算完了但结果区没读到内容（站点结构可能变了）' };
    }
    // ⑦ 点「应用当前方案」，让改装页把槽位填上 → 读回配件名 + 精校
    //    槽位装好后的 DOM 形态是：[配件名] [槽位名] [×]   ← 配件名在槽位名**前面**
    //    精校（tunes）从 localStorage['dfttk.weaponBuilder.workspaces.v3'] 读（结构化）
    const SLOT_NAMES = ['瞄准镜', '侧瞄具', '导轨脚架', '前握把', '弹匣', '弹匣座', '后握把', '枪口', '枪管', '枪托套件', '枪托', '上导轨', '左导轨', '右导轨', '上贴片', '左贴片', '右贴片'];
    // ⑧ 逐套「应用当前方案」→ 从 localStorage 读精确的 config(itemId) 与 tunes(精校)
    //    ⚠️ 应用后弹窗可能自动关闭，所以每次先确认弹窗在，再点标签页和应用。
    //    配件类别 → 中文槽位名
    const CAT_CN = {
      barrel: '枪管', muzzle: '枪口', magazine: '弹匣', magazineWell: '弹匣座',
      foregrip: '前握把', rearGrip: '后握把', stock: '枪托', stockKit: '枪托套件',
      sight: '瞄准镜', sideSight: '侧瞄具', bipod: '导轨脚架',
      topRail: '上导轨', leftRail: '左导轨', rightRail: '右导轨',
      topPad: '上贴片', leftPad: '左贴片', rightPad: '右贴片', laser: '镭射'
    };
    const readBuiltConfig = () => ev(`(() => {
      try {
        const raw = localStorage.getItem('dfttk.weaponBuilder.workspaces.v3');
        if (!raw) return null;
        const ws = JSON.parse(raw);
        const wid = ws?.activeWeaponIds?.sol;
        const cur = ws?.workspaces?.sol?.[wid];
        if (!cur) return null;
        return { config: cur.config || [], tunes: cur.tunes || null, updatedAt: cur.updatedAt || '' };
      } catch { return null; }
    })()`);

    /** 变化判定要把精校也算进去：有的方案配件完全相同，只有 tunes 不同。 */
    const keyOf = (got) => JSON.stringify([got?.config || [], got?.tunes || {}]);

    /** 应用某一套并**等状态真的变了**才算成功（最多 3 次尝试，每次轮询 8 秒）。 */
    const applyOne = async (tab) => {
      const before = keyOf(await readBuiltConfig());
      const dialogVisible = async () => ev(`(() => { const i = document.querySelector('input.weapon-builder-auto-number-input'); return !!i && i.offsetParent !== null; })()`);
      for (let attempt = 0; attempt < 3; attempt++) {
        if (!(await dialogVisible())) { await clickText('智能改枪'); await sleep(2200); }
        await selectTab(tab);
        await sleep(600);
        await clickText('应用当前方案');
        await ev(`(() => { const b = [...document.querySelectorAll('button,[role="button"]')].find((e) => /^(确定|确认|覆盖|继续|替换)$/.test((e.textContent || '').trim())); if (b) b.click(); })()`);
        const deadline = Date.now() + 8000;
        while (Date.now() < deadline) {
          await sleep(600);
          const g = await readBuiltConfig();
          if (g?.config?.length && keyOf(g) !== before) return true;
        }
        log?.(`[dfttk] 「${tab}」应用第 ${attempt + 1} 次没生效，重试…`);
      }
      return false;
    };

    let prevSec = null;
    for (const sec of sections) {
      const applied = await applyOne(sec.tab);
      const got = await readBuiltConfig();
      sec.applied = applied;
      if (applied && got?.config?.length) {
        sec.parts = got.config.map((c) => {
          const info = resolvePartName?.(c.itemId) || {};
          const slot = CAT_CN[info.category] || '';
          const nm = info.name || c.itemId;
          return slot ? `${slot}：${nm}` : nm;
        });
        sec.tunesRaw = got.tunes || null;
      } else if (prevSec?.parts) {
        // 站点这套配置与上一套完全相同（应用后状态无变化）→ 沿用上一套，并标注清楚
        sec.parts = prevSec.parts;
        sec.tunesRaw = prevSec.tunesRaw;
        sec.reusedFrom = prevSec.tab;
      } else {
        sec.parts = null;
        sec.tunesRaw = null;
      }
      prevSec = sec;
    }

    /** 同名配件合并计数（护木片常见 ×5）。 */
    const compressParts = (items) => {
      const counts = new Map();
      for (const it of items) counts.set(it, (counts.get(it) || 0) + 1);
      return [...counts.entries()].map(([k, n]) => (n > 1 ? `${k} ×${n}` : k));
    };

    // 输出顺序：**配件清单 + 精校放最前面**（模型最容易照着念，也不怕长文本被截断），面板细节放后面
    const body = sections.map((s) => {
      const head = [];
      const tag = s.reusedFrom ? `（与「${s.reusedFrom}」配置相同）` : '';
      if (s.parts && s.parts.length) head.push(`配件${tag}（${s.parts.length} 件）：` + compressParts(s.parts).join(' ｜ '));
      else head.push('配件：没读到（站点没把方案应用上，可重试）');
      const tuneLines = formatTunes(s.tunesRaw, (id) => resolvePartName?.(id)?.name || '');
      head.push(tuneLines.length ? (`精校${tag}：` + tuneLines.join(' ｜ ')) : '精校：无（这套没做精校调整）');
      return [`▸ ${s.tab}`, ...head.map((l) => `  ${l}`), ...s.lines.map((l) => `  ${l}`)].join('\n');
    }).join('\n\n');
    const text = [
      `【智能改枪 · ${weapon || 'M4A1'}】预算 ${(budgetNum / 10000).toFixed(0)}万 ｜ ${mag} 发 ｜ ${breath ? '全程屏息' : '不屏息'}`,
      `算出 ${sections.length} 套方案（用时约 ${waited} 秒）—— 下面是完整结果：`,
      '',
      body,
      '',
      '（数据来自 dfttk.com 的"智能改枪（测试）"页面。这张表就是全部数据，同一预算下不必重复调用；⚠️ 只给配置与精校，不给改枪码 —— 要码用 recommend）'
    ].join('\n');
    return { ok: true, text, ms: Date.now() - t0, builds: sections.length };
  })();

  const raced = await Promise.race([work.catch((e) => ({ ok: false, reason: String(e?.message ?? e) })), watchdog]);
  finished = true;
  killBrowser(state);
  return raced;
}

export const internals = { findBrowser, startBrowser, openCalculator, formatCalc, formatCompare, compareOnSite, buildOnSite, cleanBuildBlock, CALC_URL, DEFAULT_TOTAL_MS, PHASE, wan };
