// 狗头军师 —— 语音版适配：把 Codex skill 的知识库接成 QQ Agent 的一个检索工具
// 原仓库：https://github.com/shengjidaguai-china/goutoujunshi （SKILL.md + references/）
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const SKILL_ID = 'goutoujunshi';

let cfg = () => ({});
let log = () => {};

const TEXT_EXT = new Set(['.md', '.txt', '.yaml', '.yml', '.json']);

function safeResolve(rel) {
  const p = path.resolve(ROOT, String(rel || ''));
  if (p !== ROOT && !p.startsWith(ROOT + path.sep)) throw new Error('路径越界，只允许读技能自己的文件');
  return p;
}

function collect(dir, out = []) {
  let entries = [];
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return out; }
  for (const e of entries) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) collect(full, out);
    else if (e.isFile() && TEXT_EXT.has(path.extname(e.name).toLowerCase())) out.push(full);
  }
  return out;
}

function relList() {
  const files = collect(path.join(ROOT, 'references'));
  files.push(path.join(ROOT, 'SKILL.md'));
  return files.map((f) => ({ rel: path.relative(ROOT, f), size: (() => { try { return fs.statSync(f).size; } catch { return 0; } })() }));
}

function doList() {
  const files = relList();
  const groups = new Map();
  for (const f of files) {
    const key = f.rel.startsWith('references/') ? f.rel.split('/').slice(0, 2).join('/') : '其它';
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(f.rel.replace(/^references\//, ''));
  }
  const lines = [`共 ${files.length} 个文件（用 action=read 传相对路径读取，action=search 搜关键词）：`];
  for (const [k, arr] of groups) {
    lines.push(`\n【${k}】`);
    for (const r of arr) lines.push('· ' + r);
  }
  return lines.join('\n');
}

function doRead(rel, maxChars) {
  const p = safeResolve(rel);
  if (!fs.existsSync(p) || !fs.statSync(p).isFile()) throw new Error(`没有这个文件：${rel}`);
  const text = fs.readFileSync(p, 'utf8');
  const limit = Math.max(1000, Number(maxChars) || 8000);
  return text.length > limit
    ? text.slice(0, limit) + `\n\n…(已截断，原文 ${text.length} 字，可用 action=search 定位关键段)`
    : text;
}

function doSearch(q, hits) {
  const kw = String(q || '').trim();
  if (!kw) throw new Error('search 需要 query');
  const limit = Math.max(1, Math.min(12, Number(hits) || 6));
  const found = [];
  for (const f of relList()) {
    const rel = f.rel;
    if (!rel.startsWith('references/')) continue;
    let text = '';
    try { text = fs.readFileSync(safeResolve(rel), 'utf8'); } catch { continue; }
    const lines = text.split('\n');
    for (let i = 0; i < lines.length; i++) {
      if (!lines[i].includes(kw)) continue;
      const from = Math.max(0, i - 1);
      const snippet = lines.slice(from, Math.min(lines.length, i + 2)).join(' ').slice(0, 220);
      found.push(`[${rel}:${i + 1}] ${snippet}`);
      if (found.length >= limit) return '命中（按出现顺序）：\n' + found.join('\n');
      break; // 每个文件只取第一处，命中面更广
    }
  }
  return found.length ? '命中：\n' + found.join('\n') : `没搜到「${kw}」，换个更短的关键词试试，或者 action=list 看目录。`;
}

export function setup(api) {
  cfg = (api && api.config) || cfg;
  log = (api && api.log) || log;

  api.registerTool({
    id: 'goutoujunshi_kb',
    name: '狗头军师知识库',
    description: '查狗头军师的知识库（20 篇心理学 + 23 篇实务手册：依恋、沟通冲突、边界与同意、分手修复、婚姻家庭、法律安全转介等）。'
      + 'action=list 看全部文件；action=read 传 path 读具体文件；action=search 传 query 搜关键词（推荐先 search，命中后再 read）。'
      + '只有真需要依据时才查，别为了查而查。',
    category: 'utility',
    icon: '🐶',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['list', 'read', 'search'], description: 'list=看目录；read=读文件；search=搜关键词' },
        path: { type: 'string', description: 'read 时的相对路径，如 references/knowledge/03-依恋理论与情绪调节.md' },
        query: { type: 'string', description: 'search 时的关键词，尽量短，如「回避型」「冷战」「边界」' },
        maxChars: { type: 'integer', description: 'read 时最多返回多少字符，默认按设置' }
      },
      required: ['action']
    },
    async execute(ctx, args) {
      try {
        const conf = cfg() || {};
        if (conf.enabled === false) return { content: '狗头军师技能被关掉了。', isError: true };
        const action = String((args && args.action) || 'list').toLowerCase();
        if (action === 'list') return { content: doList() };
        if (action === 'read') return { content: doRead(args.path, args.maxChars ?? conf.maxReadChars) };
        if (action === 'search') return { content: doSearch(args.query, conf.maxSearchHits) };
        return { content: `不认识的 action：${action}`, isError: true };
      } catch (error) {
        const msg = String((error && error.message) || error);
        log(`狗头军师知识库出错：${msg}`);
        return { content: `知识库查询失败：${msg}`, isError: true };
      }
    }
  });

  log(`狗头军师已注册（知识库 ${relList().length} 个文件，检索工具 goutoujunshi_kb）`);
}

export function available() {
  try {
    const n = relList().length;
    if (!n) return { ok: false, reason: '知识库文件缺失（references 目录为空）' };
    return { ok: true };
  } catch (error) {
    return { ok: false, reason: `知识库读取失败：${String((error && error.message) || error)}` };
  }
}
