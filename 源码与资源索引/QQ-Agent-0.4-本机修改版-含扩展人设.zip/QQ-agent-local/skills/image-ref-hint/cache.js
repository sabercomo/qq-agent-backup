// 图片本地缓存 —— 修「隔几分钟就看不见图」的根因。
//
// ── 实测故障（复现过程）────────────────────────────────────────────────────
// 用户反馈"机器人识图不准确"。实测 QQ 图床的下载 url **几分钟就失效**：
//   刚收到不久的图重测 HTTP 200（成功）；过几分钟再测，同一张图 HTTP 400。
// 把最近 16 张图（7~42 分钟前）全部重测一遍：**16 张全 400**。
// 也就是说这张 url 的有效期在 **7 分钟以内**，而且是**一次性/短时**的。
//
// 后果（为什么表现为"识图不准"）：
//   · 机器人看图走 get_message_images → 现场下载 url。
//   · 消息刚到时能下（所以"当场问"经常是对的）；
//   · 只要它晚一步回头看（群聊刷得快、活跃期里回头补看、被 @ 的文字消息来晚了几分钟），
//     url 已经死了 → 工具报"图片获取失败" → 模型看不到图却已经开口，
//     于是退回猜/编 —— 在群友眼里就是"识图不准确"。
//   同一条消息的旧图更惨：它只会在提示里看到 `#id`，根本不知道自己看不到。
//
// ── 解法 ───────────────────────────────────────────────────────────────────
// 图片一开始到达（url 还活着）就**顺手存一份到本地**，之后永远读本地。
//   写入时机：before-context 钩子（每次运行前，url 刚下发、必然新鲜）
//   读取时机：read_image 工具先查本地，命中就完全不碰网络
// 这样"能不能看图"就不再取决于模型隔了多久才想起要看。
//
// 成本：只存压缩后的字节（最长边 1568 / JPEG，和发给模型的完全一致，
// 单张一般几十 KB），按会话分文件、有容量与条数上限、按天数自动清理。

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

/** 保留天数：超过就不再用（也靠清理删除）。 */
export const KEEP_DAYS = 3;
/** 每个会话最多留多少张。 */
export const MAX_PER_CHAT = 120;
/** 全部缓存目录的容量上限（字节），超了从最旧开始删。 */
export const MAX_TOTAL_BYTES = 120 * 1024 * 1024;
/** 单张超过这个大小就不缓存（避免把超大图塞进磁盘）。 */
export const MAX_ONE_BYTES = 6 * 1024 * 1024;

let _dir = null;

/**
 * 缓存目录：`<app>/data/image-cache/msg-images`。
 *
 * ⚠️ 必须避开 `<app>/data/image-cache/` 根目录 —— 那里已经有别的功能在放文件
 *    （实测有 `bing_*.jpg/png` 一堆），混在一起会让"清缓存"误删别人的图。
 *    也不能放插件目录里：插件热重载/升级会整个替换掉。
 */
export function cacheDir(appRoot) {
  if (_dir) return _dir;
  const base = process.env.QQ_AGENT_DATA_DIR
    ? path.join(process.env.QQ_AGENT_DATA_DIR, 'image-cache', 'msg-images')
    : appRoot && fs.existsSync(appRoot)
    ? path.join(appRoot, 'data', 'image-cache', 'msg-images')
    : path.join(process.env.TEMP || '.', 'qq-agent-image-cache', 'msg-images');
  try { fs.mkdirSync(base, { recursive: true }); } catch { /* ignore */ }
  _dir = base;
  return _dir;
}

/** 会话 key → 文件名（`group:123` / `private:456` 里有冒号，不能直接用）。 */
function chatFile(dir, chatKey) {
  const h = crypto.createHash('sha1').update(String(chatKey)).digest('hex').slice(0, 12);
  return path.join(dir, `${h}.json`);
}

/** 图片文件名：会话 + 消息 id，稳定可复算。 */
function imageName(chatKey, mid, ext = 'jpg') {
  return crypto.createHash('sha1').update(`${chatKey}|${mid}`).digest('hex').slice(0, 20) + '.' + ext;
}

function readIndex(file) {
  try {
    const j = JSON.parse(fs.readFileSync(file, 'utf8'));
    return j && typeof j === 'object' && j.entries ? j : { chatKey: '', entries: {} };
  } catch {
    return { chatKey: '', entries: {} };
  }
}

function writeIndex(file, idx) {
  try {
    const tmp = file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(idx), 'utf8');
    fs.renameSync(tmp, file);
  } catch { /* ignore */ }
}

function entryOf(dir, chatKey, mid) {
  const file = chatFile(dir, chatKey);
  const idx = readIndex(file);
  const e = idx.entries[String(mid)];
  if (!e) return null;
  const files = Array.isArray(e.files) ? e.files : (e.f ? [{ f: e.f, url: '' }] : []);
  if (!files.length) return null;
  return { ...e, files, file, idx };
}

/**
 * 这条消息的图是否已经在本地**且和当前消息是同一张**。
 *
 * ⚠️ 必须比对 url 指纹：QQ 图床 url 短时有效，本地 id 在应用重启后**可能被复用**
 *    （store 的 localId 机制），只按 mid 查缓存有张冠李戴的风险 —— 那正好又变成
 *    "识图不准确"。指纹不一样就当没缓存，重新抓。
 */
export function hasCached(chatKey, mid, url = '') {
  const dir = _dir;
  if (!dir) return false;
  const e = entryOf(dir, chatKey, mid);
  if (!e) return false;
  let ok = false;
  for (const f of e.files) {
    let st;
    try { st = fs.statSync(path.join(dir, f.f)); } catch { continue; }
    if (st.size) { ok = true; break; }
  }
  if (!ok) return false;
  if (url && e.url && String(e.url) !== String(fingerprint(url))) return false;
  return true;
}

/**
 * 存一条消息的图（一条消息可能有多张；GIF 抽帧时 frames 会有好几张）。
 *
 * @param {Buffer} buffer     第一张（或唯一一张）
 * @param {Buffer[]} [frames] 其余帧（GIF 抽帧用）。给了就**整组覆盖**，
 *                            否则按"同一张"去重追加 —— 保证同一条消息不会
 *                            既留旧的单帧、又留新的多帧（那会让缓存读出重复画面）。
 */
export function putCached(chatKey, mid, buffer, { ts = 0, sender = '', kind = 'image', ext = 'jpg', url = '', frames = null } = {}) {
  const dir = _dir;
  if (!dir || !buffer || !buffer.length) return false;
  const extra = (Array.isArray(frames) ? frames : []).filter((b) => Buffer.isBuffer(b) && b.length);
  const all = [buffer, ...extra];
  if (all.some((b) => b.length > MAX_ONE_BYTES)) return false;
  const file = chatFile(dir, chatKey);
  const idx = readIndex(file);
  idx.chatKey = String(chatKey);
  const cur = idx.entries[String(mid)] || { ts: Number(ts) || Date.now(), sender: String(sender || ''), kind, files: [] };
  cur.ts = Number(ts) || cur.ts || Date.now();
  cur.sender = String(sender || cur.sender || '');
  cur.kind = kind;
  const fp = url ? fingerprint(url) : '';
  if (extra.length > 0) {
    // 多帧：整组覆盖，避免旧的单帧残留成重复画面
    for (const x of cur.files || []) {
      try { fs.unlinkSync(path.join(dir, x.f)); } catch { /* ignore */ }
    }
    cur.files = [];
  } else if (fp && (cur.files || []).some((x) => x.url === fp)) {
    return false;
  }
  let n = (cur.files || []).length;
  for (const b of all) {
    const f = imageName(chatKey, `${mid}#${n}`, ext);
    try { fs.writeFileSync(path.join(dir, f), b); } catch { continue; }
    // 指纹只记在第一张上：hasCached 用它判断"还是不是同一张图"
    cur.files.push({ f, url: n === 0 ? fp : '', bytes: b.length });
    n += 1;
  }
  if (!cur.files.length) return false;
  if (fp) cur.url = fp;
  // 是否已经"抽过帧"：GIF 缓存下来的是整张原图（模型只读第一帧），
  // 读的时候要补抽帧。这个标记用来避免每次读都重复抽。
  if (extra.length > 0) cur.frames = true;
  idx.entries[String(mid)] = cur;
  // 条数上限（按消息条数）：超了按时间删最旧
  const list = Object.entries(idx.entries).sort((a, b) => (a[1].ts || 0) - (b[1].ts || 0));
  while (list.length > MAX_PER_CHAT) {
    const [k, v] = list.shift();
    for (const x of v.files || []) {
      try { fs.unlinkSync(path.join(dir, x.f)); } catch { /* ignore */ }
    }
    delete idx.entries[k];
  }
  writeIndex(file, idx);
  return true;
}

/**
 * 取一条消息本地缓存的图，返回可以**直接发回给模型**的结果数组。
 * 形状与 tools.js 的 downloadImageAsDataUrl 一致（dataUrl / isGif / gifBuffer）。
 * @returns {Array<{dataUrl:string,isGif:boolean,gifBuffer:null}>}
 */
export function getCached(chatKey, mid) {
  const dir = _dir;
  if (!dir) return [];
  const e = entryOf(dir, chatKey, mid);
  if (!e) return [];
  const out = [];
  for (const f of e.files) {
    let buf;
    try { buf = fs.readFileSync(path.join(dir, f.f)); } catch { continue; }
    if (!buf.length) continue;
    out.push({
      // 缓存里统一是 JPEG（存的就是"发给模型的那份字节"）
      dataUrl: `data:image/jpeg;base64,${buf.toString('base64')}`,
      isGif: false,
      gifBuffer: null,
      cachedAt: e.ts,
      bytes: buf.length
    });
  }
  return out;
}

/** 图床 url 的短指纹（只用来判断"还是不是同一张"，不存完整 url）。 */
function fingerprint(url) {
  return crypto.createHash('sha1').update(String(url)).digest('hex').slice(0, 12);
}

/**
 * 取一条消息缓存文件的**绝对路径与内容类型**，供"补抽帧"使用。
 *
 * 为什么不复用 getCached：那个返回的是发回给模型的 dataUrl（base64），
 * 而抽帧需要**磁盘路径**（ffmpeg 要读文件）。
 *
 * @returns {Array<{path:string, bytes:number, isGif:boolean, frames:boolean}>}
 */
export function getCachedFiles(chatKey, mid) {
  const dir = _dir;
  if (!dir) return [];
  const e = entryOf(dir, chatKey, mid);
  if (!e) return [];
  const out = [];
  for (const f of e.files) {
    const p = path.join(dir, f.f);
    let buf;
    try { buf = fs.readFileSync(p); } catch { continue; }
    if (!buf.length) continue;
    // 用**魔数**判类型，不信扩展名 —— 实测缓存文件名叫 .jpg、内容却是 GIF
    const head = buf.toString('ascii', 0, 6);
    out.push({
      path: p,
      bytes: buf.length,
      isGif: head === 'GIF87a' || head === 'GIF89a',
      frames: e.frames === true
    });
  }
  return out;
}

/** 记下"这条消息已经抽过帧"，避免每次读都重复抽。 */
export function markFramesDone(chatKey, mid) {
  const dir = _dir;
  if (!dir) return false;
  const file = chatFile(dir, chatKey);
  const idx = readIndex(file);
  const e = idx.entries[String(mid)];
  if (!e) return false;
  e.frames = true;
  writeIndex(file, idx);
  return true;
}

/**
 * 列出某个会话本地还有哪些图（新的在前）。
 * @returns {Array<{mid:number, ts:number, sender:string, bytes:number}>}
 */
export function listCached(chatKey, limit = 20) {
  const dir = _dir;
  if (!dir) return [];
  const idx = readIndex(chatFile(dir, chatKey));
  return Object.entries(idx.entries)
    .map(([mid, v]) => ({
      mid: Number(mid),
      ts: v.ts || 0,
      sender: v.sender || '',
      count: (v.files || []).length,
      bytes: (v.files || []).reduce((s, x) => s + (x.bytes || 0), 0)
    }))
    .sort((a, b) => b.ts - a.ts)
    .slice(0, Math.max(1, limit));
}

/** 清掉超过保留期的条目。 */
export function pruneOld(days = KEEP_DAYS) {
  const dir = _dir;
  if (!dir) return 0;
  const floor = Date.now() - days * 86400000;
  let removed = 0;
  let files = [];
  try { files = fs.readdirSync(dir); } catch { return 0; }
  for (const f of files) {
    if (!f.endsWith('.json')) continue;
    const full = path.join(dir, f);
    const idx = readIndex(full);
    let changed = false;
    for (const [mid, v] of Object.entries(idx.entries)) {
      if ((v.ts || 0) < floor) {
        for (const x of v.files || []) {
          try { fs.unlinkSync(path.join(dir, x.f)); } catch { /* ignore */ }
        }
        delete idx.entries[mid];
        changed = true;
        removed += 1;
      }
    }
    if (changed) writeIndex(full, idx);
  }
  return removed;
}

/** 容量兜底：总量超上限就从最旧的开始删。 */
export function enforceQuota(maxBytes = MAX_TOTAL_BYTES) {
  const dir = _dir;
  if (!dir) return 0;
  let files = [];
  try { files = fs.readdirSync(dir).filter((f) => f.endsWith('.json')); } catch { return 0; }
  const all = [];
  for (const f of files) {
    const idx = readIndex(path.join(dir, f));
    for (const [mid, v] of Object.entries(idx.entries)) {
      const bytes = (v.files || []).reduce((s, x) => s + (x.bytes || 0), 0);
      all.push({ mid, ts: v.ts || 0, bytes, file: path.join(dir, f) });
    }
  }
  let total = all.reduce((s, x) => s + x.bytes, 0);
  if (total <= maxBytes) return 0;
  all.sort((a, b) => a.ts - b.ts);
  let removed = 0;
  for (const x of all) {
    if (total <= maxBytes) break;
    const idx = readIndex(x.file);
    const v = idx.entries[String(x.mid)];
    if (v) {
      for (const y of v.files || []) {
        try { fs.unlinkSync(path.join(dir, y.f)); } catch { /* ignore */ }
      }
      delete idx.entries[String(x.mid)];
      writeIndex(x.file, idx);
    }
    total -= x.bytes;
    removed += 1;
  }
  return removed;
}

/** 目录总大小与张数（给排障/日志用）。 */
export function stats() {
  const dir = _dir;
  if (!dir) return { dir: '', files: 0, bytes: 0, messages: 0 };
  let files = 0;
  let bytes = 0;
  let messages = 0;
  try {
    for (const f of fs.readdirSync(dir)) {
      if (!f.endsWith('.json')) continue;
      const idx = readIndex(path.join(dir, f));
      for (const v of Object.values(idx.entries)) {
        messages += 1;
        for (const x of v.files || []) { files += 1; bytes += x.bytes || 0; }
      }
    }
  } catch { /* ignore */ }
  return { dir, files, bytes, messages };
}
