// 图片指代助手 + 图片本地缓存（确定性型插件）
//
// ── 这个插件修两个实测故障 ──────────────────────────────────────────────────
//
// 【故障一】查错消息 id：图片消息和"叫它看图"的文字消息是两条不同的消息
//   实测（用户反馈"群里的图为什么说是一片白"）：
//     群友先发了一条 [图片]               ← 图片在这条上（id A）
//     紧接着另发一条并 @ 机器人："你看得懂这个图吗"  ← 被 @ 的是这条，本身不带图（id B）
//     模型调用 get_message_images(messageId=B)      ← 它查了被 @ 的那条
//     工具返回："消息 B 没有可查看的图片"
//     模型接着乱试几个别的 id，最后回"我这边一片白"
//   根因不是抓图坏了（同一张图它先前还成功描述过），而是**查错 id 时工具
//   不告诉它正确的 id 在哪**，于是它瞎猜、最后自己圆成"一片白"。
//
// 【故障二】图床 url 几分钟就失效 —— 这才是"识图不准确"的根因
//   实测：QQ 图床的下载 url 有效期**在 7 分钟以内**。
//   把最近 16 张图（7~42 分钟前）全部重测：**16 张全 HTTP 400**；
//   而刚收到不久的那些图重测仍是 200（成功）。
//   于是：消息刚到时看图是对的（url 还活着），只要晚一步回头补看，
//   url 已经死了 → 工具报"图片获取失败" → 模型看不到图却已经开口 → 猜/编。
//   在群友眼里这就是"识图不准确"，而且**越忙的群越明显**（消息刷得快、回头看得晚）。
//
// ── 两个故障的解法 ─────────────────────────────────────────────────────────
// 一：包装内置工具（不重写抓图逻辑），查错 id 时把**最近一条带图的消息 id** 直接告诉它。
// 二：图片一到达就**顺手存一份到本地**（before-context 钩子里，此时 url 必然新鲜），
//     之后 read_image 先查本地、命中就完全不碰网络 —— 能不能看图不再取决于
//     "模型隔了多久才想起要看"。缓存实现见同目录 cache.js。
//
// ── 为什么这么实现（踩过的坑，别改回去）────────────────────────────────────
// 1) **包装而不是重写**：直接复用内置 `get_message_images` 的 execute，抓图/压缩/
//    GIF 转视频那套复杂逻辑一行都不复制，核心升级也不会让这里过期。
// 2) **注册成新 id，并隐藏内置那个**：不能覆盖注册同一个 id —— 那样注册表里这条的
//    skillId 会变成本插件，插件一旦被禁用，`unregisterToolsBySkill` 会把**内置工具
//    一起删掉**。所以新开一个 id，再用 `tool.guard` 把内置的藏起来。
// 3) **缓存命中时禁止往工具结果里追加任何文字**：工具结果会以 `role: 'tool'` 进
//    对话历史并**参与下一轮的前缀缓存**。往这里塞一句"这张图来自本地缓存"会改变
//    前缀 → 后续每一轮的缓存命中全废，省下的抓图时间远不够赔 token。
//    所以缓存命中时返回的是**与内置实现逐字相同**的结果，只把下载换成本地读。
// 4) **不用提示词规则解决指代问题**：模型上下文里明明有 `#849431631`，它还是去查了
//    别的 id —— 说明"给规则"不可靠。这里改成确定性兜底：查错了就直接把它指到正确那条。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import * as cache from './cache.js';
import { recoverImages } from './recovery.js';

let log = () => {};
let warn = () => {};
/** api.config()：读本插件的技能配置（设置页保存的那份）。 */
let config = null;

/**
 * GIF 补抽帧时，是否按长度自适应帧数（默认开）。
 *
 * 开 → 先探时长，再按约 1 帧/秒算（夹在 6~12 帧）。适合有动作的动图。
 * 关 → 用抽帧模块的默认帧数（4 帧）。
 *
 * 什么时候该关：短表情 GIF（几帧循环、画面几乎不变）按长度开会抽出 6+ 张几乎一样的图，
 * 白花 token 又没多看到动作。关掉就退回 4 张。
 */
function adaptiveGifFrames() {
  try {
    const v = config?.().adaptiveGifFrames;
    if (v === undefined || v === null || v === '') return true;   // 未配置 → 默认开
    if (typeof v === 'boolean') return v;
    return String(v).toLowerCase() !== 'false' && String(v) !== '0';
  } catch { return true; }
}

const CORE_TOOL_ID = 'get_message_images';
const MY_TOOL_ID = 'read_image';
const LIST_TOOL_ID = 'list_viewable_images';

/** 一次运行最多补下几张图（避免刷屏时同时抓几十张）。 */
const MAX_FETCH_PER_RUN = 4;
/** 并发上限。 */
const MAX_CONCURRENT = 2;

/**
 * 延迟导入 video-frames 插件的抽帧实现（走**应用目录**的那一份）。
 *
 * 为什么这里需要抽帧（2026-09-28 用户实测故障）：
 *   GIF 一到就被 before-context 钩子缓存了整张原图，于是 `read_image`
 *   **永远走"缓存命中"分支**，而那个分支以前直接返回缓存内容 —— **抽帧根本没执行**，
 *   模型拿到的是一张 GIF（只能读第一帧）→ 回答"这张就一帧"。
 *   实测证据：缓存文件名叫 `.jpg`，头部却是 `474946383961`（GIF89a）、497KB，
 *   就是整张原始 GIF。
 *
 * ⚠️ 这里确实让 image-ref-hint 依赖 video-frames（我的扩展集内部依赖）。
 *    代价可接受：拿不到就返回 null、退回单帧（不会报错），
 *    且两个插件都在同一套备份与还原脚本里，不会只丢一个。
 */
let _framesMod = null;
async function loadFrames() {
  if (_framesMod) return _framesMod;
  try {
    const root = globalThis.__qqAgentRoot || resolveAppRoot();
    if (!root) return null;
    const url = pathToFileURL(path.join(root, 'plugins', 'video-frames', 'frames.js')).href;
    _framesMod = await import(url);
    return _framesMod;
  } catch (e) {
    try { warn(`抽帧模块不可用（GIF 会退回单帧）：${e?.message ?? e}`); } catch { /* ignore */ }
    return null;
  }
}

/** 这段字节是 GIF 吗（GIF87a / GIF89a）。 */
function isGifBytes(buf) {
  const h = buf?.length >= 6 ? buf.toString('ascii', 0, 6) : '';
  return h === 'GIF87a' || h === 'GIF89a';
}

/**
 * 找应用根目录（含 `src/tool-registry.js` 的那个）。
 *
 * ⚠️ 不能只靠"本文件往上两级"：插件目录可能被放在别处
 *    （例如从市场安装、或被复制到另一个工作区），那时往上两级并不是应用根目录。
 *    实测踩过：在非应用目录下推出来的根目录不对，import 失败、插件静默不生效。
 *    所以列多个候选，**逐个验证"该目录下确实有 src/tool-registry.js"** 再采用。
 */
function resolveAppRoot() {
  const candidates = [];
  // ① 最准：core 自己 import 的注册表来自哪（绝对路径，不会猜错）
  try {
    if (globalThis.__qqAgentCoreToolRegistryUrl) {
      candidates.push(path.resolve(path.dirname(fileURLToPath(globalThis.__qqAgentCoreToolRegistryUrl)), '..'));
    }
  } catch { /* ignore */ }
  // ② 本文件往上两级（在应用里加载时正好是 app 根）
  try {
    candidates.push(path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..'));
  } catch { /* ignore */ }
  // ③ Electron：<install>\QQ Agent.exe → <install>\resources\app
  try {
    candidates.push(path.join(path.dirname(process.execPath), 'resources', 'app'));
  } catch { /* ignore */ }
  // ④ 兜底：cwd。⚠️ 放最后：开发/测试时 cwd 常常是工作区而不是应用目录，
  //    而工作区里也可能恰好有 src/tool-registry.js，排前面会认错根目录。
  try { candidates.push(process.cwd()); } catch { /* ignore */ }
  for (const c of candidates) {
    try {
      if (c && fs.existsSync(path.join(c, 'src', 'tool-registry.js'))) return c;
    } catch { /* ignore */ }
  }
  return null;
}

/**
 * 由注册表模块自身的路径反推应用根目录。
 *
 * ⚠️ 这条兜底很重要：`resolveAppRoot()` 是按**插件文件的位置**猜的，而插件可能从
 *    工作区副本（开发/测试）被加载，此时所有候选都落空 → appRoot null →
 *    本地缓存与"过期图补救"整条链路静默失效（不报错，只是永远看不到图）。
 *    注册表模块是 core 用绝对路径 import 进来的，从它的 URL 反推**一定准确**。
 */
function appRootFromRegistry(mod) {
  try {
    const u = globalThis.__qqAgentCoreToolRegistryUrl || mod?.__fileUrl || '';
    if (!u) return null;
    const p = fileURLToPath(u);           // …/src/tool-registry.js
    const root = path.resolve(path.dirname(p), '..');
    if (fs.existsSync(path.join(root, 'src', 'tool-registry.js'))) return root;
  } catch { /* ignore */ }
  return null;
}

/**
 * 取内置工具注册表。
 *
 * ⚠️ 必须**缓存到 globalThis**：插件加载器用 `import(url + '?t=' + Date.now())` 强制
 * 每次热重载重新求值，模块级变量会在重载后丢失。挂到 globalThis 上最稳：
 * 宁愿拿到"可能是旧实例"的注册表（注册表内容始终是最新的），也不要拿到一个空的新实例。
 */
async function coreRegistry() {
  if (globalThis.__qqAgentCoreToolRegistry) return globalThis.__qqAgentCoreToolRegistry;
  const root = resolveAppRoot();
  if (!root) {
    throw new Error('找不到应用根目录（候选路径下都没有 src/tool-registry.js）——'
      + '应用可能换了安装位置，需要更新本插件的路径探测');
  }
  const url = pathToFileURL(path.join(root, 'src', 'tool-registry.js')).href;
  const mod = await import(url);
  // 记住"注册表是从哪个文件来的"。不能用 mod.__fileUrl —— ESM 命名空间对象是冻结的，
  // 动态赋值会被拒绝（严格模式下直接抛错），所以挂一个独立的全局变量。
  globalThis.__qqAgentCoreToolRegistryUrl = url;
  globalThis.__qqAgentCoreToolRegistry = mod;
  return mod;
}

// ── 结果判定 ───────────────────────────────────────────────────────────────

/** 从内置返回文本里取"消息 X 的内容…。"那一句（认不出返回 ''）。 */
function pickPhotoSentence(res) {
  try {
    const c = res?.content;
    const text = typeof c === 'string' ? c : JSON.stringify(c ?? '');
    const m = /消息\s+\S+\s+的内容[^。]*。/.exec(text);
    return m ? m[0] : '';
  } catch {
    return '';
  }
}

/** data url → 字节（拿不到返回 null）。 */
function dataUrlToBuffer(u) {
  try {
    const s = String(u || '');
    const i = s.indexOf(',');
    if (i < 0) return null;
    const b = Buffer.from(s.slice(i + 1), 'base64');
    return b.length ? b : null;
  } catch {
    return null;
  }
}

/**
 * 把内置返回的图片部件收成本地字节。
 *
 * GIF 抽帧路线（tools.js 的 `extraDataUrls`）下，内置会把一张动图摊成几张静态图，
 * 所以要**把每张 image_url 部件都收下来**，不能只取第一张 —— 只存第一张的话，
 * 本地缓存里这张 GIF 退化成一帧，之后每次读都只有一帧（正是我们要修的毛病）。
 */
function collectImageBuffers(res) {
  try {
    const c = res?.content;
    if (!Array.isArray(c)) return [];
    const out = [];
    for (const p of c) {
      if (p?.type !== 'image_url') continue;
      const b = dataUrlToBuffer(p.image_url?.url);
      if (b) out.push(b);
    }
    return out;
  } catch {
    return [];
  }
}

/** 原工具"没有可查看的图片"的返回判定。 */
export function isNoImageResult(res) {
  try {
    const c = res?.content;
    const text = typeof c === 'string' ? c : JSON.stringify(c ?? '');
    return /没有可查看的图片/.test(text);
  } catch {
    return false;
  }
}

/** 原工具"图片获取失败"的返回判定（url 失效就走这条）。 */
export function isFetchFailedResult(res) {
  try {
    const c = res?.content;
    const text = typeof c === 'string' ? c : JSON.stringify(c ?? '');
    return /图片获取失败|图片下载失败|图片内容为空/.test(text);
  } catch {
    return false;
  }
}

/** 原工具"找不到消息"的返回判定。 */
export function isNotFoundResult(res) {
  try {
    const c = res?.content;
    const text = typeof c === 'string' ? c : JSON.stringify(c ?? '');
    return /找不到消息/.test(text);
  } catch {
    return false;
  }
}

// ── 找"最近一条带图的消息" ──────────────────────────────────────────────────

function imageMediaOf(m) {
  return (m?.media || []).filter((x) => x && x.kind === 'image' && x.url);
}

/**
 * 找当前会话里**最近一条带图的消息**（排除刚查的那条）。
 *
 * 优先返回本地**已经有缓存**的那条 —— 因为图床 url 几分钟就失效，
 * "最近带图"不一定"还看得见"；有缓存的一定看得见。
 * 拿不到 store 就返回 null —— 此时原样返回内置结果，绝不因为本插件出问题而让工具坏掉。
 */
export function findRecentImageMessage(store, chatKey, excludeMid = null, limit = 80) {
  try {
    if (!store || typeof store.recent !== 'function') return null;
    const list = store.recent(chatKey, { limit }) || [];
    let fallback = null;
    for (let i = list.length - 1; i >= 0; i -= 1) {
      const m = list[i];
      if (!m) continue;
      if (excludeMid != null && String(m.mid) === String(excludeMid)) continue;
      const imgs = imageMediaOf(m);
      if (!imgs.length) continue;
      const info = {
        mid: m.mid,
        count: imgs.length,
        sender: m.self ? '我' : String(m.senderName || m.senderId || ''),
        ts: m.ts ? new Date(m.ts).toLocaleTimeString('zh-CN', { hour12: false }) : '',
        cached: false
      };
      if (!fallback) fallback = info;
      if (cache.hasCached(chatKey, m.mid, imgs[0].url)) return { ...info, cached: true };
    }
    return fallback;
  } catch {
    return null;
  }
}

/** 会话里最近几条带图消息（新的在前），带"本地是否还看得见"。 */
export function listImageMessages(store, chatKey, limit = 50, max = 8) {
  try {
    if (!store || typeof store.recent !== 'function') return [];
    const list = store.recent(chatKey, { limit }) || [];
    const out = [];
    for (let i = list.length - 1; i >= 0 && out.length < max; i -= 1) {
      const m = list[i];
      if (!m) continue;
      const imgs = imageMediaOf(m);
      if (!imgs.length) continue;
      out.push({
        mid: m.mid,
        count: imgs.length,
        sender: m.self ? '我' : String(m.senderName || m.senderId || ''),
        ts: m.ts || 0,
        time: m.ts ? new Date(m.ts).toLocaleTimeString('zh-CN', { hour12: false }) : '',
        cached: cache.hasCached(chatKey, m.mid, imgs[0].url)
      });
    }
    return out;
  } catch {
    return [];
  }
}

// ── 抓图补缓存 ─────────────────────────────────────────────────────────────

let fetching = 0;
const pending = new Set();

/**
 * 抓一张图并写进本地缓存。
 *
 * ⚠️ 这里**重新实现下载**（而不是复用内置 execute）是有意的：
 *    内置那条路径会把字节 base64 进 dataUrl 交给模型，而我们只要"落盘"这个副作用，
 *    不需要它触发任何 LLM 调用；而且它内部有 GIF 转视频等分支（会 spawn ffmpeg），
 *    补缓存阶段没必要付这个代价 —— 缓存里统一存 JPEG。
 *    唯一需要注意的是压缩参数要和内置一致，否则"缓存看到的"和"当场看到的"不一样。
 */
async function fetchIntoCache(chatKey, m, appRoot) {
  const imgs = imageMediaOf(m);
  if (!imgs.length) return false;
  const key = `${chatKey}|${m.mid}`;
  if (String(m.mid) && cache.hasCached(chatKey, m.mid, imgs[0].url)) return false;
  if (pending.has(key)) return false;
  if (fetching >= MAX_CONCURRENT) return false;
  pending.add(key);
  fetching += 1;
  let stored = 0;
  try {
    // 先把这条消息的图都抓下来，再**一次**写进缓存：
    // 一条消息有多张图（或 GIF 抽帧多帧）时必须合成一条缓存记录，
    // 分多次 putCached 会让后一张覆盖/追加成"同一消息的第二个文件"，
    // 而 getCached 会把它们全返回 —— 数量对不上就可能重复喂图。
    const bufs = [];
    for (const im of imgs) {
      try {
        const res = await fetch(im.url, { headers: { 'user-agent': 'Mozilla/5.0' } });
        if (!res.ok) continue;
        const buf = Buffer.from(await res.arrayBuffer());
        if (!buf.length) continue;
        let out = buf;
        // 与应用同一条压缩管线（最长边 1568 / JPEG q4）—— 缓存里的字节就是会发给模型的那份
        try {
          const mod = await import(pathToFileURL(path.join(appRoot, 'src', 'image-compress.js')).href);
          const c = await mod.compressImage(buf);
          if (c && c.buffer && c.buffer.length) out = c.buffer;
        } catch { /* 压缩模块拿不到就存原图 */ }
        bufs.push(out);
      } catch { /* 单张失败不影响其它张 */ }
    }
    if (bufs.length) {
      if (cache.putCached(chatKey, m.mid, bufs[0], {
        ts: m.ts || Date.now(),
        sender: m.self ? '我' : String(m.senderName || m.senderId || ''),
        kind: 'image',
        url: imgs[0].url,
        frames: bufs.slice(1)
      })) stored = bufs.length;
    }
    return stored > 0;
  } finally {
    pending.delete(key);
    fetching -= 1;
  }
}

/**
 * before-context 钩子：每次运行前，把本批新来的图片抓一份到本地。
 *
 * ⚠️ 必须**不阻塞**主流程：这里 fire-and-forget（不 await）。等待会让每次回复
 *    都晚几百毫秒到几秒，而补缓存只是"以后可能用得上"的事。
 * ⚠️ 只处理本批新消息（triggerEntries）：翻旧账没意义 —— 那些 url 早就失效了。
 */
export function onBeforeContext(ctx = {}) {
  try {
    const store = ctx.store;
    const chatKey = ctx.chatKey;
    const appRoot = globalThis.__qqAgentRoot || resolveAppRoot();
    if (!store || !chatKey || !appRoot) return;
    // ⚠️ 不能假设 setup 已经跑过（热重载时序 / 只实现钩子的情形）：这里自己确保目录已就绪，
    //    否则 cache 模块的 _dir 还是 null，所有 hasCached/putCached 会静默变成"永远没缓存"。
    cache.cacheDir(appRoot);
    // 首次安装后补一次历史图（插件装好之前到的图，图床链接早就过期了）
    scheduleBackfill(store, chatKey, appRoot);
    const entries = Array.isArray(ctx.triggerEntries) ? ctx.triggerEntries : [];
    let queued = 0;
    for (const m of entries) {
      if (queued >= MAX_FETCH_PER_RUN) break;
      const imgs = imageMediaOf(m);
      if (!m || !imgs.length) continue;
      if (stringMid(m.mid) && cache.hasCached(chatKey, m.mid, imgs[0].url)) continue;
      queued += 1;
      fetchIntoCache(chatKey, m, appRoot).catch(() => {});
    }
  } catch (error) {
    try { warn(`图片缓存钩子出错：${error?.message ?? error}`); } catch { /* ignore */ }
  }
}

/** 卸载时不再处理任何补缓存任务。 */
export function deactivate() {
  pending.clear();
}

// ── 首次安装后的补缓存（考古）───────────────────────────────────────────────

/** 补缓存最多回看多少条消息、每个会话最多补几张、整轮最多补几张。 */
const BACKFILL_SCAN = 120;
const BACKFILL_MAX_PER_CHAT = 40;
const BACKFILL_MAX_TOTAL = 120;
/** 已补过的会话（避免每次运行都重扫）。 */
const backfilledChats = new Set();
let backfillTotal = 0;

/**
 * 把**已经在上下文里、但图床链接早已过期**的图补进本地缓存。
 *
 * 为什么需要：本地缓存只能从"插件装好之后新到的图"开始积累，而模型当下能看到的
 * 最近几十条【已读信息】里的图全都是过期的。不补的话，"识图不准"要等新图慢慢
 * 换掉旧图才会好 —— 补一次就立刻生效（走的是已验证的 /api/media-data 补救通道）。
 *
 * ⚠️ 按会话分别补（不是全局只补一次）：实测发现**没触发运行的会话不会被缓存**
 *    （before-context 只在真正跑一次时才执行），而"某张图当时没触发、后来又有人
 *    问起它"恰恰是最常见的场景 —— 那个会话也需要补一次。整轮总量仍有上限。
 * ⚠️ 刻意做成后台、限量、可失败：这只是"让旧图也能看"的优化，绝不能影响主流程。
 */
async function backfillRecent(store, chatKey, appRoot) {
  try {
    if (!store || typeof store.recent !== 'function') return 0;
    if (backfillTotal >= BACKFILL_MAX_TOTAL) return 0;
    const list = store.recent(chatKey, { limit: BACKFILL_SCAN }) || [];
    const targets = [];
    for (let i = list.length - 1; i >= 0 && targets.length < BACKFILL_MAX_PER_CHAT; i -= 1) {
      const m = list[i];
      const imgs = imageMediaOf(m);
      if (!imgs.length) continue;
      if (stringMid(m.mid) && cache.hasCached(chatKey, m.mid, imgs[0].url)) continue;
      targets.push(m);
    }
    let done = 0;
    for (const m of targets) {
      if (backfillTotal + done >= BACKFILL_MAX_TOTAL) break;
      try {
        // 同一个会话串行补，别把 QQ/本机接口打满
        const recovered = await recoverImages(appRoot, m.media || []);
        for (const r of recovered) {
          try {
            const b64 = r.dataUrl.slice(r.dataUrl.indexOf(',') + 1);
            cache.putCached(chatKey, m.mid, Buffer.from(b64, 'base64'), {
              ts: m.ts || Date.now(),
              sender: m.self ? '我' : String(m.senderName || ''),
              kind: 'image',
              url: imageMediaOf(m)[0].url
            });
            done += 1;
          } catch { /* ignore */ }
        }
      } catch { /* 单条失败继续 */ }
    }
    backfillTotal += done;
    return done;
  } catch {
    return 0;
  }
}

function stringMid(mid) {
  return mid !== null && mid !== undefined && String(mid) !== '';
}

/**
 * 缓存命中时的 GIF 补抽帧 —— 修"只能说读到一帧"的那个故障。
 *
 * 背景（2026-09-28 用户实测）：
 *   GIF 一到就被 before-context 钩子缓存成**整张原图**，于是 `read_image` 每次都走
 *   "缓存命中"分支；而那个分支原样返回缓存内容 —— **抽帧从未执行**。
 *   模型收到一张 GIF（只读第一帧），于是回答"这张就一帧"。
 *   实测证据：缓存文件名叫 `.jpg`，头部却是 `474946383961`（GIF89a）、497KB。
 *
 * 做法：只抽**第一张**、且**内容确实是 GIF**、且**还没抽过**的条目。
 *   抽完把多帧写回缓存（`frames:[...]` 会整组覆盖并打上 frames 标记），
 *   之后每次读都直接命中多帧，不会再抽。
 *
 * 失败一律返回 null → 调用方退回原来的单帧行为（不会因为抽帧坏了而看不到图）。
 *
 * @returns {Promise<string[]|null>} dataUrl 数组；不需要抽或抽失败时 null
 */
async function maybeExtractGifFrames(chatKey, mid) {
  try {
    if (!chatKey || mid == null) return null;
    const files = cache.getCachedFiles(chatKey, mid);
    if (files.length !== 1) return null;        // 只处理"单张且是 GIF"的情形
    const f = files[0];
    if (!f.isGif || f.frames) return null;      // 非 GIF / 已抽过
    const mod = await loadFrames();
    if (!mod || typeof mod.extractFrames !== 'function') return null;
    // ── 帧数必须按长度自适应（2026-09-28 修）──────────────────────────────
    // 这里曾经**不传 count**，于是 frames.js 用了它的默认值 4。
    // 后果：核心那条路（tools.js → gifToFramesDataUrls → gifFrameCountFor）会按
    // 时长算帧数，但 **GIF 实际走的这条插件路永远只抽 4 帧** —— 用户看到的
    // "明明动作挺明显却抽不到"就是这么来的：
    //   1.52 秒的 GIF：自适应 6 帧（间隔 0.27s）vs 固定 4 帧（间隔 0.45s），
    //   眨眼这种短动作正好落在两次采样之间就被漏掉。
    let want = 0;
    if (adaptiveGifFrames()) {
      try {
        const root = globalThis.__qqAgentRoot || resolveAppRoot();
        if (root) {
          const core = await import(pathToFileURL(path.join(root, 'src', 'gif-to-video.js')).href);
          if (typeof core.gifFrameCountFor === 'function') {
            const dur = typeof mod.probeDuration === 'function' ? await mod.probeDuration(f.path).catch(() => 0) : 0;
            want = Number(core.gifFrameCountFor(dur, f.bytes)) || 0;
          }
        }
      } catch { /* 拿不到自适应函数就退回 frames.js 的默认值 */ }
    }
    // want = 0 时传 undefined → frames.js 用自己的默认帧数（4）。
    // 这既是"关掉自适应"的行为，也是"拿不到 gifFrameCountFor"时的兜底。
    // labels 默认开（与 video-frames 插件的 provider 保持一致）
    const r = await mod.extractFrames({ filePath: f.path, count: want || undefined, maxWidth: 768, labels: true });
    const frames = (r && Array.isArray(r.frames)) ? r.frames.filter(Boolean) : [];
    if (frames.length < 2) return null;          // 没抽出多帧就别折腾，保持原样
    // ⚠️ 必须检查"抽出来的帧是不是真的不一样"（2026-09-28 加）：
    //    frames.js 曾因 run() 返回值判真假写错，无差别触发"退回 -ss 0"，
    //    抽出的每一帧其实都是**同一张首帧**（只有左上角时间标记不同）。
    //    如果这里不查重复，会把"单帧"标记成"已抽帧"，之后永远不再重试 ——
    //    等于把这个 bug 永久固化进缓存。宁可判失败保留原样，等修好后能自愈。
    const seen = new Set();
    let distinct = 0;
    for (const u of frames) {
      // 抠掉 data URL 前缀后按内容比；同一张图必然字节相同
      const body = String(u).slice(String(u).indexOf(',') + 1, String(u).indexOf(',') + 400);
      if (!seen.has(body)) { seen.add(body); distinct += 1; }
    }
    if (distinct < 2) {
      try { warn(`GIF 抽帧抽出了 ${frames.length} 张相同画面，判定失败、不写缓存（${mid}）`); } catch { /* ignore */ }
      return null;
    }
    const bufs = frames.map((u) => dataUrlToBuffer(u)).filter(Boolean);
    if (bufs.length < 2) return null;
    const n = cache.putCached(chatKey, mid, bufs[0], {
      kind: 'image',
      frames: bufs.slice(1)
    });
    if (!n) return null;
    cache.markFramesDone(chatKey, mid);
    try { log(`缓存命中的 GIF 已补抽帧：${mid} → ${bufs.length} 帧`); } catch { /* ignore */ }
    return frames;
  } catch (e) {
    try { warn(`GIF 补抽帧失败（退回单帧）：${e?.message ?? e}`); } catch { /* ignore */ }
    return null;
  }
}

/**
 * 触发一次补缓存：**每个会话只做一次**，且在后台跑（不占 setup，也不抢回复时间）。
 */
export function scheduleBackfill(store, chatKey, appRoot) {
  const key = String(chatKey || '');
  if (!key || backfilledChats.has(key) || !store || !appRoot) return;
  if (backfillTotal >= BACKFILL_MAX_TOTAL) return;
  backfilledChats.add(key);
  backfillRecent(store, key, appRoot).then((n) => {
    if (n) {
      try { log(`${key}：已把 ${n} 张历史图补进本地缓存（以后随时能看）`); } catch { /* ignore */ }
    }
  }).catch(() => {});
}

// ── setup ──────────────────────────────────────────────────────────────────

export async function setup(api) {
  log = api.log;
  warn = api.warn;
  config = typeof api.config === 'function' ? api.config : null;

  let appRoot = null;
  let original = null;
  try {
    const reg = await coreRegistry();
    // appRoot 按优先级取：别的模块已经解析好的 → 从注册表 URL 反推（最准）→ 自己猜
    appRoot = globalThis.__qqAgentRoot || appRootFromRegistry(reg) || resolveAppRoot();
    globalThis.__qqAgentRoot = appRoot;
    if (appRoot) cache.cacheDir(appRoot);
    original = reg.getTool(CORE_TOOL_ID);
  } catch (error) {
    warn(`取内置工具注册表失败：${error?.message ?? error}`);
  }
  if (!original || typeof original.execute !== 'function') {
    warn('没取到内置 get_message_images，本插件不生效（图片指代助手停用）');
    return;
  }

  const originalExecute = original.execute;
  const st = cache.stats();
  log(`本地图片缓存：${st.files} 张 / ${(st.bytes / 1048576).toFixed(1)}MB（${st.dir}）`);

  // ── 工具一：read_image（看单条消息的图，优先本地）────────────────────────
  api.registerTool({
    id: MY_TOOL_ID,
    name: '查看消息图片',
    // description 与内置保持同义（模型靠它决定何时调用），末尾补一句本插件的能力
    description: original.description
      + ' 若那条消息里没有图片，我会告诉你最近一条带图的消息是哪条，用它的 id 再查一次。'
      + ' 图片在收到的当下会被自动存在本地，所以稍后再看也能看到。',
    category: original.category || 'query',
    icon: original.icon || '🖼️',
    // 保留内置的视觉门槛：模型不支持图片输入时本工具也应隐藏
    requiresVision: original.requiresVision === true,
    parameters: original.parameters,
    defaultEnabled: original.defaultEnabled !== false,
    async execute(ctx, args) {
      const chatKey = ctx?.chatKey;
      const mid = args?.messageId;
      const entry = chatKey && mid != null ? ctx?.store?.findByMid?.(chatKey, mid) : null;
      const imgs = imageMediaOf(entry);
      // 1) 本地缓存命中：直接给模型，完全不碰网络（图床 url 早就失效了也没关系）
      if (chatKey && mid != null && imgs.length && cache.hasCached(chatKey, mid, imgs[0].url)) {
        const results = cache.getCached(chatKey, mid);
        if (results.length) {
          // ⚠️ 缓存命中之前**直接返回缓存内容**，于是 GIF 永远拿不到抽帧结果：
          //    GIF 一到就被 before-context 钩子存成整张原图，`read_image` 必然走这里，
          //    而这里返回的就是那张 GIF（模型只读第一帧）→ 回答"这张就一帧"。
          //    实测证据：缓存文件名叫 .jpg，头部却是 GIF89a、497KB。
          //    所以这里补一步：GIF 且还没抽过帧 → 用缓存文件抽帧、写回缓存、返回多帧。
          const fix = await maybeExtractGifFrames(chatKey, mid);
          if (fix) {
            const text = `消息 ${mid} 的内容：${fix.length} 张图片。`;
            return {
              content: [
                { type: 'text', text },
                ...fix.map((u) => ({ type: 'image_url', image_url: { url: u } }))
              ],
              videoCount: 0
            };
          }
          // ⚠️ 尽量沿用内置的同一句话（"消息 X 的内容：N 张图片。"）—— 文本变了会改变
          //    对话前缀，把后续轮次的缓存命中打掉（见文件头注释 3）。
          //    拿不到原文（内置只回文本部件时）就自己拼一句同样格式的。
          const text = `消息 ${mid} 的内容：${results.length} 张图片。`;
          return {
            content: [
              { type: 'text', text },
              ...results.map((r) => ({ type: 'image_url', image_url: { url: r.dataUrl } }))
            ],
            videoCount: 0
          };
        }
      }
      // 2) 没缓存 → 走内置实现（抓图/压缩/GIF 转视频都由它负责，行为完全一致）
      const res = await originalExecute(ctx, args);
      // 3) 内置抓到了：顺手补一份缓存（此刻 url 还活着，下次就稳了）
      if (appRoot && chatKey && mid != null && entry && imgs.length
        && !isNoImageResult(res) && !isFetchFailedResult(res)) {
        if (!cache.hasCached(chatKey, mid, imgs[0].url)) {
          // 优先直接存内置**已经下载好**的字节：不用二次抓网络，而且形态与
          // "当场看到的"完全一致（含 GIF 抽帧后的多帧）。
          // 内置只回文本部件（少数路径）时退回自己抓。
          const bufs = collectImageBuffers(res);
          if (bufs.length) {
            try {
              cache.putCached(chatKey, mid, bufs[0], {
                ts: entry.ts || Date.now(),
                sender: entry.self ? '我' : String(entry.senderName || ''),
                kind: 'image',
                url: imgs[0].url,
                frames: bufs.slice(1)
              });
            } catch { /* 存不下不影响这次返回 */ }
          } else {
            fetchIntoCache(chatKey, entry, appRoot).catch(() => {});
          }
        }
        return res;
      }
      // 4) 内置抓失败（url 已过期）→ 走补救通道：用 media[].file 换一个新鲜 url 再抓
      //    （实测能救回几小时前的老图：/api/media-data → OneBot get_image → 新 url 下载成功）
      if (appRoot && entry && imgs.length && isFetchFailedResult(res)) {
        try {
          const recovered = await recoverImages(appRoot, entry.media || []);
          if (recovered.length) {
            // 救回来了：同样补进缓存，下次直接命中
            for (const r of recovered) {
              try {
                const b64 = r.dataUrl.slice(r.dataUrl.indexOf(',') + 1);
                cache.putCached(chatKey, mid, Buffer.from(b64, 'base64'), {
                  ts: entry.ts || Date.now(),
                  sender: entry.self ? '我' : String(entry.senderName || ''),
                  kind: 'image',
                  url: imgs[0].url
                });
              } catch { /* 存不下不影响这次返回 */ }
            }
            const what = `${recovered.length} 张图片`;
            return {
              content: [
                { type: 'text', text: `消息 ${mid} 的内容：${what}。` },
                ...recovered.map((r) => ({ type: 'image_url', image_url: { url: r.dataUrl } }))
              ],
              videoCount: 0
            };
          }
        } catch { /* 补救失败就继续走下面的提示 */ }
      }
      // 5) 没图 / 抓失败 / 找不到消息 → 补一句"正确的 id 在哪"
      const hit = findRecentImageMessage(ctx?.store, chatKey, mid);
      if (!hit) {
        if (isFetchFailedResult(res)) return withTip(res, staleTip());
        return res;
      }
      const when = hit.ts ? `（${hit.ts}）` : '';
      const who = hit.sender ? `，${hit.sender} 发的` : '';
      const how = hit.cached ? '（这张已经存在本地，直接查一定能看到）' : '';
      const head = isFetchFailedResult(res) ? staleTip() + ' ' : '这条消息里没有图片。';
      const tip = `\n提示：${head}最近一条带图的消息是 #${hit.mid}${when}${who}，`
        + `共 ${hit.count} 张${how} —— 用它的 id 再调一次 ${MY_TOOL_ID}。`;
      return withTip(res, tip);
    }
  });

  // ── 工具二：list_viewable_images（还有哪些图看得到）─────────────────────
  // 存在的意义：模型被 @ 的那条消息不带图时，它需要知道"上下文里哪几条是图"，
  // 而聊天记录里的 #id 只标在带图消息上、不告诉它图还在不在。
  api.registerTool({
    id: LIST_TOOL_ID,
    name: '列出可看的图',
    description: '列出当前会话最近的图片消息：id、谁发的、时间、以及这张图**现在还能不能看到**。'
      + '当你要回应「这个图」「刚才那张」但不确定是哪条消息时，先用这个查一下，再用 read_image 看具体的图。',
    category: 'query',
    icon: '📷',
    requiresVision: original.requiresVision === true,
    parameters: {
      type: 'object',
      properties: {
        limit: { type: 'integer', description: '最多返回几条，默认 6，最大 12' }
      }
    },
    async execute(ctx, args) {
      const max = Math.min(12, Math.max(1, Number(args?.limit) || 6));
      const list = listImageMessages(ctx?.store, ctx?.chatKey, 80, max);
      if (!list.length) return { content: '当前会话最近没有图片消息。' };
      const lines = list.map((x) => {
        const who = x.sender ? `${x.sender} ` : '';
        const n = x.count > 1 ? `（${x.count} 张）` : '';
        return `- #${x.mid}  ${who}${x.time}${n}  ${x.cached ? '✅ 看得到' : '⚠️ 可能已失效（图床链接几分钟就过期）'}`;
      });
      return {
        content: `最近的图片消息（从上到下 = 从新到旧）：\n${lines.join('\n')}\n`
          + '看某一张：用 read_image，messageId 填上面的 #数字。'
      };
    }
  });

  log('图片指代助手已生效：read_image（优先本地缓存）+ list_viewable_images，'
    + '并隐藏内置 get_message_images');
}

/** url 失效时的统一说明 —— 让模型知道"不是你没图，是链接过期了"。 */
function staleTip() {
  return '这张图的图床链接已经过期（QQ 的图片链接只在前几分钟有效），现在下载不到了。';
}

/** 在工具结果文本后面追加提示；只在**出错/查错**这条路径上追加（见文件头注释 3）。 */
function withTip(res, tip) {
  const content = typeof res?.content === 'string' ? res.content + tip : res?.content;
  return { ...res, content };
}

/** 可用性：无外部依赖。 */
export function available() {
  return { ok: true };
}

/** 启动时清一次过期缓存（在 setup 之前被调，所以这里自己也解析一次目录）。 */
export function activate() {
  try {
    const root = globalThis.__qqAgentRoot || resolveAppRoot();
    if (root) cache.cacheDir(root);
    const n = cache.pruneOld();
    const q = cache.enforceQuota();
    if (n || q) {
      try { log(`已清理过期图片缓存：过期 ${n} 张，超容量 ${q} 张`); } catch { /* ignore */ }
    }
  } catch { /* ignore */ }
}

export const hooks = {
  'before-context': (ctx) => onBeforeContext(ctx)
};

export const providers = {
  'tool.guard': ({ toolId, context } = {}) => {
    if (toolId !== CORE_TOOL_ID) return { ok: true };
    const visionOn = !context || context.visionEnabled !== false;
    if (!visionOn) return { ok: true };
    // 隐藏内置那个，改由本插件的 read_image 提供（优先本地缓存 + 查错时给出正确 id）
    return { ok: false, reason: '由「图片指代助手」插件接管（优先本地缓存，查错时给出正确的消息 id）' };
  }
};

export const internals = {
  findRecentImageMessage, listImageMessages, isNoImageResult, isFetchFailedResult, isNotFoundResult,
  // 暴露给排障：能直接看到"按长度自适应"这个开关当前解析成什么。
  adaptiveGifFrames
};
