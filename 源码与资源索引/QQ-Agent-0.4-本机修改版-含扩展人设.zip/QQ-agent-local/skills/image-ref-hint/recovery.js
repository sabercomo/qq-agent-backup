// 过期图的补救通道 —— 本地缓存没命中时的第二条路。
//
// ── 背景（实测）────────────────────────────────────────────────────────────
// QQ 图床的下载 url 有效期**在 7 分钟以内**：把最近 16 张图（7~42 分钟前）重测，
// 16 张全 HTTP 400。但 **QQ 客户端自己缓存着这些图**，只要知道图片文件名
// （store 里 media[].file 一直存着，它不会过期），就能重新换一个新鲜 url 出来。
//
// 两条已验证的通道（都实测拿回了一张早已过期的图、解出来是合法 JPEG）：
//
//   ① 应用自带接口 `POST http://127.0.0.1:<port>/api/media-data`
//      body `{ items:[{ file, url }] }` → `{ results:[{dataUrl}|null] }`
//      它内部走 OneBot 的 get_image（拿新 url）+ safe-fetch（校验+下载），
//      正是界面上显示图片用的那条路径 —— 也就是"应用本来就允许做的事"。
//      **首选**：不用自己带 OneBot 令牌、不用自己校验 SSRF/图片类型。
//
//   ② OneBot HTTP API 直连 `POST http://127.0.0.1:<onebotPort>/get_image`（Bearer 令牌）
//      → `{ data:{ url } }` → 再自己去下那个 url。
//      ① 不可用时兜底（比如控制台端口被改过、或 api 关了）。

import fs from 'node:fs';
import path from 'node:path';

/** 单次补救的整体超时（别把一次工具调用卡死）。 */
const RECOVER_TIMEOUT_MS = 12000;

/** 从应用配置里读控制台端口、OneBot 地址与令牌。 */
function readNetConfig(appRoot) {
  const out = { appPort: 3210, appToken: '', onebotBase: '', onebotToken: '' };
  // `appRoot` 是 `<install>/resources/app`，配置在 `<install>/data/config.json`。
  // 插件里拿不到 core 的 ROOT 常量，所以按相对位置列候选往上找。
  // 也认 `appRoot` 自己就是数据根（<install>）的情形。
  const candidates = [
    ...(process.env.QQ_AGENT_DATA_DIR ? [path.join(process.env.QQ_AGENT_DATA_DIR, 'config.json')] : []),
    path.join(appRoot, '..', 'data', 'config.json'),
    path.join(appRoot, 'data', 'config.json'),
    path.join(appRoot, 'config.json'),
    path.join(path.dirname(process.execPath), 'data', 'config.json')
  ];
  for (const p of candidates) {
    try {
      if (!fs.existsSync(p)) continue;
      const cfg = JSON.parse(fs.readFileSync(p, 'utf8'));
      // 配置里没有 server/onebot 段就不是我们要的那份（例如某个插件自己的 config.json）
      if (!cfg?.server && !cfg?.onebot) continue;
      out.appPort = Number(process.env.QQ_AGENT_PORT || cfg?.server?.port) || out.appPort;
      out.appToken = String(cfg?.server?.token || '');
      const ob = cfg?.onebot || {};
      const host = String(ob.host || '127.0.0.1');
      const port = Number(ob.port) || 3000;
      out.onebotBase = String(ob.httpUrl || `http://${host}:${port}`).replace(/\/$/, '');
      out.onebotToken = String(ob.accessToken || ob.httpAccessToken || ob.token || '');
      return out;
    } catch { /* 换下一个候选 */ }
  }
  return out;
}

function withTimeout(ms) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(new Error('补救超时')), ms);
  t.unref?.();
  return { signal: ctrl.signal, done: () => clearTimeout(t) };
}

/** 推断 dataUrl 的 mime（应用接口原样返回 mime，这里只做兜底）。 */
function guessMime(fileName, fallback = 'image/jpeg') {
  const s = String(fileName || '').toLowerCase();
  if (s.endsWith('.png')) return 'image/png';
  if (s.endsWith('.gif')) return 'image/gif';
  if (s.endsWith('.webp')) return 'image/webp';
  if (s.endsWith('.jpg') || s.endsWith('.jpeg')) return 'image/jpeg';
  return fallback;
}

/**
 * 通道①：走应用自带的 /api/media-data。一次可救多张。
 * @returns {Promise<Array<null|{dataUrl:string,isGif:boolean,gifBuffer:null}>>}
 */
async function viaAppApi(appRoot, items) {
  const net = readNetConfig(appRoot);
  const url = `http://127.0.0.1:${net.appPort}/api/media-data`;
  const { signal, done } = withTimeout(RECOVER_TIMEOUT_MS);
  try {
    const headers = { 'content-type': 'application/json', 'X-Console-Token': 'qq-agent-console', Origin: `http://127.0.0.1:${net.appPort}` };
    if (net.appToken) headers['x-token'] = net.appToken;
    const r = await fetch(url, { method: 'POST', headers, body: JSON.stringify({ items }), signal });
    if (!r.ok) return items.map(() => null);
    const j = await r.json();
    const results = Array.isArray(j?.results) ? j.results : [];
    return items.map((it, i) => {
      const d = results[i];
      const dataUrl = typeof d?.dataUrl === 'string' ? d.dataUrl : '';
      if (!dataUrl.startsWith('data:')) return null;
      const mime = dataUrl.slice(5, dataUrl.indexOf(';')) || guessMime(it?.file);
      return { dataUrl, isGif: /gif/i.test(mime), gifBuffer: null };
    });
  } catch {
    return items.map(() => null);
  } finally {
    done();
  }
}

/** 通道②：直连 OneBot 的 get_image 换新 url，再自己下载。 */
async function viaOneBot(appRoot, item) {
  const net = readNetConfig(appRoot);
  if (!net.onebotBase) return null;
  const { signal, done } = withTimeout(RECOVER_TIMEOUT_MS);
  try {
    const headers = { 'content-type': 'application/json' };
    if (net.onebotToken) headers.authorization = `Bearer ${net.onebotToken}`;
    const r = await fetch(`${net.onebotBase}/get_image`, {
      method: 'POST', headers, body: JSON.stringify({ file: String(item?.file || '') }), signal
    });
    if (!r.ok) return null;
    const j = await r.json();
    const fresh = String(j?.data?.url || j?.url || '');
    if (!fresh) return null;
    const g = await fetch(fresh, { headers: { 'user-agent': 'Mozilla/5.0' }, signal });
    if (!g.ok) return null;
    const buf = Buffer.from(await g.arrayBuffer());
    if (!buf.length) return null;
    const mime = String(g.headers.get('content-type') || '').split(';')[0].trim() || guessMime(item?.file);
    if (!/^image\//i.test(mime)) return null;
    return { dataUrl: `data:${mime};base64,${buf.toString('base64')}`, isGif: /gif/i.test(mime), gifBuffer: null };
  } catch {
    return null;
  } finally {
    done();
  }
}

/**
 * 补救一条消息的图（按 media[].file 换新鲜 url）。
 * @param {string} appRoot 应用根目录
 * @param {Array<{file?:string,url?:string}>} media 该消息的图片 media
 * @returns {Promise<Array<{dataUrl:string,isGif:boolean,gifBuffer:null}>>} 救回来的图（可能为空）
 */
export async function recoverImages(appRoot, media) {
  const items = (Array.isArray(media) ? media : [])
    .filter((m) => m && m.kind === 'image' && (m.file || m.url))
    .map((m) => ({ file: m.file || '', url: m.url || '' }));
  if (!appRoot || !items.length) return [];

  // 通道①：一次请求救全部
  const got = await viaAppApi(appRoot, items);
  const out = got.filter(Boolean);
  if (out.length) return out;

  // 通道②：逐张兜底
  for (const it of items) {
    const one = await viaOneBot(appRoot, it);
    if (one) out.push(one);
  }
  return out;
}
