// 三角洲·特勤处制造排名（LLM 型技能）
//
// 为什么是技能而不是插件：什么时候该查、查哪个台、报几个，全看用户怎么说话，
// 没有"满足某条件必然执行"的时机，所以走 registerTool + prompt 引导，
// 由模型自己判断该不该调。数据只是"报给人看"，不需要拦截或改写消息流。
//
// ══════════════════════════════════════════════════════════════════════════
// 数据源与接口（2026-10 在本机实测，勿凭记忆改动）
// ══════════════════════════════════════════════════════════════════════════
//   页面： https://orzice.com/v/rb       （三角洲小涛查「今日制造 · 补卡攻略」）
//   接口： GET /api/sjz/manufacturePro?t=<1-4>&l=<1-3>&token=<32位>&timestamp=<秒>
//          t=1 技术中心 / 2 工作台 / 3 制药台 / 4 防具台
//          l = 制造台等级，同一物品在 l=1/2/3 下的 period / price_hour 不同
//   返回： {"code":0,"message":"成功","data":"<Base64 密文>"}   ← data 是加密的，不是明文 JSON
//
//   解密后的明文结构：一段固定前缀 + 「被替换过的 Base64」
//      前缀   = 非法侵入计算机信息系统罪,我方公司保留报警和起诉权利
//      替换   = 站点把 Base64 里的部分数字换成了带 | 的短串（见 SUBST 表），
//               还原后再 Base64 解码，才是真正的 JSON 数组
//   每一项： { name, period_1/2/3(小时), price(总收益), price_hour_1/2/3(每小时收益),
//             priceMax(卖价), priceCB(材料成本), sxf(手续费), unlockLevel(需要几级台),
//              grade, objectID, place, require[](材料清单) }
//   页面渲染口径 = 本技能口径：先按 unlockLevel 过滤（等级不够造不了），
//   再按 price（总收益）或 price_hour（每小时）降序取前几名。
//
// ── 签名（把站点自身的 CryptoJS.MD5 入口拦下来实测得出，13 组样本全部复算通过）──
//   token = md5( timestamp + md5(参数串 + timestamp + AC) + 签名后缀 )
//     · 参数串 = 除 token/timestamp 外的查询串，**顺序敏感**，站点发的是 "t=1&l=3"
//     · AC     = **页面 HTML 里内联的**，形如 var AC = "b192fa…"（会轮换，必须现读）
//     · 签名后缀 = 私自使用，后果自负！我方保留起诉权利！
//     · timestamp 不是把 HTML 里的 TimeUnix 原样拿来用：站点用 GetTimeUnix() 按
//       本机时钟推进（TimeUnix + 已过去秒数），所以这里也按偏移量实时算。
//
// ── 加密参数也是页面下发的（每次都不同，必须现读 HTML）───────────────────────
//   var AA = "…"  → AES 密钥（32 字符，UTF-8 直接当 key）
//   var AB = "…"  → AES 初始向量（16 字符）
//   AES-256-CBC + Pkcs7，密文是标准 Base64。
//   ⚠️ 别把两个"水印"搞混：参与签名的是「私自使用，后果自负！…」，
//      解密明文的前缀是「非法侵入计算机信息系统罪,…」。混了就是一路 403 / 解不开。
//
// ── UA 与 Referer：反抓取规则的关键（单变量对照实测，逐条对过）────────────────
//   自称 Chrome / Safari / curl / python-requests / node-fetch / Googlebot，或干脆
//   不带 UA —— 一律 403；只有 jsdom 那个 UA + Accept + Referer 稳定 200。
//   Referer 是必需项（去掉就 403）。与签名无关：用站点自己 JS 算的 token，
//   配 Chrome UA 照样被 403。站点拦的是"冒充浏览器但不完整"和"未登记的自动化客户端"。
//   默认值就用它；站点以后若改规则，可以在技能设置里换（userAgent）。
//
// ── 请求纪律 ─────────────────────────────────────────────────────────────
//   一次刷新 = 1 个页面（取签名/加密参数）+ 最多 4 个接口，串行且间隔 400ms；
//   默认缓存 15 分钟；一旦吃到 403 就冷却（默认 15 分钟）不再重试，并优先拿旧快照答，
//   绝不"重试到通"—— 403 的响应体是空的，也不能当成"特勤处没数据"转述。
//
// 依赖：只用 node:crypto / node:fs / node:path，无第三方包。快照落在
// <数据目录>/teqinchu-rank/state.json（数据目录优先取核心的 DATA_DIR）。

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';

const SITE = 'https://orzice.com';
const PAGE_PATH = '/v/rb';
const API_PATH = '/api/sjz/manufacturePro';

// 参与签名的后缀（与解密明文前缀是两回事，见文件头）
const SIGN_SUFFIX = '私自使用，后果自负！我方保留起诉权利！';
// 解密后明文的前缀
const DATA_PREFIX = '非法侵入计算机信息系统罪,我方公司保留报警和起诉权利';
// 站点把 Base64 里这些字符替换成了带 | 的短串（原字符 → 替换串）。
// 来源：站点的全局变量 aaa（UrlDecBase64 用它对每个替换串做 replaceAll 还原）。
// 注意 6 和 7 没被替换。
const SUBST = [
  ['=', '*|'],
  ['1', 'aa|a'],
  ['2', 'ab|a'],
  ['3', 'ba|a'],
  ['4', 't|tc'],
  ['5', 't|ts'],
  ['8', 'r|oq'],
  ['9', 'f|oz'],
  ['0', 'j|rz']
];

const PLACES = { 1: '技术中心', 2: '工作台', 3: '制药台', 4: '防具台' };
const PLACE_ALIAS = {
  '1': 1, '技术中心': 1, '技术': 1, tech: 1,
  '2': 2, '工作台': 2, workbench: 2,
  '3': 3, '制药台': 3, '制药': 3,
  '4': 4, '防具台': 4, '防具': 4
};

// 实测唯一能穿过站点反抓取规则的标识（详见文件头）；设置里可覆盖
const DEFAULT_UA = 'Mozilla/5.0 (win32) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/30.1.2';
let uaCurrent = DEFAULT_UA;

// ── 登录凭证（可选）─────────────────────────────────────────────────────
// 站点对**未登录**的数据接口有免费额度，用光就回 code=400「请登录账号！才可以使用功能！」。
// 浏览器里登录跟机器人是两条通道：机器人发请求时不带浏览器的登录状态，所以要"借用"过来。
// 支持两种粘贴形式（都从浏览器 F12 里拿）：
//   ① 直接粘 Cookie 字符串；
//   ② 直接粘 DevTools 里「Copy as cURL」的整段文本 —— 自动从里面挑出登录相关的头。
// 只挑下面这些头，Host / Content-Length / Sec-* / Accept-Encoding 之类一概不用（有些还会
// 把请求搞坏）。凭证只存在本机配置里，不外发到任何别的地方。
const CRED_HEADER_ALLOW = new Set([
  'cookie', 'login-token', 'accesstoken', 'access-token', 'authorization',
  'x-csrf-token', 'token', 'user-token', 'bilibili'
]);
let credHeaders = null;
let credNote = '';          // 填了凭证却没解析出登录头时，给用户一句明确提醒（别静默当匿名）

/**
 * 解析用户粘贴的登录凭证。返回 headers 对象，或 null。
 * 容错点（都是实际踩过的）：
 *   · Windows 的「Copy as cURL (cmd)」会把引号写成 ^"，先还原成普通引号；
 *   · 只挑允许的头，Host、Content-Length、Sec- 开头的一系列、Accept-Encoding 之类一概不带
 *     （带了反而可能把请求搞坏，或让 WAF 又不认）；
 *   · 粘贴内容里一个登录头都没有（最常见：复制成了图片/页面请求），返回 null 并留提醒。
 */
function parseCredential(raw) {
  const text = String(raw || '').trim();
  if (!text) return null;
  const normalized = text.replace(/\^"/g, '"').replace(/\^'/g, "'");
  const looksCurl = /^curl\s/i.test(normalized) || normalized.includes(' -H ') || normalized.includes('--url');
  if (!looksCurl) return { cookie: text };          // 就当是直接的 Cookie 字符串

  const headers = {};
  const re = /-H\s+(['"])([\s\S]*?)\1/g;
  let m;
  while ((m = re.exec(normalized)) !== null) {
    const line = m[2];
    const idx = line.indexOf(':');
    if (idx <= 0) continue;
    const name = line.slice(0, idx).trim().toLowerCase();
    const value = line.slice(idx + 1).trim();
    if (!CRED_HEADER_ALLOW.has(name) || !value) continue;
    headers[name] = value;
  }
  if (!Object.keys(headers).length) {
    credNote = '技能设置里填了「登录凭证」，但里面没解析出可用的登录信息（Cookie/Token 一个都没有，可能是复制成了图片或页面请求），这次仍按匿名访问。';
    return null;
  }
  return headers;
}

// ── 由 api 注入 ─────────────────────────────────────────────────────────
let cfg = () => ({});
let httpFetch = null;
let logger = { log: () => {}, warn: () => {}, error: () => {} };

let stateDir = null;   // setup 时解析
let stateFile = null;

// 进程内缓存与冷却状态
let mem = { at: 0, level: 0, sortBy: '', payload: null, changes: null };
let blockedUntil = 0;
let blockedNote = '';
let blockCount = 0;        // 连续被拦次数：用来做"越撞越等久"的递增冷却（保护站点免费额度）
let fetchTimes = [];       // 最近一小时内真正联网抓取的时刻，用于每小时次数上限

// ── 小工具 ──────────────────────────────────────────────────────────────
const md5Hex = (s) => crypto.createHash('md5').update(String(s), 'utf8').digest('hex');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function clamp(n, lo, hi, dflt) {
  const v = Number(n);
  if (!Number.isFinite(v)) return dflt;
  return Math.min(hi, Math.max(lo, Math.round(v)));
}

/** 千分位：游戏币数字都很大，不加分隔符群友数不清。 */
function fmtInt(n) {
  const v = Math.round(Number(n) || 0);
  return v.toLocaleString('en-US');
}

/** 收益带符号：负数（亏本）必须显示出来，这是最有用的信息。 */
function fmtGain(n) {
  const v = Math.round(Number(n) || 0);
  return (v > 0 ? '+' : '') + fmtInt(v);
}

/** 小时数：4 / 4.5 / 6.75 这种，别显示成 4.0。 */
function fmtHours(n) {
  const v = Number(n);
  if (!Number.isFinite(v)) return '?';
  return String(Math.round(v * 100) / 100);
}

/** 服务器时间戳（秒）→ 北京时间文本，用来告诉群友"这是几点的数据"。 */
function fmtServerTime(ts) {
  const ms = Number(ts) * 1000;
  if (!Number.isFinite(ms) || ms <= 0) return '未知时间';
  try {
    return new Intl.DateTimeFormat('zh-CN', {
      timeZone: 'Asia/Shanghai', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', hour12: false
    }).format(new Date(ms));
  } catch { return new Date(ms).toISOString().slice(5, 16).replace('T', ' '); }
}

/** "多久之前"的人话表述。 */
function agoText(ms) {
  const d = Math.max(0, Date.now() - Number(ms || 0));
  const min = Math.floor(d / 60000);
  if (min < 1) return '刚刚';
  if (min < 60) return `${min} 分钟前`;
  const h = Math.floor(min / 60);
  if (h < 24) return `${h} 小时前`;
  return `${Math.floor(h / 24)} 天前`;
}

/**
 * 这一份还能用多久（给文案用）：把剩余毫秒说成人话。
 */
function leftText(at, windowMs) {
  const min = Math.round(Math.max(0, windowMs - (Date.now() - at)) / 60000);
  if (min >= 120) return `${(min / 60).toFixed(1)} 小时`;
  if (min >= 1) return `${min} 分钟`;
  return '不到 1 分钟';
}

/** 被拦之后要等多久：连续被拦就翻倍（15 → 30 → 60 → 最多 120 分钟），别反复去撞站点额度。 */
function nextCooldownMs(baseMs) {
  blockCount += 1;
  const wait = Math.min(baseMs * Math.pow(2, blockCount - 1), 120 * 60000);
  return wait;
}

/** 把"被站点拒绝"的原始原因翻译成群友能看懂的话。 */
function blockReasonText(raw) {
  const s = String(raw || '');
  if (/登录/.test(s)) {
    return '数据源（orzice.com）对未登录的免费查询有额度限制，这会儿额度用完了，它要求登录才继续给数据';
  }
  if (/403/.test(s)) return '数据源（orzice.com）的反抓取规则把这次请求拦下了';
  return `数据源拒绝了这次请求（${s || '原因未知'}）`;
}

// ── 签名与解密 ──────────────────────────────────────────────────────────
/** token = md5(timestamp + md5(参数串 + timestamp + AC) + 签名后缀) */
function signToken(paramString, ts, ac) {
  return md5Hex(String(ts) + md5Hex(String(paramString) + String(ts) + String(ac)) + SIGN_SUFFIX);
}

/** 从页面 HTML 里取本次下发的签名/加密参数与服务器时间。取不到说明站点改版了。 */
function parseCreds(html) {
  const pick = (name) => {
    const m = String(html).match(new RegExp(`var\\s+${name}\\s*=\\s*"([^"]*)"`));
    return m ? m[1] : null;
  };
  const tsMatch = String(html).match(/TimeUnix\s*=\s*(\d{9,12})/);
  const creds = { timeUnix: tsMatch ? Number(tsMatch[1]) : null, aa: pick('AA'), ab: pick('AB'), ac: pick('AC') };
  if (!creds.timeUnix || !creds.aa || !creds.ab || !creds.ac) {
    return { error: '页面里没找到 TimeUnix/AA/AB/AC（站点可能改版了）' };
  }
  return { creds };
}

/**
 * 实时服务器时间：站点自己也是这么算的（GetTimeUnix = TimeUnix + 已过去秒数）。
 * 直接把 HTML 里的 TimeUnix 拿去签名，一旦隔了几秒就可能被判过期。
 */
function serverNow(creds, credsFetchedAt) {
  const elapsed = Math.max(0, Math.round((Date.now() - credsFetchedAt) / 1000));
  // 站点自己的容错是 30 天，这里只防本地时钟被改动导致的离谱偏移
  return String(creds.timeUnix + Math.min(elapsed, 3600));
}

/**
 * 解接口的 data：AES-256-CBC → 去前缀 → 还原被替换的字符 → Base64 解码 → JSON。
 * 任一步失败都返回 error（宁可如实报"数据源格式变了"，也不要给模型半个结果）。
 */
function decryptData(dataB64, creds) {
  try {
    const key = Buffer.from(creds.aa, 'utf8');
    const iv = Buffer.from(String(creds.ab).padEnd(16, '\0').slice(0, 16), 'utf8');
    const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
    const plain = Buffer.concat([
      decipher.update(Buffer.from(String(dataB64), 'base64')),
      decipher.final()
    ]).toString('utf8');

    let body = plain.startsWith(DATA_PREFIX) ? plain.slice(DATA_PREFIX.length) : plain;
    for (const [orig, junk] of SUBST) {
      if (body.includes(junk)) body = body.split(junk).join(orig);
    }
    const text = Buffer.from(body, 'base64').toString('utf8');
    const json = JSON.parse(text);
    const list = Array.isArray(json) ? json : (Array.isArray(json?.data) ? json.data : null);
    if (!list) return { error: '解密出来了，但结构不是数组（站点可能改版了）' };
    return { items: list };
  } catch (e) {
    return { error: `解密失败：${e.message}（站点可能升级了加密方式）` };
  }
}

// ── HTTP ────────────────────────────────────────────────────────────────
/**
 * 一次 GET。返回 { text } 或 { error, status, blocked }。
 *
 * 重试纪律：只在连接层失败（fetch reject / 超时）时重试一次；HTTP 状态码是服务器的
 * 明确回答，绝不重试 —— 403 重试只会让站点把拦截拉长，而且 403 的响应体是空的。
 */
async function getText(url, { timeoutMs, accept = 'application/json, text/plain, */*', retry = 1 } = {}) {
  const attempt = async () => {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await httpFetch(url, {
        method: 'GET',
        signal: ctrl.signal,
        redirect: 'follow',
        headers: {
          'User-Agent': uaCurrent,
          'Accept': accept,
          // Referer 不是礼貌问题，是必需项：实测去掉就 403
          'Referer': `${SITE}${PAGE_PATH}`,
          // 配置了登录凭证就带上（没配就是匿名访问，走站点自己的免费额度）
          ...(credHeaders || {})
        }
      });
      const body = await res.text();
      if (res.status === 403 || res.status === 429) {
        return { error: `HTTP ${res.status}（被站点反抓取规则拦下）`, status: res.status, blocked: true };
      }
      if (!res.ok) return { error: `HTTP ${res.status}`, status: res.status };
      if (!body) return { error: '空响应', transient: true };
      return { text: body };
    } catch (e) {
      const msg = e?.name === 'AbortError' ? `超时（${timeoutMs}ms）` : (e?.message ?? String(e));
      return { error: `网络失败：${msg}`, transient: true };
    } finally {
      clearTimeout(timer);
    }
  };

  let out = await attempt();
  if (out.transient && retry > 0) {
    logger.warn('teqinchu-rank: 瞬时网络故障，800ms 后重试一次：%s', url);
    await sleep(800);
    out = await attempt();
  }
  return out;
}

/** 抓页面取参数（每次联网刷新第一个请求）。 */
async function getCreds(timeoutMs) {
  const r = await getText(`${SITE}${PAGE_PATH}`, { timeoutMs, accept: 'text/html,application/xhtml+xml' });
  if (r.error) return r;
  const parsed = parseCreds(r.text);
  if (parsed.error) return parsed;
  return { creds: parsed.creds, fetchedAt: Date.now() };
}

/** 抓一个制造台（签名 → 取密文 → 解密）。 */
async function fetchPlace(t, level, creds, credsFetchedAt, timeoutMs) {
  const paramString = `t=${t}&l=${level}`;
  const ts = serverNow(creds, credsFetchedAt);
  const url = `${SITE}${API_PATH}?${paramString}&token=${signToken(paramString, ts, creds.ac)}&timestamp=${ts}`;
  const r = await getText(url, { timeoutMs });
  if (r.error) return r;

  let json = null;
  try { json = JSON.parse(r.text); } catch (e) { return { error: `接口返回的不是合法 JSON：${e.message}` }; }
  if (json?.code !== 0) {
    const msg = String(json?.message || json?.msg || '').trim();
    // 站点对密集访问会直接回 code=400「请登录账号！才可以使用功能！」——
    // 这是它的访问频率限制，不是"没数据"。这类回复要当成"被挡"，走冷却，
    // 否则每次追问都会再打一遍，越打越久。
    const throttled = /登录|频繁|限制|稍后|太快|过多/.test(msg);
    return {
      error: msg ? `数据源拒绝：${msg}` : `数据源拒绝：code=${json?.code}`,
      blocked: throttled,
      throttled
    };
  }
  if (!json?.data) return { error: '接口没返回数据体（data 为空）' };

  const dec = decryptData(json.data, creds);
  if (dec.error) return { error: dec.error };
  return { items: dec.items };
}

// ── 排序与展示口径（与网页一致）──────────────────────────────────────────
/**
 * 把接口原始项整理成"按指定等级可造"的排行。
 * 过滤规则照抄页面：unlockLevel > 等级 的物品直接不显示（造不了，报出来是误导）。
 */
function rankItems(items, level, sortBy, topN) {
  const usable = (items || []).filter((it) => {
    const need = Number(it?.unlockLevel ?? 1);
    if (Number.isFinite(need) && need > level) return false;
    const period = Number(it?.[`period_${level}`]);
    return Number.isFinite(period) && period > 0;
  });
  const key = sortBy === 'hour' ? `price_hour_${level}` : 'price';
  usable.sort((a, b) => (Number(b?.[key]) || 0) - (Number(a?.[key]) || 0));
  return usable.slice(0, topN).map((it) => ({
    name: String(it?.name ?? '未知物品').trim(),
    period: Number(it?.[`period_${level}`]) || 0,
    price: Number(it?.price) || 0,
    priceHour: Number(it?.[`price_hour_${level}`]) || 0,
    need: Number(it?.unlockLevel ?? 1) || 1
  }));
}

// ── 落盘（快照，用于回答"这次更新变了什么"）────────────────────────────────
function readState() {
  try {
    const raw = fs.readFileSync(stateFile, 'utf8');
    const j = JSON.parse(raw.charCodeAt(0) === 0xfeff ? raw.slice(1) : raw);
    return j && typeof j === 'object' ? j : {};
  } catch { return {}; }
}

function writeState(state) {
  try {
    fs.mkdirSync(stateDir, { recursive: true });
    const tmp = `${stateFile}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(state, null, 1), 'utf8');
    fs.renameSync(tmp, stateFile);
  } catch (e) {
    logger.warn('teqinchu-rank: 快照写入失败（不影响本次回答）：%s', e?.message ?? e);
  }
}

/**
 * 对比同一等级、同一排序口径的上一次快照，产出人话版变化说明。
 *
 * @param {number} depth 对比深度：只比本次真正要报的前 depth 名。
 *   快照里存的是全量榜单，拿全量比会出现"报告写着前 4 名、变化说明却说掉出前 5 名"。
 */
function describeChanges(prevSnap, currPlaces, sortBy, depth = 4) {
  if (!prevSnap || !prevSnap.places) return null;
  if (prevSnap.sortBy && prevSnap.sortBy !== sortBy) return null;
  const d = Math.max(1, Number(depth) || 4);
  const lines = [];
  for (const t of Object.keys(currPlaces)) {
    const nowTop = (currPlaces[t].top || []).slice(0, d);
    const oldTop = (prevSnap.places?.[t]?.top || []).slice(0, d);
    if (!oldTop.length) continue;
    const oldNames = new Set(oldTop.map((x) => x.name));
    const newNames = new Set(nowTop.map((x) => x.name));
    const placeName = PLACES[t] || t;

    const entered = nowTop.filter((x) => !oldNames.has(x.name)).map((x) => x.name);
    const left = oldTop.filter((x) => !newNames.has(x.name)).map((x) => x.name);
    if (oldTop[0]?.name && nowTop[0]?.name && oldTop[0].name !== nowTop[0].name) {
      lines.push(`${placeName}：第 1 名 ${oldTop[0].name} → ${nowTop[0].name}`);
    } else if (oldTop[0]?.name && nowTop[0]?.name) {
      const dv = nowTop[0].price - oldTop[0].price;
      if (Math.abs(dv) >= 500) {
        lines.push(`${placeName}：第 1 名还是「${nowTop[0].name}」，收益 ${fmtGain(dv)}`);
      }
    }
    if (entered.length) lines.push(`${placeName}：新进榜 ${entered.slice(0, 3).join('、')}`);
    if (left.length) lines.push(`${placeName}：掉出前 ${d} 名 ${left.slice(0, 3).join('、')}`);
  }
  return lines;
}

// ── 报告拼装 ────────────────────────────────────────────────────────────
/**
 * 输出分两段：
 *   第一段 = **要发出去的内容**：每个制造台一条消息（一行一条），按顺序依次发送；
 *            金额按排序口径给：默认「总收益」，切成按每小时时才给「X/小时」。
 *            例：`工作台今日头名是 4.6x30mm AP SX（8h），总收益 261,106`
 *   第二段 = 标了【仅参考】的备注（数据时间、异常、与上次相比的变化），给模型看，别发出去。
 */
function buildReport({ payload, changes, staleNote }) {
  const { serverTs, fetchedAt, level, sortBy, places } = payload;
  const byHour = sortBy === 'hour';

  // 台与台的先后：按"该台头名"的口径值从高到低（默认总收益，和网站一致）
  const order = ['1', '2', '3', '4'].filter((t) => places[t]);
  const headValue = (t) => {
    const it = (places[t]?.top || [])[0];
    if (!it) return -Infinity;
    return byHour ? it.priceHour : it.price;
  };
  order.sort((a, b) => headValue(b) - headValue(a));

  // 第一段：一行 = 一条消息
  const lines = order.map((t) => {
    const it = (places[t]?.top || [])[0];
    if (!it) return `${PLACES[t]}今天这批数据里没合适的，等会儿再问一次`;
    const money = byHour ? `${fmtInt(it.priceHour)}/小时` : `总收益 ${fmtInt(it.price)}`;
    return `${PLACES[t]}今日头名是 ${it.name}（${fmtHours(it.period)}h），${money}`;
  });

  // 第二段：只给模型看的参考信息
  const notes = [`数据时间 ${fmtServerTime(serverTs)}（抓取于 ${agoText(fetchedAt)}）· 制造${level}级 · ${byHour ? '按每小时收益选头名' : '按总收益选头名'}`];
  if (staleNote) notes.push(`注意：${staleNote}`);
  for (const t of order) {
    if (!(places[t]?.top || []).length && places[t]?.error) notes.push(`${PLACES[t]}：${places[t].error}`);
  }
  if (changes == null) {
    notes.push('这是第一次抓取，已存下基准；下次再问就能告诉你「比上次变了什么」。');
  } else if (changes.length) {
    notes.push(`与上次（${payload.prevAt ? agoText(payload.prevAt) : '上次'}）相比：${changes.join('；')}`);
  } else {
    notes.push('与上次相比：四个台的头名都没变。');
  }
  notes.push('发法：上面**每一行是一条单独的消息**，按顺序依次发（工具的消息参数支持传字符串数组，一次调用就能一条接一条发出去）。不要合并成一条、不要加序号、不要 @ 任何人、不要用引用回复，也不要补开场白或总结。这一段是给你参考的，不要发出去。');

  return `${lines.join('\n')}\n\n【仅参考·不要发出】\n${notes.join('\n')}`;
}

// ── 浏览器通道：打开页面，读页面自己已经算好的数据 ──────────────────────────
// 为什么需要它（2026-10 实测）：站点一边限制匿名查询额度（撞光就回「请登录账号」），
// 一边把"带登录态的**程序化**请求"按 403 拦掉 —— 只有真浏览器能用登录态。
// 所以这条路是：开一个真浏览器（无头 Edge/Chrome）→ 打开 /v/rb → 读页面里的 Vue 数据
// （AppDataVue.manufacture_Base_1..4 就是接口回来的全量列表，页面自己已经解好密了）。
// 好处：① 请求来自真浏览器，WAF 放行；② 用浏览器里的登录态，不吃匿名额度；
//       ③ 站点那套签名/加密完全不用我们管。
// 前提：这个浏览器配置里登录过一次（会自动走 QQ 一键登录，前提是这台机器上 QQ 处于登录状态）。
const BROWSER_EXE_CANDIDATES = [
  path.join(process.env['ProgramFiles(x86)'] || '', 'Microsoft/Edge/Application/msedge.exe'),
  path.join(process.env['ProgramFiles'] || '', 'Microsoft/Edge/Application/msedge.exe'),
  path.join(process.env['ProgramFiles'] || '', 'Google/Chrome/Application/chrome.exe'),
  path.join(process.env['ProgramFiles(x86)'] || '', 'Google/Chrome/Application/chrome.exe'),
  path.join(process.env.LOCALAPPDATA || '', 'Google/Chrome/Application/chrome.exe')
];

let br = null;             // 常驻浏览器：{ proc, port, exe, headless }
let brWarmTimer = null;    // 保温计时器（闲置一段时间后自己关掉，别一直占内存）
let brProfileDir = null;
let brKnownLoggedIn = null; // 进程内已知的登录状态：null=还不知道，true/false=已知
let brLockFile = null;      // 记录当前浏览器 pid，供"上次没关掉"的清扫用
let brExitHooked = false;   // 进程退出兜底只注册一次

// ── 浏览器进程的生命周期兜底（v1.2.2：**全部异步**，绝不阻塞主进程）────────────
//
// ⚠️ 为什么必须异步：这里是 Electron/Node 的**主进程**。v1.2.0/1.2.1 用 spawnSync 跑
//    `msedge --version` / tasklist / taskkill / powershell(CIM)，单次 0.5~3 秒，CIM 查询更久 ——
//    这期间整个应用**卡住不动**，用户看到的就是"窗口卡死、关不掉"。现在全部换成
//    异步 execFile + await：该等的等，但事件循环不被堵住（界面不卡、窗口能点能关）。
//
// 要堵的四个漏点：
//   ① 有窗口登录那条路失败时直接 return，可见窗口没关 → try/finally 保证关；
//   ② spawn 的 windowsHide 写成了 !headless（无头模式下反而不隐藏）→ 恒为 true；
//   ③ 应用退出时没人管浏览器 → 进程退出兜底（非阻塞：proc.kill() + fire-and-forget 的 taskkill）；
//   ④ --headless=new 只有 Chromium 112+ 认，老版本会带窗口启动 → 按版本挑旗标；
//      旧版本残留不写 lock → 另按"配置目录"清扫（技能加载后延迟 1.2 秒跑一次，不拖慢启动）。
const execFileAsync = promisify(execFile);

/** 浏览器主版本号（老版本不认 --headless=new，会带窗口启动）。异步 + 结果缓存。 */
const majorCache = new Map();
async function browserMajorVersion(exe) {
  if (majorCache.has(exe)) return majorCache.get(exe);
  let major = 0;
  try {
    const { stdout, stderr } = await execFileAsync(exe, ['--version'], { timeout: 5000, windowsHide: true });
    const m = String(stdout || stderr || '').match(/(\d+)\.\d+\.\d+/);
    major = m ? Number(m[1]) : 0;
  } catch { major = 0; }
  majorCache.set(exe, major);
  return major;
}
/** 按浏览器版本给 headless 旗标。 */
async function headlessFlagsFor(exe) {
  const major = await browserMajorVersion(exe);
  const flags = (major && major < 112) ? ['--headless'] : ['--headless=new'];
  return flags.concat([
    '--disable-gpu',
    '--disable-background-mode',              // 别挂在后台不退
    '--disable-backgrounding-occluded-windows',
    '--no-service-autorun'
  ]);
}
function writeBrowserLock(pid) {
  try {
    fs.mkdirSync(stateDir, { recursive: true });
    fs.writeFileSync(brLockFile, JSON.stringify({ pid: Number(pid) || 0, at: Date.now(), profileDir: brProfileDir }), 'utf8');
  } catch { /* ignore */ }
}
function clearBrowserLock() { try { fs.rmSync(brLockFile, { force: true }); } catch { /* ignore */ } }
function profileLockFiles() {
  return ['SingletonLock', 'SingletonCookie', 'SingletonSocket'].map((f) => path.join(brProfileDir || path.join(stateDir, 'browser-profile'), f));
}
/** 这个 pid 还是不是浏览器进程（防止 pid 复用误杀别人的程序）。异步。 */
async function isBrowserPid(pid) {
  try {
    const { stdout } = await execFileAsync('tasklist', ['/FI', `PID eq ${Number(pid)}`, '/FO', 'CSV', '/NH'], { timeout: 5000, windowsHide: true });
    return /msedge\.exe|chrome\.exe/i.test(String(stdout || ''));
  } catch { return false; }
}
/** 强杀**整棵进程树**（异步）：只 kill 主进程会留下 crashpad/GPU 子进程。 */
async function killTree(pid) {
  const n = Number(pid);
  if (!n) return;
  try { await execFileAsync('taskkill', ['/PID', String(n), '/T', '/F'], { timeout: 8000, windowsHide: true }); } catch { /* ignore */ }
}
/**
 * 立刻返回版：**进程退出钩子里用**。那时不能 await、更不能阻塞（阻塞 = 应用关了窗口还留着），
 * 所以 detached + unref 把它甩出去，让 taskkill 自己跑完。
 */
function killTreeDetached(pid) {
  const n = Number(pid);
  if (!n) return;
  try {
    const p = spawn('taskkill', ['/PID', String(n), '/T', '/F'], { stdio: 'ignore', windowsHide: true, detached: true });
    p.unref?.();
  } catch { /* ignore */ }
}
/** 清扫上一次没关掉的浏览器（应用被强杀留下的），并清残留单实例锁。 */
async function sweepStaleBrowser() {
  try {
    if (brLockFile && fs.existsSync(brLockFile)) {
      const j = JSON.parse(fs.readFileSync(brLockFile, 'utf8'));
      const pid = Number(j?.pid) || 0;
      if (pid && await isBrowserPid(pid)) {
        logger.warn('teqinchu-rank: 发现上次没关掉的浏览器（PID %s），正在清掉', pid);
        await killTree(pid);
      }
      clearBrowserLock();
    }
  } catch { /* ignore */ }
  for (const f of profileLockFiles()) { try { fs.rmSync(f, { force: true }); } catch { /* ignore */ } }
}
/** 应用退出/被中断时的兜底：**非阻塞**地收掉浏览器，别留窗口。 */
function installExitHook() {
  if (brExitHooked) return;
  brExitHooked = true;
  const kill = () => {
    const pid = br?.proc?.exitCode === null ? br.proc.pid : 0;
    try { if (pid) br.proc.kill(); } catch { /* ignore */ }   // 先给主进程一发（瞬时，不阻塞）
    if (pid) killTreeDetached(pid);                            // 子树交给独立的 taskkill，不等它
    clearBrowserLock();
  };
  try { process.once('exit', kill); } catch { /* ignore */ }
  for (const sig of ['SIGINT', 'SIGTERM', 'SIGHUP']) {
    try { process.once(sig, () => { kill(); }); } catch { /* 某些信号平台不支持 */ }
  }
}
/**
 * 清扫**所有**正在使用我们这份配置目录的浏览器进程 —— 不依赖 browser.lock。
 *
 * 为什么必须有这一条：v1.1.0 及更早的版本**根本不写 lock**，只按 lock 清扫的话，
 * 那些老版本留在桌面上的窗口永远清不掉（用户报的"还有残留窗口关不掉"就是这个）。
 * 做法：查 msedge/chrome 的命令行里有没有我们这个 profile 路径，有就整棵树强杀。
 * 异步 + 调用方不 await（见 setup），所以不会拖慢应用启动。
 */
async function sweepBrowsersByProfile(profileDir) {
  const dir = profileDir || path.join(stateDir, 'browser-profile');
  if (!dir) return [];
  // ⚠️ 我们自己正在用浏览器时**不清扫**：命令行里区分不出"我们自己的子进程（渲染/GPU，
  //    同样带这个 profile）"和"上次留下的残留进程"，硬清会把正在读数据的那一次打断。
  //    那种情况下留给"用完关闭"和"下次启动的 lock 清扫"处理。
  if (br?.proc && br.proc.exitCode === null) return [];
  const esc = String(dir).replace(/'/g, "''");
  const ps = 'Get-CimInstance Win32_Process -Filter "Name=\'msedge.exe\' or Name=\'chrome.exe\'" | '
    + `Where-Object { $_.CommandLine -and $_.CommandLine.Contains('${esc}') } | `
    + 'Select-Object -ExpandProperty ProcessId';
  let stdout = '';
  try {
    const r = await execFileAsync('powershell.exe',
      ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', ps],
      { timeout: 20000, windowsHide: true, maxBuffer: 1024 * 1024 });
    stdout = String(r?.stdout || '');
  } catch { return []; }
  const pids = stdout.split(/\s+/).map((s) => Number(s)).filter((n) => Number.isInteger(n) && n > 0);
  const current = Number(br?.proc?.pid) || 0;      // 别把自己正在用的那个杀了
  const killed = [];
  for (const pid of pids) {
    if (pid === current) continue;
    if (!await isBrowserPid(pid)) continue;        // 只见 msedge/chrome 才动手（防 pid 复用误杀）
    logger.warn('teqinchu-rank: 清掉一个还挂着的浏览器进程（PID %s）', pid);
    await killTree(pid);
    killed.push(pid);
  }
  // 顺手把可能残留的单实例锁清掉，免得下次登录被锁挡住
  for (const f of profileLockFiles()) { try { fs.rmSync(f, { force: true }); } catch { /* ignore */ } }
  return killed;
}
function findBrowserExe(override) {
  if (override && fs.existsSync(override)) return override;
  for (const p of BROWSER_EXE_CANDIDATES) { if (p && fs.existsSync(p)) return p; }
  return null;
}

/** 统一 ws / globalThis.WebSocket 两套 API 的差异（Node 20 没有全局 WebSocket）。 */
async function wsConnect(url, timeoutMs = 8000) {
  let Impl = globalThis.WebSocket;
  if (!Impl) {
    try { Impl = (await import('ws')).WebSocket || (await import('ws')).default; } catch { /* 下面报错 */ }
  }
  if (!Impl) throw new Error('运行环境没有可用的 WebSocket（无法连接浏览器调试端口）');
  const sock = new Impl(url);
  const handlers = new Map();          // id → { resolve, reject, timer }：一个连接只挂一个监听器
  const onRaw = (raw) => {
    let m; try { m = JSON.parse(String(raw)); } catch { return; }
    const h = handlers.get(m.id);
    if (!h) return;
    handlers.delete(m.id);
    clearTimeout(h.timer);
    if (m.error) h.reject(new Error(m.error.message || 'CDP 报错'));
    else h.resolve(m.result);
  };
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('连接浏览器调试端口超时')), timeoutMs);
    const ok = () => { clearTimeout(timer); resolve(); };
    const bad = (e) => { clearTimeout(timer); reject(e instanceof Error ? e : new Error(String(e))); };
    if (typeof sock.on === 'function') {
      sock.on('open', ok);
      sock.on('error', bad);
      sock.on('message', onRaw);
    } else {
      sock.onopen = ok;
      sock.onerror = () => bad(new Error('连接浏览器调试端口失败'));
      sock.onmessage = (ev) => onRaw(ev.data);
    }
  });
  return {
    handlers,
    send: (s) => sock.send(s),
    close: () => { for (const h of handlers.values()) clearTimeout(h.timer); handlers.clear(); try { sock.close(); } catch { /* ignore */ } }
  };
}

/** 发一条 CDP 命令并等回包。 */
function cdpCall(conn, method, params = {}, timeoutMs = 10000) {
  const id = ++cdpCall.seq;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { conn.handlers.delete(id); reject(new Error(`${method} 超时`)); }, timeoutMs);
    conn.handlers.set(id, { resolve, reject, timer });
    conn.send(JSON.stringify({ id, method, params }));
  });
}
cdpCall.seq = 0;

async function ensureBrowser(exePath, keepWarmSec, timeoutMs, headless = true) {
  if (br && br.proc && br.proc.exitCode === null && br.headless === headless) return br;
  if (br) await closeBrowser();                    // 模式变了（比如要做登录）就换一个
  const exe = findBrowserExe(exePath);
  if (!exe) return { error: '没找到 Edge 或 Chrome（可在技能设置里填浏览器路径）' };
  const port = 9300 + Math.floor(Math.random() * 500);
  brProfileDir = path.join(stateDir, 'browser-profile');
  fs.mkdirSync(brProfileDir, { recursive: true });
  // 只有"当前没有浏览器"时才清扫：把上次没关掉的残留（包括可见窗口）先干掉，免得越攒越多
  await sweepStaleBrowser();
  installExitHook();
  logger.log('teqinchu-rank: 启动浏览器通道（%s）', headless ? '无头' : '有窗口·登录用');
  const args = [
    `--remote-debugging-port=${port}`,
    `--user-data-dir=${brProfileDir}`,
    '--no-first-run', '--no-default-browser-check', '--disable-sync', '--disable-extensions',
    '--window-size=1280,1000'
  ];
  if (headless) args.push(...(await headlessFlagsFor(exe)));
  // 有窗口模式只为了一次性完成 QQ 一键登录：**必须可见**（实测挪到屏幕外，
  // QQ 一键登录就不会完成，会一直卡在 graph.qq.com 那一页）。
  // 所以这里用一个小窗口露在屏幕角上，登录成功后立刻关掉，不影响后续读数据（读数据走无头）。
  else args.push('--window-size=560,460', '--window-position=40,40');
  args.push('about:blank');
  // ⚠️ windowsHide 恒为 true：这个参数只管"要不要给子进程开控制台窗口"，跟浏览器自己的
  //    窗口无关（登录用的可见窗口照样显示）。以前写成 !headless，无头模式下反而是 false —— 写反了。
  const proc = spawn(exe, args, { stdio: 'ignore', windowsHide: true });
  proc.unref?.();                                  // 别让浏览器把宿主进程/事件循环拖住
  proc.on('exit', () => { if (br && br.proc === proc) br = null; });
  writeBrowserLock(proc.pid);
  const deadline = Date.now() + Math.min(timeoutMs, 20000);
  while (Date.now() < deadline) {
    await sleep(400);
    try {
      const r = await fetch(`http://127.0.0.1:${port}/json/version`);
      if (r.ok) { br = { proc, port, exe, headless }; scheduleBrowserClose(keepWarmSec); return br; }
    } catch { /* 还没起来 */ }
  }
  try { proc.kill(); } catch { /* ignore */ }
  await killTree(proc.pid);
  clearBrowserLock();
  return { error: '浏览器调试端口没起来（可能被安全软件拦了）' };
}

function scheduleBrowserClose(keepWarmSec) {
  if (brWarmTimer) clearTimeout(brWarmTimer);
  brWarmTimer = setTimeout(() => { closeBrowser().catch(() => {}); }, Math.max(30, keepWarmSec) * 1000);
  brWarmTimer.unref?.();          // 别因为它让宿主进程退不掉
}

async function closeBrowser() {
  if (brWarmTimer) { clearTimeout(brWarmTimer); brWarmTimer = null; }
  const cur = br; br = null;
  if (!cur) return;
  // ⚠️ 必须"优雅关闭"（CDP 的 Browser.close），不能直接杀进程：
  //    实测强杀会在配置目录留下残留的单实例锁，**下一次启动就再也登不上 QQ**
  //    （表现为一直卡在 graph.qq.com 登录页）——这是踩过的坑。
  try {
    const v = await (await fetch(`http://127.0.0.1:${cur.port}/json/version`)).json();
    const conn = await wsConnect(v.webSocketDebuggerUrl, 4000);
    await cdpCall(conn, 'Browser.close', {}, 3000).catch(() => {});
    conn.close();
  } catch { /* 端口已经没了就算了 */ }
  const deadline = Date.now() + 4000;
  while (cur.proc.exitCode === null && Date.now() < deadline) await sleep(300);
  if (cur.proc.exitCode === null) await killTree(cur.proc.pid);   // 整棵树杀，别留 crashpad/GPU 子进程
  clearBrowserLock();
  // 兜底：清掉可能残留的单实例锁
  if (brProfileDir) {
    for (const f of ['SingletonLock', 'SingletonCookie', 'SingletonSocket']) {
      try { fs.rmSync(path.join(brProfileDir, f), { force: true }); } catch { /* ignore */ }
    }
  }
  logger.log('teqinchu-rank: 已关闭浏览器通道（省内存）');
}

/**
 * 这个浏览器配置里有没有登录态？
 * ⚠️ 浏览器正跑着的时候，Cookie 库是被独占锁住的（读文件会失败）——所以进程内已经
 *    读到的结论优先，不会因为"读不到文件"就误判成没登录、白开一次有窗口模式（踩过）。
 */
function profileHasLoginCookie() {
  if (brKnownLoggedIn !== null) return brKnownLoggedIn;
  try {
    const p = path.join(brProfileDir || path.join(stateDir, 'browser-profile'), 'Default', 'Network', 'Cookies');
    if (!fs.existsSync(p)) return false;
    return fs.readFileSync(p).includes('cloud_token');
  } catch { return false; }
}

/** 轮询页面里的 Vue 数据，直到**要的台都有数据**（或超时，超时就返回拿到的部分）。 */
async function pollAppData(conn, timeoutMs, needIdx) {
  const expr = `(() => { try {
    const v = window.AppDataVue;
    if (!v) return null;
    const bases = [1,2,3,4].map(i => (v['manufacture_Base_' + i] || []).map(x => ({
      name: x.name, price: x.price, unlockLevel: x.unlockLevel,
      period_1: x.period_1, period_2: x.period_2, period_3: x.period_3,
      price_hour_1: x.price_hour_1, price_hour_2: x.price_hour_2, price_hour_3: x.price_hour_3
    })));
    if (!bases.some(b => b.length)) return null;
    return JSON.stringify({ bases, lv: v.lv, serverTs: (typeof TimeUnix !== 'undefined' ? TimeUnix : 0), loggedIn: !/未登录/.test(document.body.innerText || '') });
  } catch (e) { return 'ERR:' + e.message; } })()`;
  const need = (needIdx && needIdx.length ? needIdx : [0, 1, 2, 3]);
  const deadline = Date.now() + timeoutMs;
  let best = null;
  while (Date.now() < deadline) {
    try {
      const r = await cdpCall(conn, 'Runtime.evaluate', { expression: expr, returnByValue: true }, Math.min(8000, Math.max(2500, deadline - Date.now())));
      const val = r?.result?.value;
      if (typeof val === 'string' && val.startsWith('{')) {
        const parsed = JSON.parse(val);
        // 页面是四个台分开请求的，先到的可能只有一两个：必须等"要的台"都到齐再交，
        // 否则会把还没加载完的台误报成"这个台没数据"（踩过）。
        if (need.every((i) => (parsed.bases[i] || []).length)) return parsed;
        best = parsed;
      } else if (typeof val === 'string' && val.startsWith('ERR:')) {
        return { error: val.slice(4) };
      }
    } catch (e) {
      // 页面正在导航 / 执行上下文被重建时会报错，这不是失败，接着轮询就好
      logger.log('teqinchu-rank: 轮询页面数据暂时失败（%s），继续等…', e?.message ?? e);
    }
    await sleep(600);
  }
  return best;                                     // 超时：把拿到的部分交出去（缺的台会如实标注）
}

/** 读一次页面：headless 决定用无头还是有窗口；doLogin 时若没数据就先走一次登录页。 */
async function readOnce({ timeoutMs, exePath, warmSec, headless = true, doLogin = false, needIdx }) {
  const b = await ensureBrowser(exePath, warmSec, timeoutMs, headless);
  if (b.error) return { error: b.error };
  scheduleBrowserClose(warmSec);
  let conn = null; let tabId = null;
  try {
    const res = await fetch(`http://127.0.0.1:${b.port}/json/new?${encodeURIComponent(SITE + (doLogin ? '/login' : PAGE_PATH))}`, { method: 'PUT' });
    const tab = await res.json();
    tabId = tab.id;
    conn = await wsConnect(tab.webSocketDebuggerUrl);
    await cdpCall(conn, 'Runtime.enable', {}, timeoutMs);

    if (doLogin) {
      // QQ 互联：机器上 QQ 处于登录状态时，这一步会自己完成一键登录并跳回站点
      logger.log('teqinchu-rank: 走一次登录页（自动 QQ 一键登录）…');
      await sleep(12000);
      await cdpCall(conn, 'Page.navigate', { url: `${SITE}${PAGE_PATH}` }, timeoutMs).catch(() => {});
    }

    let data = await pollAppData(conn, doLogin ? 20000 : Math.min(timeoutMs, 15000), needIdx);
    if (!data && !doLogin) {
      const ck = await cdpCall(conn, 'Storage.getCookies', {}, 6000).catch(() => null);
      const hasToken = (ck?.cookies || []).some((c) => c.name === 'cloud_token');
      brKnownLoggedIn = hasToken ? true : false;
      return { error: '页面里没读到制造数据', needLogin: !hasToken };
    }
    if (!data) return { error: '页面里没读到制造数据（登录后仍无数据，可能站点改版或账号无权限）' };
    if (data.error) return { error: data.error };
    brKnownLoggedIn = data.loggedIn === true;
    return data;
  } catch (e) {
    return { error: `浏览器读取失败：${e?.message ?? e}` };
  } finally {
    try { conn?.close(); } catch { /* ignore */ }
    if (tabId) { try { await fetch(`http://127.0.0.1:${b.port}/json/close/${tabId}`); } catch { /* ignore */ } }
  }
}

/**
 * 浏览器通道读一次数据：先无头读；如果发现是"没登录"，就用一个有窗口（挪到屏幕外）的
 * 浏览器把 QQ 一键登录走完（无头模式下这一步走不通，实测），之后再读。
 */
async function browserRead({ timeoutMs, exePath, warmSec, needIdx }) {
  // 还没登录过就先别用无头：实测"无头先跑一次"会让这个配置之后再也登不上，
  // 所以没登录态时第一次就直接用有窗口（小窗，能完成 QQ 一键登录）。
  const logged = profileHasLoginCookie();
  logger.log('teqinchu-rank: 浏览器配置里%s登录态，用%s模式读取', logged ? '有' : '没有', logged ? '无头' : '有窗口');
  const first = await readOnce({ timeoutMs, exePath, warmSec, headless: logged, needIdx });
  if (!first.error) return first;
  if (!first.needLogin) return first;

  logger.log('teqinchu-rank: 浏览器里没有登录态，用有窗口模式登录一次（屏幕左上角会闪一个小窗）…');
  await closeBrowser();
  let login;
  try {
    login = await readOnce({ timeoutMs: Math.max(timeoutMs, 25000), exePath, warmSec, headless: false, doLogin: true, needIdx });
  } finally {
    // ⚠️ v1.2.0 关键修复：这个可见窗口必须**无论如何**都关掉。
    //    以前登录失败时下面直接 return，那个 560×460 的小窗就永远留在桌面上 ——
    //    这就是用户报的"问完 AI 留一个窗口、关不掉"。
    await closeBrowser();
  }
  if (!login.error) {
    logger.log('teqinchu-rank: 自动登录成功，之后会继续用无头模式');
    const again = await readOnce({ timeoutMs, exePath, warmSec, headless: true, needIdx });
    return again.error ? login : again;
  }
  return {
    error: `${first.error}；自动登录也没成功（${login.error}）。`
      + '（登录窗口已经关掉了。可以再问一次，或者到屏幕上重新走一次登录）'
  };
}

// ── 主流程：拿数据（缓存 / 冷却 / 抓取）────────────────────────────────────
/**
 * @param {number[]} placesWanted 本次真正需要联网抓的台（只问一个台时就只抓一个，
 *        省下请求次数 —— 站点有反抓取规则，少打一次少一分被拦的风险）
 */
async function loadData({ level, sortBy, timeoutMs, ttlMs, cooldownMs, force, placesWanted, depth, maxPerHour, browserMode, browserExe, browserWarmSec, windowMs, windowHours }) {
  const wanted = (placesWanted && placesWanted.length ? placesWanted : [1, 2, 3, 4]).map(String);
  const cachedHasAll = mem.payload && wanted.every((t) => mem.payload.places?.[t]);

  // 0) 时间窗模式（默认 8 小时，见 windowHours 设置）：窗口内已经抓过就直接用那一份，不联网。
  //    这里读的是**磁盘上的原始数据**，所以进程重启/应用重启也算数；而且存的是页面原始列表，
  //    因此窗口内任何等级/排序的问法都能从同一份数据里算出来，不用为换口径再抓一次。
  if (!force) {
    const raw = readState()?.raw;
    if (raw && Array.isArray(raw.bases) && Date.now() - raw.at < windowMs && wanted.every((p) => (raw.bases[Number(p) - 1] || []).length)) {
      const places = {};
      for (const p of wanted) places[p] = { top: rankItems(raw.bases[Number(p) - 1] || [], level, sortBy, 99), dataAt: raw.at };
      const st = readState();
      const snap = st?.snapshots?.[String(level)] || null;
      return {
        payload: {
          serverTs: raw.serverTs, fetchedAt: raw.at, level, sortBy, places,
          prevAt: snap?.prev?.fetchedAt || snap?.fetchedAt || raw.at, fetchedPlaces: wanted, channel: raw.channel || ''
        },
        changes: snap ? describeChanges(snap.prev, snap.places, sortBy, depth) : null,
        fromCache: true, windowed: true, fetchedAt: raw.at, leftText: leftText(raw.at, windowMs)
      };
    }
  }

  // 1) 进程内缓存：同一个窗口内也用不着天天重算
  if (!force && cachedHasAll && mem.level === level && mem.sortBy === sortBy && Date.now() - mem.at < windowMs) {
    return { payload: mem.payload, changes: mem.changes, fromCache: true, windowed: true, fetchedAt: mem.at, leftText: leftText(mem.at, windowMs) };
  }

  // 1.5) 每小时联网次数上限：站点的匿名额度是按小时算的（实测撞光后整个接口回「请登录账号」），
  //      所以给自己加一道闸，宁可这一小时里给旧数据，也别把额度打光、导致后面谁都问不到。
  fetchTimes = fetchTimes.filter((t) => Date.now() - t < 3600000);
  if (fetchTimes.length >= maxPerHour) {
    const snap = readState()?.snapshots?.[String(level)];
    if (snap) {
      const payload = {
        serverTs: snap.serverTs, fetchedAt: snap.fetchedAt, level, sortBy,
        prevAt: snap.prev?.fetchedAt || snap.fetchedAt, places: snap.places
      };
      return {
        payload, fromCache: true, cooldown: true,
        staleNote: `一小时内的查询次数已到上限（${maxPerHour} 次，防止把数据源的免费额度用光），先给你 ${agoText(snap.fetchedAt)} 抓到的排名。要强制重抓，在技能设置里调高「每小时最多抓几次」。`,
        changes: describeChanges(snap.prev, snap.places, sortBy, depth)
      };
    }
  }

  // 2) 被站点挡着（403 冷却中）：不联网，有旧数据就用旧数据（诚实标注）
  if (Date.now() < blockedUntil) {
    const snap = readState()?.snapshots?.[String(level)];
    const mins = Math.ceil((blockedUntil - Date.now()) / 60000);
    if (snap) {
      const payload = {
        serverTs: snap.serverTs, fetchedAt: snap.fetchedAt, level, sortBy,
        prevAt: snap.prev?.fetchedAt || snap.fetchedAt,
        places: snap.places
      };
      return {
        payload, fromCache: true, cooldown: true,
        staleNote: `${blockReasonText(blockedNote)}；约 ${mins} 分钟后才会再试。下面是 ${agoText(snap.fetchedAt)} 抓到的排名。`,
        changes: describeChanges(snap.prev, snap.places, sortBy, depth)
      };
    }
    return {
      error: `${blockReasonText(blockedNote)}。大约 ${mins} 分钟后可以再问一次；现在也还没有可用的旧数据，所以这次给不了排名。`,
      blocked: true
    };
  }

  // 3) 取数据：先走浏览器通道（打页面、用登录态），不行再退回直连接口
  const state = readState();
  const prevSnap = state?.snapshots?.[String(level)] || null;
  const prevAt = prevSnap?.fetchedAt || 0;
  const prevPlaces = prevSnap?.places || {};

  const places = {};
  const rawBases = [[], [], [], []];              // 页面/接口的原始列表，存下来供"当天复用"用
  let firstError = null;
  let channel = '';
  let serverTs = 0;                               // 站点侧的"数据时间"，两个通道各自给
  fetchTimes.push(Date.now());                    // 记一次请求（含失败：失败也在消耗额度）

  if (browserMode !== 'off') {
    const b = await browserRead({ timeoutMs, exePath: browserExe, warmSec: browserWarmSec, needIdx: wanted.map((p) => Number(p) - 1) });
    if (!b.error && Array.isArray(b.bases)) {
      channel = 'browser';
      serverTs = Number(b.serverTs) || 0;
      if (!b.loggedIn) logger.warn('teqinchu-rank: 浏览器通道拿到了数据，但页面显示未登录（用的可能是匿名额度）');
      for (const p of wanted) {
        const base = b.bases[Number(p) - 1] || [];
        rawBases[Number(p) - 1] = base;
        places[p] = base.length
          ? { top: rankItems(base, level, sortBy, 99), dataAt: Date.now() }
          // 页面里这个台没数据：可能是没加载完（超时了），如实标注，别当成"造不了"
          : { top: [], error: '页面上这个台的数据没加载出来（再问一次通常就好）', dataAt: 0 };
      }
    } else {
      logger.warn('teqinchu-rank: 浏览器通道不可用（%s），改用直连接口', b.error);
    }
  }

  if (!channel) {
    const c = await getCreds(timeoutMs);
    if (c.error) {
      if (c.blocked) {
        const wait = nextCooldownMs(cooldownMs);
        blockedUntil = Date.now() + wait;
        blockedNote = c.error;
      }
      return { error: `抓不到 orzice 页面：${c.error}`, blocked: !!c.blocked };
    }
    serverTs = c.creds.timeUnix;
    for (const p of wanted) {
      const r = await fetchPlace(Number(p), level, c.creds, c.fetchedAt, timeoutMs);
      if (r.error) {
        if (!firstError) firstError = { place: p, ...r };
        if (r.blocked) break;                       // 已被拦：别再接着撞
        places[p] = { top: [], error: r.error, dataAt: 0 };
      } else {
        rawBases[Number(p) - 1] = r.items || [];    // 接口回来的原始列表，形状与页面一致
        places[p] = { top: rankItems(r.items, level, sortBy, 99), dataAt: Date.now() };
      }
      await sleep(400);                             // 对数据源客气一点
    }
  }

  if (firstError && firstError.blocked) {
    const wait = nextCooldownMs(cooldownMs);
    blockedUntil = Date.now() + wait;
    blockedNote = firstError.error;
    const waitMin = Math.round(wait / 60000);
    if (prevSnap) {                               // 有旧快照就先给旧的，别让用户空手而归
      const payload = {
        serverTs: prevSnap.serverTs, fetchedAt: prevSnap.fetchedAt, level, sortBy,
        prevAt: prevSnap.prev?.fetchedAt || prevSnap.fetchedAt,
        places: prevSnap.places
      };
      return {
        payload, fromCache: true, cooldown: true,
        staleNote: `${blockReasonText(firstError.error)}；${waitMin} 分钟内不再重试。下面是 ${agoText(prevSnap.fetchedAt)} 抓到的排名（不是刚抓的）。`,
        changes: describeChanges(prevSnap.prev, prevSnap.places, sortBy, depth)
      };
    }
    return {
      error: `${blockReasonText(firstError.error)}。这不是"特勤处没数据"，大约 ${waitMin} 分钟后可以再问一次；现在也还没有可用的旧数据，所以这次给不了排名。`,
      blocked: true
    };
  }

  if (firstError && Object.keys(places).length === 0) {
    return { error: `四个制造台一个都没抓到：${firstError.error}` };
  }

  // 4) 与上次快照对比（这次抓到的台才有对比意义），合并后落盘。
  //    合并纪律：本轮没抓到、但有上次好数据的台，**保留上次的数据**（标 stale），
  //    绝不用"空 + 错误"覆盖掉上次的榜单 —— 否则下一次回答会把上次的数据当成
  //    "新进榜/掉榜"的对比基线，凭空造出一堆假变化。
  const changes = describeChanges({ places: prevPlaces, sortBy: prevSnap?.sortBy }, places, sortBy, depth);
  const mergedPlaces = { ...prevPlaces };
  for (const [k, v] of Object.entries(places)) {
    const prev = prevPlaces[k];
    if ((!v.top || !v.top.length) && v.error && prev?.top?.length) {
      mergedPlaces[k] = { top: prev.top, dataAt: prev.dataAt || prevSnap?.fetchedAt || 0, stale: true };
    } else {
      mergedPlaces[k] = v;
    }
  }

  state.snapshots = state.snapshots || {};
  state.snapshots[String(level)] = {
    savedAt: Date.now(), fetchedAt: Date.now(), serverTs, level, sortBy,
    places: mergedPlaces,
    prev: prevSnap ? { places: prevSnap.places, fetchedAt: prevSnap.fetchedAt, sortBy: prevSnap.sortBy } : null
  };
  // 原始列表另存一份：每日一次模式靠它判断"今天抓过没有"，也靠它支持当天换等级/换排序口径
  state.raw = { at: Date.now(), serverTs, channel, bases: rawBases };
  writeState(state);

  const payload = {
    serverTs, fetchedAt: Date.now(), level, sortBy,
    places: mergedPlaces, prevAt: prevAt || null, fetchedPlaces: wanted, channel
  };
  blockCount = 0;              // 抓到数据了：冷却计数归零
  const finalChanges = prevAt ? (changes || []) : null;
  mem = { at: Date.now(), level, sortBy, payload, changes: finalChanges };
  return { payload, changes: finalChanges };
}

// ── 技能入口 ────────────────────────────────────────────────────────────
// setup 可以是 async：加载器是 `await setupFn(api)`，所以这里能安全地等配置导入。
export async function setup(api) {
  cfg = typeof api.config === 'function' ? api.config : () => ({});
  httpFetch = typeof api.fetch === 'function' ? (...args) => api.fetch(...args) : null;
  logger = {
    log: typeof api.log === 'function' ? (...a) => api.log(...a) : () => {},
    warn: typeof api.warn === 'function' ? (...a) => api.warn(...a) : () => {},
    error: typeof api.error === 'function' ? (...a) => api.error(...a) : () => {}
  };

  // 数据目录：优先用核心的 DATA_DIR（可能被 QQ_AGENT_DATA_DIR 覆盖），取不到就退回
  // <安装目录>/data —— 与核心默认一致。import 用 try 包住：核心以后改名/改导出都不会
  // 连累本技能加载失败（历史上就有插件因为 import 核心内部函数而整个技能加载不起来）。
  stateDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', 'data', 'teqinchu-rank');
  try {
    const m = await import('../../src/config.js');
    if (m?.DATA_DIR) stateDir = path.join(m.DATA_DIR, 'teqinchu-rank');
  } catch { /* 用兜底路径，不影响功能，只是快照换个地方存 */ }
  stateFile = path.join(stateDir, 'state.json');
  brLockFile = path.join(stateDir, 'browser.lock');   // 记录浏览器 pid：应用被强杀后下次启动清扫

  // v1.2.1：**加载时就清一次**。老版本（v1.1.0 及更早）不写 lock，光靠 lock 清扫不掉它们
  // 留在桌面上的窗口；所以这里按"配置目录"把所有还在用这份 profile 的浏览器进程清掉 ——
  // 技能一加载（含热重载）就生效，不用等下一次查询。
  try {
    // 延迟 1.2 秒、且**不 await**：① 不拖慢应用启动（要清的是历史残留，不急这几百毫秒）；
    // ② 避开"启动瞬间正好在抓数据"的竞态（sweepBrowsersByProfile 内部还会跳过当前在用的那个）。
    const timer = setTimeout(() => {
      sweepBrowsersByProfile(path.join(stateDir, 'browser-profile'))
        .then((killed) => { if (killed.length) logger.warn('teqinchu-rank: 启动检查清掉了 %s 个残留浏览器进程', killed.length); })
        .catch(() => {});
    }, 1200);
    timer.unref?.();
  } catch { /* 清理失败不影响功能 */ }

  api.registerTool({
    id: 'manufacture_rank',
    name: '特勤处制造排名',
    category: 'knowledge',
    icon: '🏭',
    description: '用无头浏览器打开 orzice.com/v/rb（三角洲小涛查）的「今日制造」页面，读页面上渲染出来的特勤处制造排名：四个制造台（技术中心 / 工作台 / 制药台 / 防具台）当前最赚钱的前几名，每项含物品名、制造耗时（小时）、总收益、每小时收益；并对比上一次结果，指出这次更新后排名/收益变了什么。请求来自本机真浏览器、用已登录的账号，不受站点匿名额度限制与程序化请求拦截影响（浏览器不可用时自动回退到直连接口）。可用 place 参数只看某一个台（1=技术中心 2=工作台 3=制药台 4=防具台，也认中文名），用 sort=hour 改成按每小时收益排，用 topN 改每个台报几名，用 refresh=true 强制忽略缓存、立刻重读一次。默认「8 小时内只抓一次，窗口内都用那一份」。用户问「今天特勤处制造做什么」「造什么最赚钱」「哪个制造台收益高」「制造排名」「特勤处更新了没」时使用。',
    parameters: {
      type: 'object',
      properties: {
        place: {
          type: 'string',
          description: '可选，只看某个制造台。填 1/2/3/4 或中文名（技术中心、工作台、制药台、防具台）都行。不传则四个台都报。'
        },
        sort: {
          type: 'string',
          description: '可选，排序口径：total=按总收益（默认，和网站一致），hour=按每小时收益。用户说「每小时/按效率」时传 hour。'
        },
        topN: {
          type: 'number',
          description: '可选，每个台报前几名，1~10，默认取技能设置里的值（初始 4）。用户说「多报几个/前五」时传。'
        },
        level: {
          type: 'number',
          description: '可选，制造台等级 1~3，默认取技能设置（初始 3）。用户明确说自己制造台是几级时传。'
        },
        refresh: {
          type: 'boolean',
          description: '可选，是否绕过缓存强制重新抓取，默认 false。用户说「重新查/刷新/是不是又更新了」时才传 true；同群反复追问时不要传。'
        }
      }
    },
    async execute(_ctx, args = {}) {
      if (!httpFetch) {
        return { content: '未启用网络权限（web_fetch），无法查询特勤处制造数据。', isError: true };
      }

      const c = cfg() || {};
      uaCurrent = String(c.userAgent || '').trim() || DEFAULT_UA;
      credNote = '';
      credHeaders = parseCredential(c.cookie);
      const level = clamp(args?.level ?? c.level, 1, 3, 3);
      const sortBy = String(args?.sort ?? c.sortBy ?? 'total').toLowerCase() === 'hour' ? 'hour' : 'total';
      const topN = clamp(args?.topN ?? c.topN, 1, 10, 4);
      const timeoutMs = clamp(c.timeoutMs, 3000, 30000, 15000);
      // 8 小时抓一次（用户要求，见 windowHours 设置）：窗口内谁问都用那一份，不联网
      const windowHours = clamp(c.windowHours, 1, 72, 8);
      const windowMs = windowHours * 3600000;
      const cooldownMs = clamp(c.blockCooldownMin, 1, 240, 3) * 60000;
      const maxPerHour = clamp(c.maxFetchesPerHour, 1, 60, 8);
      // 浏览器通道（默认开）：用真浏览器打开页面读数据，绕开"程序化请求被拦 + 匿名额度"
      const browserMode = String(c.browserMode ?? 'auto').toLowerCase() === 'off' ? 'off' : 'auto';
      const browserExe = String(c.browserPath || '').trim();
      const browserWarmSec = clamp(c.browserWarmSec, 30, 3600, 300);

      // place 参数：既决定报几个台，也决定真正联网抓几个台
      let onlyPlace = null;
      if (args?.place != null && String(args.place).trim() !== '' && String(args.place) !== 'all') {
        const raw = String(args.place).trim();
        onlyPlace = PLACE_ALIAS[raw.toLowerCase()] ?? PLACE_ALIAS[raw] ?? null;
        if (!onlyPlace) {
          return { content: `没听懂要查哪个台：「${args.place}」。可选 1 技术中心 / 2 工作台 / 3 制药台 / 4 防具台。`, isError: true };
        }
      }

      let out;
      try {
        out = await loadData({
          level, sortBy, timeoutMs, cooldownMs,
          force: args?.refresh === true,
          placesWanted: onlyPlace ? [onlyPlace] : [1, 2, 3, 4],
          depth: topN,
          maxPerHour,
          browserMode, browserExe, browserWarmSec, windowMs, windowHours
        });
      } catch (e) {
        logger.error('teqinchu-rank: 抓取过程异常：%s', e?.stack ?? e?.message ?? e);
        return { content: `抓取特勤处数据时出错：${e?.message ?? e}`, isError: true };
      }
      if (out.error) {
        // 只在"真的出问题"的时候才提凭证的事：数据抓到了就别拿设置问题去打扰群里
        const tip = credNote ? `\n\n⚠️ ${credNote}` : '';
        return { content: out.error + tip, isError: true };
      }

      // 截断到 topN（抓取时按全量排序，这里才按用户要的条数切）
      const payload = {
        ...out.payload,
        places: Object.fromEntries(Object.entries(out.payload.places)
          .map(([k, v]) => [k, { ...v, top: (v.top || []).slice(0, topN) }]))
      };

      let content;
      if (onlyPlace) {
        const only = { [String(onlyPlace)]: payload.places[String(onlyPlace)] || { top: [] } };
        content = buildReport({ payload: { ...payload, places: only }, changes: out.changes, staleNote: out.staleNote });
        // 只有这一轮真的顺带抓了其它台，才说"其余台也更新了"；否则如实说没抓，
        // 不然就成了"拿旧数据假装刚更新"。
        const didAll = (payload.fetchedPlaces || []).length > 1;
        const others = Object.keys(payload.places).filter((k) => k !== String(onlyPlace));
        if (others.length) {
          const brief = others.map((k) => `${PLACES[k]}：${payload.places[k].top[0]?.name ?? '暂无数据'}`).join('；');
          content += didAll
            ? `\n\n（其余台本轮也顺带更新了 —— ${brief}）`
            : `\n\n（其余台本轮没重新抓，省数据源请求；上次记录 —— ${brief}。要看就说"四个台都报"）`;
        }
      } else {
        content = buildReport({ payload, changes: out.changes, staleNote: out.staleNote });
      }
      if (out.fromCache) {
        content += `\n\n（本次用的是 ${agoText(out.payload.fetchedAt)} 抓的那一份 —— 设置是「${windowHours} 小时抓一次」，还有约 ${out.leftText || leftText(out.payload.fetchedAt, windowMs)} 才到下次抓取。要马上要最新的就说「重新查」）`;
      }
      // 凭证填了却没解析出登录头时，只在"被拦/冷却"这种真出问题的场景才提醒，
      // 抓数据正常时不必拿设置问题去打扰群里
      if (credNote && out.cooldown) content += `\n\n⚠️ ${credNote}`;
      return { content };
    }
  });
}

/** 自检：没有网络权限时明确报出来（技能页会显示"依赖未就绪"而不是静默失效）。 */
export function available() {
  if (!httpFetch) return { ok: false, reason: '缺少 web_fetch 权限（清单里的 permissions 被删了？）' };
  return true;
}

/** 技能被停用/热重载时把常驻浏览器关掉，别留一个没人管的浏览器进程。 */
export function dispose() { return closeBrowser(); }
export function deactivate() { return closeBrowser(); }
