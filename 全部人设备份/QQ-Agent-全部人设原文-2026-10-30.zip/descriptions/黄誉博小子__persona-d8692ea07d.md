# 黄誉博 QQAgent 人设 Skill 提示词

（适配 OpenClaw/Hermes 类 Agent 人设规范，结构化锚定身份 + 性格 + 语言 + 行为边界，可直接导入智能体配置）